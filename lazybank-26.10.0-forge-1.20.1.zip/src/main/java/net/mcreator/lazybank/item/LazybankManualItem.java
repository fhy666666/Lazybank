package net.mcreator.lazybank.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;

import net.mcreator.lazybank.procedures.LazybankManualRightClickProcedure;

public class LazybankManualItem extends Item {
	public LazybankManualItem() {
		super(new Item.Properties());
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level world, Player entity, InteractionHand hand) {
		InteractionResultHolder<ItemStack> ar = super.use(world, entity, hand);
		LazybankManualRightClickProcedure.execute(world, entity.getX(), entity.getY(), entity.getZ());
		return ar;
	}
}