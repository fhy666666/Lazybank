package net.mcreator.lazybank.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.util.RandomSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.lazybank.procedures.LazybankRightClickProcedure;
import net.mcreator.lazybank.procedures.LazybankPlaceProcedure;
import net.mcreator.lazybank.procedures.LazybankMainWorkProcedure;
import net.mcreator.lazybank.block.entity.LazybankBlockEntity;

import com.google.common.collect.ImmutableMap;

public class LazybankBlock extends Block implements EntityBlock {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
	private final ImmutableMap<BlockState, VoxelShape> shapes = this.makeShapes();

	public LazybankBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.WOOD).strength(1f, 1000f).lightLevel(blockstate -> 11).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	private ImmutableMap<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			return switch (state.getValue(FACING)) {
				case NORTH -> Shapes.or(box(1, 1, 1, 15, 15, 2), box(4, 2, 0, 14, 4, 1), box(2, 4, 0, 14, 12, 1), box(2, 12, 0, 12, 14, 1), box(3, 3, 2, 13, 13, 3), box(4, 4, 4, 12, 12, 12), box(5, 5, 3, 11, 11, 4), box(5, 2, 5, 11, 4, 11),
						box(3, 1, 3, 13, 2, 13), box(4, 0, 4, 12, 1, 12));
				case EAST -> Shapes.or(box(14, 1, 1, 15, 15, 15), box(15, 2, 4, 16, 4, 14), box(15, 4, 2, 16, 12, 14), box(15, 12, 2, 16, 14, 12), box(13, 3, 3, 14, 13, 13), box(4, 4, 4, 12, 12, 12), box(12, 5, 5, 13, 11, 11),
						box(5, 2, 5, 11, 4, 11), box(3, 1, 3, 13, 2, 13), box(4, 0, 4, 12, 1, 12));
				case WEST -> Shapes.or(box(1, 1, 1, 2, 15, 15), box(0, 2, 2, 1, 4, 12), box(0, 4, 2, 1, 12, 14), box(0, 12, 4, 1, 14, 14), box(2, 3, 3, 3, 13, 13), box(4, 4, 4, 12, 12, 12), box(3, 5, 5, 4, 11, 11), box(5, 2, 5, 11, 4, 11),
						box(3, 1, 3, 13, 2, 13), box(4, 0, 4, 12, 1, 12));
				default -> Shapes.or(box(1, 1, 14, 15, 15, 15), box(2, 2, 15, 12, 4, 16), box(2, 4, 15, 14, 12, 16), box(4, 12, 15, 14, 14, 16), box(3, 3, 13, 13, 13, 14), box(4, 4, 4, 12, 12, 12), box(5, 5, 12, 11, 11, 13), box(5, 2, 5, 11, 4, 11),
						box(3, 1, 3, 13, 2, 13), box(4, 0, 4, 12, 1, 12));
			};
		});
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return shapes.get(state);
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		BlockState state = super.getStateForPlacement(context);
		if (state == null)
			return null;
		return state.setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public void onPlace(BlockState blockstate, Level world, BlockPos pos, BlockState oldState, boolean moving) {
		super.onPlace(blockstate, world, pos, oldState, moving);
		world.scheduleTick(pos, this, 1);
	}

	@Override
	public void tick(BlockState blockstate, ServerLevel world, BlockPos pos, RandomSource random) {
		super.tick(blockstate, world, pos, random);
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		LazybankMainWorkProcedure.execute(world, x, y, z);
		world.scheduleTick(pos, this, 1);
	}

	@Override
	public void setPlacedBy(Level world, BlockPos pos, BlockState blockstate, LivingEntity entity, ItemStack itemstack) {
		super.setPlacedBy(world, pos, blockstate, entity, itemstack);
		LazybankPlaceProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ(), entity);
	}

	@Override
	public InteractionResult use(BlockState blockstate, Level world, BlockPos pos, Player entity, InteractionHand hand, BlockHitResult hit) {
		super.use(blockstate, world, pos, entity, hand, hit);
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		double hitX = hit.getLocation().x;
		double hitY = hit.getLocation().y;
		double hitZ = hit.getLocation().z;
		Direction direction = hit.getDirection();
		LazybankRightClickProcedure.execute(world, x, y, z, entity);
		return InteractionResult.SUCCESS;
	}

	@Override
	public MenuProvider getMenuProvider(BlockState state, Level worldIn, BlockPos pos) {
		BlockEntity tileEntity = worldIn.getBlockEntity(pos);
		return tileEntity instanceof MenuProvider menuProvider ? menuProvider : null;
	}

	@Override
	public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
		return new LazybankBlockEntity(pos, state);
	}

	@Override
	public boolean triggerEvent(BlockState state, Level world, BlockPos pos, int eventID, int eventParam) {
		super.triggerEvent(state, world, pos, eventID, eventParam);
		BlockEntity blockEntity = world.getBlockEntity(pos);
		return blockEntity != null && blockEntity.triggerEvent(eventID, eventParam);
	}

	@Override
	public boolean hasAnalogOutputSignal(BlockState state) {
		return true;
	}

	@Override
	public int getAnalogOutputSignal(BlockState blockState, Level world, BlockPos pos) {
		BlockEntity tileentity = world.getBlockEntity(pos);
		if (tileentity instanceof LazybankBlockEntity be)
			return AbstractContainerMenu.getRedstoneSignalFromContainer(be);
		else
			return 0;
	}
}