package net.mcreator.lazybank.procedures;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.LongTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.lazybank.network.LazybankModVariables;

public class LazybankChemicalMainWorkProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		String lazybankChemicalName = "";
		String category1 = "";
		String category2 = "";
		String lazybankChemicalNameTemp = "";
		double lazybankChemicalBalance = 0;
		double lazybankTimer = 0;
		CompoundTag compoundTag = new CompoundTag();
		lazybankChemicalName = getBlockNBTString(world, BlockPos.containing(x, y, z), "lazybankChemicalName");
		lazybankChemicalBalance = getBlockNBTNumber(world, BlockPos.containing(x, y, z), "lazybankChemicalBalance");
		lazybankTimer = LazybankModVariables.MapVariables.get(world).lazybankTicker + Math.abs((int) (x * 31) ^ (int) (y * 17) ^ (int) z);
		category1 = getBlockNBTString(world, BlockPos.containing(x, y, z), "category1");
		category2 = getBlockNBTString(world, BlockPos.containing(x, y, z), "category2");
		if ((ForgeRegistries.BLOCKS.getKey((world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock()).toString()).contains("tank")
				|| (ForgeRegistries.BLOCKS.getKey((world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock()).toString()).contains("barrel")) {
			if ((lazybankChemicalName).equals("")) {
				if (!((Tag) ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y + 1), (int) z)) instanceof BlockEntity _blockEnt9 ? _blockEnt9.saveWithFullMetadata() : new CompoundTag()).get("GasTanks") instanceof ListTag _list11
						? _list11
						: new ListTag()).isEmpty()) {
					category1 = "GasTanks";
					category2 = "gasName";
				} else if (!((Tag) ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y + 1), (int) z)) instanceof BlockEntity _blockEnt13 ? _blockEnt13.saveWithFullMetadata() : new CompoundTag())
						.get("InfusionTanks") instanceof ListTag _list15 ? _list15 : new ListTag()).isEmpty()) {
					category1 = "InfusionTanks";
					category2 = "infusionName";
				} else if (!((Tag) ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y + 1), (int) z)) instanceof BlockEntity _blockEnt17 ? _blockEnt17.saveWithFullMetadata() : new CompoundTag())
						.get("SlurryTanks") instanceof ListTag _list19 ? _list19 : new ListTag()).isEmpty()) {
					category1 = "SlurryTanks";
					category2 = "infusionName";
				} else if (!((Tag) ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y + 1), (int) z)) instanceof BlockEntity _blockEnt21 ? _blockEnt21.saveWithFullMetadata() : new CompoundTag())
						.get("PigmentTanks") instanceof ListTag _list23 ? _list23 : new ListTag()).isEmpty()) {
					category1 = "PigmentTanks";
					category2 = "pigmentName";
				} else if (!((Tag) ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y + 1), (int) z)) instanceof BlockEntity _blockEnt25 ? _blockEnt25.saveWithFullMetadata() : new CompoundTag())
						.get("chemical_tanks") instanceof ListTag _list27 ? _list27 : new ListTag()).isEmpty()) {
					category1 = "chemical_tanks";
					category2 = "id";
				}
				if (!((Tag) ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y + 1), (int) z)) instanceof BlockEntity _blockEnt29 ? _blockEnt29.saveWithFullMetadata() : new CompoundTag()).get(category1) instanceof ListTag _list31
						? _list31
						: new ListTag()).isEmpty()) {
					lazybankChemicalNameTemp = (Tag) ((Tag) ((Tag) ((Tag) ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y + 1), (int) z)) instanceof BlockEntity _blockEnt33
							? _blockEnt33.saveWithFullMetadata()
							: new CompoundTag()).get(category1) instanceof ListTag _list35 ? _list35 : new ListTag()).get(0) instanceof CompoundTag _compound37 ? _compound37 : new CompoundTag()).get("stored") instanceof CompoundTag _compound39
									? _compound39
									: new CompoundTag())
							.get(category2) instanceof StringTag _stringTag41 ? _stringTag41.getAsString() : "";
				}
				if (!(lazybankChemicalNameTemp).equals("")) {
					if (LazybankModVariables.MapVariables.get(world).isLazybankChemicalRebalancedMode) {
						if (!(((lazybankChemicalNameTemp.substring(lazybankChemicalNameTemp.indexOf(":", 0) + 1)).replace("gas", "")).replaceAll("^_+|_+$", "")).contains("_")) {
							lazybankChemicalName = lazybankChemicalNameTemp;
						}
					} else {
						lazybankChemicalName = lazybankChemicalNameTemp;
					}
				}
			}
			if (!((Tag) ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y + 1), (int) z)) instanceof BlockEntity _blockEnt42 ? _blockEnt42.saveWithFullMetadata() : new CompoundTag()).get(category1) instanceof ListTag _list44
					? _list44
					: new ListTag()).isEmpty()) {
				if (!(lazybankChemicalName).equals("")
						&& ((Tag) ((Tag) ((Tag) ((Tag) ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y + 1), (int) z)) instanceof BlockEntity _blockEnt46 ? _blockEnt46.saveWithFullMetadata() : new CompoundTag())
								.get(category1) instanceof ListTag _list48 ? _list48 : new ListTag()).get(0) instanceof CompoundTag _compound50 ? _compound50 : new CompoundTag()).get("stored") instanceof CompoundTag _compound52
										? _compound52
										: new CompoundTag())
								.get(category2) instanceof StringTag _stringTag54 ? _stringTag54.getAsString() : "").equals(lazybankChemicalName)) {
					lazybankChemicalBalance = lazybankChemicalBalance
							+ ((Tag) ((Tag) ((Tag) ((Tag) ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y + 1), (int) z)) instanceof BlockEntity _blockEnt55 ? _blockEnt55.saveWithFullMetadata() : new CompoundTag())
									.get(category1) instanceof ListTag _list57 ? _list57 : new ListTag()).get(0) instanceof CompoundTag _compound59 ? _compound59 : new CompoundTag()).get("stored") instanceof CompoundTag _compound61
											? _compound61
											: new CompoundTag())
									.get("amount") instanceof LongTag _numberTag63 ? _numberTag63.getAsLong() : 0);
					compoundTag = (Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y + 1), (int) z)) instanceof BlockEntity _blockEnt64 ? _blockEnt64.saveWithFullMetadata() : new CompoundTag();
					((Tag) ((Tag) ((Tag) compoundTag.get(category1) instanceof ListTag _list66 ? _list66 : new ListTag()).get(0) instanceof CompoundTag _compound68 ? _compound68 : new CompoundTag()).get("stored") instanceof CompoundTag _compound70
							? _compound70
							: new CompoundTag()).put("amount", LongTag.valueOf((long) 0));
					if ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y + 1), (int) z)) instanceof BlockEntity _blockEnt73)
						_blockEnt73.load(compoundTag);
				}
			}
		}
		if (lazybankChemicalBalance >= LazybankModVariables.MapVariables.get(world).minimumInterestBearingAmount * 1000) {
			if (((Tag) ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y - 1), (int) z)) instanceof BlockEntity _blockEnt74 ? _blockEnt74.saveWithFullMetadata() : new CompoundTag()).get(category1) instanceof ListTag _list76
					? _list76
					: new ListTag()).isEmpty()) {
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							("data modify block ~ ~-1 ~ " + category1 + " set value [{Tank:0b,stored:{amount:"
									+ Math.max(1,
											(ForgeRegistries.BLOCKS.getKey((world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock()).toString()).contains("basic")
													? (int) Math.min((lazybankChemicalBalance * LazybankModVariables.MapVariables.get(world).interestRate) / LazybankModVariables.MapVariables.get(world).interestEarningPeriod, 64000)
													: (int) Math.min((lazybankChemicalBalance * LazybankModVariables.MapVariables.get(world).interestRate) / LazybankModVariables.MapVariables.get(world).interestEarningPeriod, 131072000))
									+ "L," + category2 + ":\"" + lazybankChemicalName + "\"}}]"));
				if (lazybankTimer % LazybankModVariables.MapVariables.get(world).interestEarningPeriod == 0) {
					lazybankChemicalBalance = Math.min(lazybankChemicalBalance + lazybankChemicalBalance * LazybankModVariables.MapVariables.get(world).interestRate,
							(131072000 * LazybankModVariables.MapVariables.get(world).interestEarningPeriod) / LazybankModVariables.MapVariables.get(world).interestRate);
				}
			} else {
				if (!(((Tag) ((Tag) ((Tag) ((Tag) ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y - 1), (int) z)) instanceof BlockEntity _blockEnt83 ? _blockEnt83.saveWithFullMetadata() : new CompoundTag())
						.get(category1) instanceof ListTag _list85 ? _list85 : new ListTag()).get(0) instanceof CompoundTag _compound87 ? _compound87 : new CompoundTag()).get("stored") instanceof CompoundTag _compound89
								? _compound89
								: new CompoundTag())
						.get(category2) instanceof StringTag _stringTag91 ? _stringTag91.getAsString() : "").equals(lazybankChemicalName))) {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								("data modify block ~ ~-1 ~ " + category1 + " set value [{Tank:0b,stored:{amount:"
										+ Math.max(1,
												(ForgeRegistries.BLOCKS.getKey((world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock()).toString()).contains("basic")
														? (int) Math.min((lazybankChemicalBalance * LazybankModVariables.MapVariables.get(world).interestRate) / LazybankModVariables.MapVariables.get(world).interestEarningPeriod, 64000)
														: (int) Math.min((lazybankChemicalBalance * LazybankModVariables.MapVariables.get(world).interestRate) / LazybankModVariables.MapVariables.get(world).interestEarningPeriod, 131072000))
										+ "L," + category2 + ":\"" + lazybankChemicalName + "\"}}]"));
				}
				if (((ForgeRegistries.BLOCKS.getKey((world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock()).toString()).contains("tank")
						|| (ForgeRegistries.BLOCKS.getKey((world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock()).toString()).contains("barrel"))
						&& ((ForgeRegistries.BLOCKS.getKey((world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock()).toString()).contains("basic")
								? ((Tag) ((Tag) ((Tag) ((Tag) ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y - 1), (int) z)) instanceof BlockEntity _blockEnt103 ? _blockEnt103.saveWithFullMetadata() : new CompoundTag())
										.get(category1) instanceof ListTag _list105 ? _list105 : new ListTag()).get(0) instanceof CompoundTag _compound107 ? _compound107 : new CompoundTag()).get("stored") instanceof CompoundTag _compound109
												? _compound109
												: new CompoundTag())
										.get("amount") instanceof LongTag _numberTag111 ? _numberTag111.getAsLong() : 0) < 64000
								: ((Tag) ((Tag) ((Tag) ((Tag) ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y - 1), (int) z)) instanceof BlockEntity _blockEnt112 ? _blockEnt112.saveWithFullMetadata() : new CompoundTag())
										.get(category1) instanceof ListTag _list114 ? _list114 : new ListTag()).get(0) instanceof CompoundTag _compound116 ? _compound116 : new CompoundTag()).get("stored") instanceof CompoundTag _compound118
												? _compound118
												: new CompoundTag())
										.get("amount") instanceof LongTag _numberTag120 ? _numberTag120.getAsLong() : 0) < 131072000)) {
					if (lazybankChemicalBalance * LazybankModVariables.MapVariables.get(world).interestRate <= LazybankModVariables.MapVariables.get(world).interestEarningPeriod) {
						if (lazybankTimer % (LazybankModVariables.MapVariables.get(world).interestEarningPeriod / (lazybankChemicalBalance * LazybankModVariables.MapVariables.get(world).interestRate)) == 0) {
							if ((ForgeRegistries.BLOCKS.getKey((world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock()).toString()).contains("basic")) {
								compoundTag = (Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y - 1), (int) z)) instanceof BlockEntity _blockEnt123 ? _blockEnt123.saveWithFullMetadata() : new CompoundTag();
								((Tag) ((Tag) ((Tag) compoundTag.get(category1) instanceof ListTag _list125 ? _list125 : new ListTag()).get(0) instanceof CompoundTag _compound127 ? _compound127 : new CompoundTag())
										.get("stored") instanceof CompoundTag _compound129
												? _compound129
												: new CompoundTag())
										.put("amount",
												LongTag.valueOf(
														(long) Math.min(
																((Tag) ((Tag) ((Tag) ((Tag) ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y - 1), (int) z)) instanceof BlockEntity _blockEnt130
																		? _blockEnt130.saveWithFullMetadata()
																		: new CompoundTag()).get(category1) instanceof ListTag _list132 ? _list132 : new ListTag()).get(0) instanceof CompoundTag _compound134 ? _compound134 : new CompoundTag())
																		.get("stored") instanceof CompoundTag _compound136 ? _compound136 : new CompoundTag()).get("amount") instanceof LongTag _numberTag138 ? _numberTag138.getAsLong() : 0) + 1,
																64000)));
								if ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y - 1), (int) z)) instanceof BlockEntity _blockEnt141)
									_blockEnt141.load(compoundTag);
							} else {
								compoundTag = (Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y - 1), (int) z)) instanceof BlockEntity _blockEnt142 ? _blockEnt142.saveWithFullMetadata() : new CompoundTag();
								((Tag) ((Tag) ((Tag) compoundTag.get(category1) instanceof ListTag _list144 ? _list144 : new ListTag()).get(0) instanceof CompoundTag _compound146 ? _compound146 : new CompoundTag())
										.get("stored") instanceof CompoundTag _compound148
												? _compound148
												: new CompoundTag())
										.put("amount",
												LongTag.valueOf(
														(long) Math.min(
																((Tag) ((Tag) ((Tag) ((Tag) ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y - 1), (int) z)) instanceof BlockEntity _blockEnt149
																		? _blockEnt149.saveWithFullMetadata()
																		: new CompoundTag()).get(category1) instanceof ListTag _list151 ? _list151 : new ListTag()).get(0) instanceof CompoundTag _compound153 ? _compound153 : new CompoundTag())
																		.get("stored") instanceof CompoundTag _compound155 ? _compound155 : new CompoundTag()).get("amount") instanceof LongTag _numberTag157 ? _numberTag157.getAsLong() : 0) + 1,
																131072000)));
								if ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y - 1), (int) z)) instanceof BlockEntity _blockEnt160)
									_blockEnt160.load(compoundTag);
							}
						}
					} else {
						if ((ForgeRegistries.BLOCKS.getKey((world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock()).toString()).contains("basic")) {
							compoundTag = (Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y - 1), (int) z)) instanceof BlockEntity _blockEnt163 ? _blockEnt163.saveWithFullMetadata() : new CompoundTag();
							((Tag) ((Tag) ((Tag) compoundTag.get(category1) instanceof ListTag _list165 ? _list165 : new ListTag()).get(0) instanceof CompoundTag _compound167 ? _compound167 : new CompoundTag())
									.get("stored") instanceof CompoundTag _compound169 ? _compound169 : new CompoundTag())
									.put("amount",
											LongTag.valueOf((long) Math.min(((Tag) ((Tag) ((Tag) ((Tag) ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y - 1), (int) z)) instanceof BlockEntity _blockEnt170
													? _blockEnt170.saveWithFullMetadata()
													: new CompoundTag()).get(category1) instanceof ListTag _list172 ? _list172 : new ListTag()).get(0) instanceof CompoundTag _compound174 ? _compound174 : new CompoundTag())
													.get("stored") instanceof CompoundTag _compound176 ? _compound176 : new CompoundTag()).get("amount") instanceof LongTag _numberTag178 ? _numberTag178.getAsLong() : 0)
													+ (lazybankChemicalBalance * LazybankModVariables.MapVariables.get(world).interestRate) / LazybankModVariables.MapVariables.get(world).interestEarningPeriod, 64000)));
							if ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y - 1), (int) z)) instanceof BlockEntity _blockEnt181)
								_blockEnt181.load(compoundTag);
						} else {
							compoundTag = (Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y - 1), (int) z)) instanceof BlockEntity _blockEnt182 ? _blockEnt182.saveWithFullMetadata() : new CompoundTag();
							((Tag) ((Tag) ((Tag) compoundTag.get(category1) instanceof ListTag _list184 ? _list184 : new ListTag()).get(0) instanceof CompoundTag _compound186 ? _compound186 : new CompoundTag())
									.get("stored") instanceof CompoundTag _compound188 ? _compound188 : new CompoundTag())
									.put("amount",
											LongTag.valueOf((long) Math.min(((Tag) ((Tag) ((Tag) ((Tag) ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y - 1), (int) z)) instanceof BlockEntity _blockEnt189
													? _blockEnt189.saveWithFullMetadata()
													: new CompoundTag()).get(category1) instanceof ListTag _list191 ? _list191 : new ListTag()).get(0) instanceof CompoundTag _compound193 ? _compound193 : new CompoundTag())
													.get("stored") instanceof CompoundTag _compound195 ? _compound195 : new CompoundTag()).get("amount") instanceof LongTag _numberTag197 ? _numberTag197.getAsLong() : 0)
													+ (lazybankChemicalBalance * LazybankModVariables.MapVariables.get(world).interestRate) / LazybankModVariables.MapVariables.get(world).interestEarningPeriod, 131072000)));
							if ((Object) world.getBlockEntity(BlockPos.containing((int) x, (int) (y - 1), (int) z)) instanceof BlockEntity _blockEnt200)
								_blockEnt200.load(compoundTag);
						}
					}
				} else if (lazybankTimer % LazybankModVariables.MapVariables.get(world).interestEarningPeriod == 0) {
					lazybankChemicalBalance = Math.min(lazybankChemicalBalance + lazybankChemicalBalance * LazybankModVariables.MapVariables.get(world).interestRate,
							(131072000 * LazybankModVariables.MapVariables.get(world).interestEarningPeriod) / LazybankModVariables.MapVariables.get(world).interestRate);
				}
			}
		}
		if (!world.isClientSide()) {
			BlockPos _bp = BlockPos.containing(x, y, z);
			BlockEntity _blockEntity = world.getBlockEntity(_bp);
			BlockState _bs = world.getBlockState(_bp);
			if (_blockEntity != null) {
				_blockEntity.getPersistentData().putDouble("lazybankChemicalBalance", lazybankChemicalBalance);
				_blockEntity.getPersistentData().putString("lazybankChemicalName", lazybankChemicalName);
				_blockEntity.getPersistentData().putString("category1", category1);
				_blockEntity.getPersistentData().putString("category2", category2);
			}
			if (world instanceof Level _level)
				_level.sendBlockUpdated(_bp, _bs, _bs, 3);
		}
	}

	private static String getBlockNBTString(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getString(tag);
		return "";
	}

	private static double getBlockNBTNumber(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getDouble(tag);
		return -1;
	}
}