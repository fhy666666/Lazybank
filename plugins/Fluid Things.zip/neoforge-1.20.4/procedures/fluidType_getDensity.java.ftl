(
    ${input$fluidstack}.getFluidType().getDensity()
)