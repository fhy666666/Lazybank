(
    ${input$fluidstack}.getFluidType().getLightLevel()
)