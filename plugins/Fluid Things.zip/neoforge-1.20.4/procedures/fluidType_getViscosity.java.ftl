(
    ${input$fluidstack}.getFluidType().getViscosity()
)