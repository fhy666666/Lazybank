(
	${input$fluidstack}.getHoverName().getString()
)