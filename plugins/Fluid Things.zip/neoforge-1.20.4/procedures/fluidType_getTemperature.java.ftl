(
    ${input$fluidstack}.getFluidType().getTemperature()
)