(
    ${input$fluidstack}.getFluid().getAttributes().canPushEntity(${input$entity})
)