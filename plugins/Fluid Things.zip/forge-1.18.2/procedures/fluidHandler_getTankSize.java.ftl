(
    new Object() {
        public int getTankSize(LevelAccessor level, BlockPos pos, int tank) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            if(blockEntity != null) {
                return blockEntity.getCapability(CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY, null)
                    .map(fluidHandler -> fluidHandler.getTankCapacity(tank))
                    .orElse(0);
            }
            return 0;
        }
    }.getTankSize(world, new BlockPos((int)${input$x}, (int)${input$y}, (int)${input$z}), (int) ${input$tank})
)