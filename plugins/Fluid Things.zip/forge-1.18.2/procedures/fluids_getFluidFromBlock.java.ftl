(
    new Object() {
        public FluidStack getFluidFromBlock(LevelAccessor level, BlockPos pos) {
            if (world instanceof Level lvl) {
                FluidState state = lvl.getFluidState(pos);
                if(state != null && !state.isEmpty()) {
                    return new FluidStack(state.getType(), 1000);
                }
            }
            return FluidStack.EMPTY;
        }
    }.getFluidFromBlock(world, new BlockPos((int)${input$x}, (int)${input$y}, (int)${input$z}))
)