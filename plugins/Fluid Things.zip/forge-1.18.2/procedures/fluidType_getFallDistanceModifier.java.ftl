(
    ${input$fluidstack}.getFluid().getAttributes().getFallDistanceModifier(${input$entity})
)