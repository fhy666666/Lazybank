(
    ${input$fluidstack}.getFluid().getAttributes().getLuminosity()
)