(
    new Object() {
        public boolean doesBlockHaveTank(LevelAccessor level, BlockPos pos) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            if(blockEntity != null) {
                return blockEntity.getCapability(CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY, null).isPresent();
            }
            return false;
        }
    }.doesBlockHaveTank(world, new BlockPos((int)${input$x}, (int)${input$y}, (int)${input$z}))
)