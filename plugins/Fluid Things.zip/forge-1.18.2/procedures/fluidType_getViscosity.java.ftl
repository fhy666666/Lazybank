(
    ${input$fluidstack}.getFluid().getAttributes().getViscosity(world, ${input$fluidstack}.getFluid().defaultFluidState().createLegacyBlock())
)