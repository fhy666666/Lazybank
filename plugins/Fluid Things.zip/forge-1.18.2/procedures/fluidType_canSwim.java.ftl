(
    ${input$fluidstack}.getFluid().getAttributes().canSwim(${input$entity})
)