(
    ${input$fluidstack}.getFluid().getAttributes().getDensity(world, ${input$fluidstack}.getFluid().defaultFluidState().createLegacyBlock())
)