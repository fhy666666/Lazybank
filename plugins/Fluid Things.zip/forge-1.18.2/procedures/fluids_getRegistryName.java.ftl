(
    net.minecraftforge.registries.ForgeRegistries.FLUIDS.getKey(${input$fluidstack}.getFluid()).toString()
)