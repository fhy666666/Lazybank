{
	${input$fluidstack}.grow(${opt.toInt(input$amount)});
}