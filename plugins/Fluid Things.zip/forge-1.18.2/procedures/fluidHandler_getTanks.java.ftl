(
    new Object() {
        public int getTanks(LevelAccessor level, BlockPos pos) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            if(blockEntity != null) {
                return blockEntity.getCapability(CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY, null)
                    .map(fluidHandler -> fluidHandler.getTanks())
                    .orElse(0);
            }
            return 0;
        }
    }.getTanks(world, new BlockPos((int)${input$x}, (int)${input$y}, (int)${input$z}))
)