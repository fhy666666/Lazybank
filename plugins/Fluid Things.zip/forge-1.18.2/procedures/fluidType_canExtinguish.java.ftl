(
    ${input$fluidstack}.getFluid().getAttributes().canExtinguish(${input$entity})
)