{
    ${input$fluidstack}.shrink(${opt.toInt(input$amount)});
}