(
    ${input$fluidstack}.getDisplayName().getString()
)