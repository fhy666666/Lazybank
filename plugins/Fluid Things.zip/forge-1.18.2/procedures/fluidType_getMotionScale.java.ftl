(
    ${input$fluidstack}.getFluid().getAttributes().getMotionScale(${input$entity})
)