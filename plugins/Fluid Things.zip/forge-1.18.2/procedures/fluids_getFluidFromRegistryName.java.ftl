(
    new FluidStack(net.minecraftforge.registries.ForgeRegistries.FLUIDS.getValue(new ResourceLocation(${input$regName})), 1)
)