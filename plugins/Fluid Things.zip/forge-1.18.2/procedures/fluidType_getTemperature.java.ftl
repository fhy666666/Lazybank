(
    ${input$fluidstack}.getFluid().getAttributes().getTemperature()
)