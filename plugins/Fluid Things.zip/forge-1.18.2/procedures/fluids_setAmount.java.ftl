{
    ${input$fluidstack}.setAmount(${opt.toInt(input$amount)});
}