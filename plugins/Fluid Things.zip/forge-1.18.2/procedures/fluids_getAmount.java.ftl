(
    ${input$fluidstack}.getAmount()
)