{
    int _drain = ${opt.toInt(input$amount)};
    BlockEntity blockEntity = world.getBlockEntity(new BlockPos((int)${input$x}, (int)${input$y}, (int)${input$z}));
    if(blockEntity != null) {
        blockEntity.getCapability(CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY, null).ifPresent(capability -> 
            capability.drain(new FluidStack(${input$fluidstack}.getFluid(), _drain), IFluidHandler.FluidAction.EXECUTE)
        );
    }
}