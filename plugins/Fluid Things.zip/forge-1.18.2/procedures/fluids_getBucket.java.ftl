(
    ${input$fluidstack}.getFluid().getBucket()
)