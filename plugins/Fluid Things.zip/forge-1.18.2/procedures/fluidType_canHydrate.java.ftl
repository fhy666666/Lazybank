(
    ${input$fluidstack}.getFluid().getAttributes().canHydrate(${input$entity})
)