(
    new Object() {
        public boolean isFluidValid(LevelAccessor level, BlockPos pos, FluidStack stack, int tank) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            if(blockEntity != null) {
                return blockEntity.getCapability(CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY, null)
                    .map(fluidHandler -> fluidHandler.isFluidValid(tank, stack))
                    .orElse(false);
            }
            return false;
        }
    }.isFluidValid(world, new BlockPos((int)${input$x}, (int)${input$y}, (int)${input$z}), ${input$fluidstack}, (int) ${input$tank})
)