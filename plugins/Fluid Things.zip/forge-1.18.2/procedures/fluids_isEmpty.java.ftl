(
    ${input$fluidstack}.isEmpty()
)