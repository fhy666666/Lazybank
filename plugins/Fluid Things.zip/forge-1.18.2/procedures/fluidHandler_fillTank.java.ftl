{
    int _fill = ${opt.toInt(input$amount)};
    BlockEntity blockEntity = world.getBlockEntity(new BlockPos((int)${input$x}, (int)${input$y}, (int)${input$z}));
    if(blockEntity != null) {
        blockEntity.getCapability(CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY, null).ifPresent(capability -> 
            capability.fill(new FluidStack(${input$fluidstack}.getFluid(), _fill), IFluidHandler.FluidAction.EXECUTE)
        );
    }
}