(
    new Object() {
        public int getAmountInTank(LevelAccessor level, BlockPos pos, int tank) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            if(blockEntity != null) {
                return blockEntity.getCapability(CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY, null)
                    .map(fluidHandler -> fluidHandler.getFluidInTank(tank).getAmount())
                    .orElse(0);
            }
            return 0;
        }
    }.getAmountInTank(world, new BlockPos((int)${input$x}, (int)${input$y}, (int)${input$z}), (int) ${input$tank})
)