(
    ${input$fluidstack}.getFluid().getAttributes().canConvertToSource()
)