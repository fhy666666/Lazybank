(
    new Object() {
        public FluidStack getFluidInTank(LevelAccessor level, BlockPos pos, int tank) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            if(blockEntity != null) {
                return blockEntity.getCapability(CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY, null)
                    .map(fluidHandler -> fluidHandler.getFluidInTank(tank).copy())
                    .orElse(FluidStack.EMPTY);
            }
            return FluidStack.EMPTY;
        }
    }.getFluidInTank(world, new BlockPos((int)${input$x}, (int)${input$y}, (int)${input$z}), (int) ${input$tank})
)