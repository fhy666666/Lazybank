(
	new FluidStack(BuiltInRegistries.FLUID.getValue(ResourceLocation.parse(${input$regName})), 1)
)