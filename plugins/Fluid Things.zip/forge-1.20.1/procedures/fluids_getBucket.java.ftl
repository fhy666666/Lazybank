(
	${input$fluidstack}.getFluid().getBucket()
)