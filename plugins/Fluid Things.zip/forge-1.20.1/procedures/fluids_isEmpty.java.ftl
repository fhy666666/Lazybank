(
	${input$fluidstack}.isEmpty()
)