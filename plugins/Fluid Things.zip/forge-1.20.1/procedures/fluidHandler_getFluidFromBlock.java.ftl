(
	new Object() {
		public FluidStack getFluidInTank(LevelAccessor level, BlockPos pos, int tank) {
			BlockEntity blockEntity = level.getBlockEntity(pos);
			if(blockEntity != null) {
				return blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, null)
					.map(fluidHandler -> fluidHandler.getFluidInTank(tank).copy())
					.orElse(FluidStack.EMPTY);
			}
			return FluidStack.EMPTY;
		}
	}.getFluidInTank(world, BlockPos.containing(${input$x}, ${input$y}, ${input$z}),(int) ${input$tank})
)