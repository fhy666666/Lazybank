(
	new Object() {
		public int getTankSize(LevelAccessor level, BlockPos pos, int tank) {
			BlockEntity blockEntity = level.getBlockEntity(pos);
			if(blockEntity != null) {
				return blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, null)
					.map(fluidHandler -> fluidHandler.getTankCapacity(tank))
					.orElse(0);
			}
			return 0;
		}
	}.getTankSize(world, BlockPos.containing(${input$x}, ${input$y}, ${input$z}),(int) ${input$tank})
)