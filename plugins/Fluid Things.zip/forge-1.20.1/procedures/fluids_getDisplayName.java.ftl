(
	${input$fluidstack}.getDisplayName().getString()
)