(
	new Object() {
		public boolean isFluidValid(LevelAccessor level, BlockPos pos, FluidStack stack, int tank) {
			BlockEntity blockEntity = level.getBlockEntity(pos);
			if(blockEntity != null) {
				return blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, null)
					.map(fluidHandler -> fluidHandler.isFluidValid(tank, stack))
					.orElse(false);
			}
			return false;
		}
	}.isFluidValid(world, BlockPos.containing(${input$x}, ${input$y}, ${input$z}), ${input$fluidstack},(int) ${input$tank})
)