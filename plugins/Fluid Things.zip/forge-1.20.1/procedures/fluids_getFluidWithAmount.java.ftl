(
	new FluidStack(${input$fluidstack}.getFluid(), ${opt.toInt(input$amount)})
)