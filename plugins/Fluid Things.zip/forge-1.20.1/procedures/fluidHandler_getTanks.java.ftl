(
	new Object() {
		public int getTanks(LevelAccessor level, BlockPos pos) {
			BlockEntity blockEntity = level.getBlockEntity(pos);
			if(blockEntity != null) {
				return blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, null)
					.map(fluidHandler -> fluidHandler.getTanks())
					.orElse(0);
			}
			return 0;
		}
	}.getTanks(world, BlockPos.containing(${input$x}, ${input$y}, ${input$z}))
)