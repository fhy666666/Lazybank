(
	${input$fluidstack}.getAmount()
)