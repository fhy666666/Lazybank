
int insertCount = ${input$count};
ItemStack stackToInsert = ${input$items}.copy();
if (!world.isClientSide()) {


    // 坐标修正（避免偏移）
    BlockPos pos = new BlockPos(
        (int)Math.floor(${input$x}),
        (int)Math.floor(${input$y}),
        (int)Math.floor(${input$z})
    );

    // 【1.21.1 适配重点】：确保 world 是标准的 Level 对象
    if (world instanceof net.minecraft.world.level.Level _level) {
        
        // 【1.21.1 能力系统重构】：不再使用 BlockEntity.getCapability
        // 直接向当前世界查询该坐标下的 IItemHandler（第三个参数 null 代表不限制朝向）
        var handler = _level.getCapability(net.neoforged.neoforge.capabilities.Capabilities.ItemHandler.BLOCK, pos, null);
        
        // 如果成功获取到容器接口
        if (handler != null) {
            
            // 解决内部使用的 final 变量限制
            final double finalinsertCount = insertCount;
            final ItemStack finalstackToInsert = stackToInsert.copy();

            long total = Math.round(finalinsertCount);
            if (total <= 0) return;

            // 防止超过 int 上限
            if (total > Integer.MAX_VALUE) total = Integer.MAX_VALUE;
            int remaining = (int) total;

            // 创建超大堆叠的 ItemStack (1.21.1 内存中依然支持突破最大堆叠限制)
            ItemStack tempStack = finalstackToInsert.copy();
            tempStack.setCount(remaining); 

            // O(1) 性能优化版的遍历插入
            for (int i = 0; i < handler.getSlots(); i++) {
                tempStack = handler.insertItem(i, tempStack, false);
                
                // 如果堆叠变为空（已全部存入），则提前结束遍历
                if (tempStack.isEmpty()) {
                    break;
                }
            }
        }
    }
}
