
int insertCount = ${input$count};

ItemStack stackToInsert = ${input$items}.copy();

if (!world.isClientSide()) {


    // 坐标修正（避免偏移）
    BlockPos pos = new BlockPos(
        (int)Math.floor(${input$x}),
        (int)Math.floor(${input$y}),
        (int)Math.floor(${input$z})
    );

    BlockEntity be = world.getBlockEntity(pos);
    if (be == null) return;

    // 【关键修复】：解决 Java lambda 表达式的 final 限制
    // 在进入 lambda 之前，将变量声明为 final
    final ItemStack finalstackToInsert = stackToInsert.copy();
    final double finalinsertCount = insertCount;

    be.getCapability(net.minecraftforge.items.CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null)
    .ifPresent(handler -> {

        // 在这里使用 finalinsertCount
        long total = Math.round(finalinsertCount);
        if (total <= 0) return;

        // 防止超过 int 上限
        if (total > Integer.MAX_VALUE) total = Integer.MAX_VALUE;
        int remaining = (int) total;

        // 在这里使用 finalstackToInsert
        ItemStack tempStack = finalstackToInsert.copy();
        tempStack.setCount(remaining); 

        // 遍历所有槽位尝试插入 (O(1) 性能优化版)
        for (int i = 0; i < handler.getSlots(); i++) {
            tempStack = handler.insertItem(i, tempStack, false);
            
            // 如果堆叠变为空（已全部存入），则提前结束遍历
            if (tempStack.isEmpty()) {
                break;
            }
        }
    });
}
