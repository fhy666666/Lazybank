package ${package}.mixin;

import ${package}.nummax.NumMax;
import net.minecraft.core.component.DataComponents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(DataComponents.class)
public class NumMaxDataComponentsMixin {
    @ModifyConstant(method = "lambda$static$1(Lnet/minecraft/core/component/DataComponentType$Builder;)Lnet/minecraft/core/component/DataComponentType$Builder;",
            constant = @Constant(intValue = 99))
    private static int nummax$maxStackLimit(int original) {
        return NumMax.MAX_STACK;
    }
}
