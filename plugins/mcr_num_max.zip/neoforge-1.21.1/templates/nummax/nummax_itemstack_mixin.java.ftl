package ${package}.mixin;

import ${package}.nummax.NumMax;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(ItemStack.class)
public class NumMaxItemStackMixin {
    @ModifyConstant(method = "lambda$static$3(Lcom/mojang/serialization/codecs/RecordCodecBuilder$Instance;)Lcom/mojang/datafixers/kinds/App;",
            constant = @Constant(intValue = 99))
    private static int nummax$countLimit(int original) {
        return NumMax.MAX_STACK;
    }
}
