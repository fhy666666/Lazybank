<#--
 # MCreator (https://mcreator.net/)
 # Copyright (C) 2012-2020, Pylo
 # Copyright (C) 2020-2023, Pylo, opensource contributors
 #
 # This program is free software: you can redistribute it and/or modify
 # it under the terms of the GNU General Public License as published by
 # the Free Software Foundation, either version 3 of the License, or
 # (at your option) any later version.
 #
 # This program is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 # GNU General Public License for more details.
 #
 # You should have received a copy of the GNU General Public License
 # along with this program.  If not, see <https://www.gnu.org/licenses/>.
 #
 # Additional permission for code generator templates (*.ftl files)
 #
 # As a special exception, you may create a larger work that contains part or
 # all of the MCreator code generator templates (*.ftl files) and distribute
 # that work under terms of your choice, so long as that work isn't itself a
 # template for code generation. Alternatively, if you modify or redistribute
 # the template itself, you may (at your option) remove this special exception,
 # which will cause the template and the resulting code generator output files
 # to be licensed under the GNU General Public License without this special
 # exception.
-->

<#-- @formatter:off -->
package ${package}.item.inventory;

<@javacompress>
@EventBusSubscriber public class ${name}InventoryCapability extends ComponentItemHandler {

	@SubscribeEvent public static void onItemDropped(ItemTossEvent event) {
		if (event.getEntity().getItem().getItem() == ${JavaModName}Items.${REGISTRYNAME}.get()) {
			Player player = event.getPlayer();
			if (player.containerMenu instanceof ${data.guiBoundTo}Menu)
				player.closeContainer();
		}
	}

	public ${name}InventoryCapability(MutableDataComponentHolder parent) {
		super(parent, DataComponents.CONTAINER, ${data.inventorySize});
	}

	<#if data.inventoryStackSize != 99>
	@Override public int getSlotLimit(int slot) {
		return ${data.inventoryStackSize}

	@Override public ItemStack insertItem(int slot, @Nonnull ItemStack toInsert, boolean simulate) {
		this.validateSlotIndex(slot);
		if (toInsert.isEmpty()) {
			return ItemStack.EMPTY;
		}
		if (!this.isItemValid(slot, toInsert)) {
			return toInsert;
		}
		net.minecraft.world.item.component.ItemContainerContents contents = this.getContents();
		ItemStack existing = this.getStackFromContents(contents, slot);
		int insertLimit = this.getSlotLimit(slot);
		if (toInsert.getMaxStackSize() <= 1 || insertLimit <= toInsert.getMaxStackSize()) {
			insertLimit = Math.min(insertLimit, toInsert.getMaxStackSize());
		}
		if (!existing.isEmpty()) {
			if (!ItemStack.isSameItemSameComponents(toInsert, existing)) {
				return toInsert;
			}
			insertLimit -= existing.getCount();
		}
		if (insertLimit <= 0) {
			return toInsert;
		}
		int inserted = Math.min(insertLimit, toInsert.getCount());
		if (!simulate) {
			this.updateContents(contents, toInsert.copyWithCount(existing.getCount() + inserted), slot);
		}
		return toInsert.copyWithCount(toInsert.getCount() - inserted);
	};
	}
	</#if>

	@Override public boolean isItemValid(int slot, @Nonnull ItemStack stack) {
		return stack.getItem() != ${JavaModName}Items.${REGISTRYNAME}.get();
	}

	@Override public ItemStack getStackInSlot(int slot) {
		return super.getStackInSlot(slot).copy();
	}

}
</@javacompress>

<#-- @formatter:on -->