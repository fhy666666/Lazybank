package ${package}.mixin;

import net.minecraft.core.NonNullList;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.SlotItemHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractContainerMenu.class)
public abstract class NumMaxSwapMergeMixin {
    @Shadow
    public NonNullList<Slot> slots;

    @Inject(method = "doClick(IILnet/minecraft/world/inventory/ClickType;Lnet/minecraft/world/entity/player/Player;)V",
            at = @At("HEAD"), cancellable = true)
    private void nummax$swap(int slotId, int button, ClickType type, Player player, CallbackInfo ci) {
        if (type != ClickType.SWAP || slotId < 0 || slotId >= this.slots.size()) {
            return;
        }
        Slot slot = this.slots.get(slotId);
        if (!(slot instanceof SlotItemHandler)) {
            return;
        }
        ItemStack hotbar = player.getInventory().getItem(button);
        if (hotbar.isEmpty() || !slot.mayPlace(hotbar)) {
            return;
        }
        ItemStack existing = slot.getItem();
        if (existing.isEmpty()) {
            int limit = slot.getMaxStackSize(hotbar);
            if (hotbar.getCount() > limit) {
                slot.setByPlayer(hotbar.split(limit));
                player.getInventory().setItem(button, hotbar);
                player.getInventory().setChanged();
                slot.setChanged();
                ci.cancel();
            }
            return;
        }
        if (!ItemStack.isSameItemSameTags(hotbar, existing)) {
            return;
        }
        int limit = slot.getMaxStackSize(hotbar);
        if (existing.getCount() >= limit) {
            return;
        }
        int move = Math.min(limit - existing.getCount(), hotbar.getCount());
        existing.grow(move);
        hotbar.shrink(move);
        if (hotbar.isEmpty()) {
            player.getInventory().setItem(button, ItemStack.EMPTY);
        } else {
            player.getInventory().setChanged();
        }
        slot.setChanged();
        ci.cancel();
    }
}
