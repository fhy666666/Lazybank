package ${package}.mixin;

import ${package}.nummax.NumMax;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(ServerGamePacketListenerImpl.class)
public abstract class NumMaxServerGamePacketListenerMixin {
    @ModifyConstant(method = "handleSetCreativeModeSlot(Lnet/minecraft/network/protocol/game/ServerboundSetCreativeModeSlotPacket;)V",
            constant = @Constant(intValue = 64))
    private int nummax$creativeStackLimit(int original) {
        return NumMax.MAX_STACK;
    }
}
