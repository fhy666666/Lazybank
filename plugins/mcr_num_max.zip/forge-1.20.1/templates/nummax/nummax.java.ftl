package ${package}.nummax;

public final class NumMax {
    public static final int MAX_STACK = 999000000;

    private NumMax() {
    }
}
