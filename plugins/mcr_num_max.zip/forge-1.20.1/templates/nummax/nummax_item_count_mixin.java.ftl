package ${package}.mixin;

import ${package}.nummax.NumMaxFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(GuiGraphics.class)
public abstract class NumMaxItemCountMixin {
    @Redirect(method = "renderItemDecorations(Lnet/minecraft/client/gui/Font;Lnet/minecraft/world/item/ItemStack;IILjava/lang/String;)V",
            at = @At(value = "INVOKE", target = "Ljava/lang/String;valueOf(I)Ljava/lang/String;", remap = false))
    private String nummax$count(int count) {
        return NumMaxFormat.format(count);
    }

    /**
     * The count label is drawn at x + 19 - 2 - font.width(text); with k/w/m units it can be wider
     * than the 16 px slot and spills outside it. Scale it down so it stays inside the slot.
     */
    @Redirect(method = "renderItemDecorations(Lnet/minecraft/client/gui/Font;Lnet/minecraft/world/item/ItemStack;IILjava/lang/String;)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;drawString(Lnet/minecraft/client/gui/Font;Ljava/lang/String;IIIZ)I"))
    private int nummax$drawCount(GuiGraphics graphics, Font font, String text, int x, int y, int color, boolean shadow) {
        int width = font.width(text);
        float scale = NumMaxFormat.countScale(width, text.length());
        if (scale >= 1.0f) {
            return graphics.drawString(font, text, x, y, color, shadow);
        }

        PoseStack pose = graphics.pose();
        pose.pushPose();
        // keep the right edge and the bottom of the label where vanilla puts them
        pose.translate((float) (x + width) - width * scale, y + 8.0f * (1.0f - scale), 0.0f);
        pose.scale(scale, scale, 1.0f);
        int drawn = graphics.drawString(font, text, 0, 0, color, shadow);
        pose.popPose();
        return drawn;
    }
}
