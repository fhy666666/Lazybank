package ${package}.nummax;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public final class NumMaxByteBuf {
    public static FriendlyByteBuf writeItemStack(FriendlyByteBuf buffer, ItemStack stack, boolean limitedTag) {
        if (stack.isEmpty()) {
            buffer.writeBoolean(false);
        } else {
            buffer.writeBoolean(true);
            Item item = stack.getItem();
            buffer.writeId(BuiltInRegistries.ITEM, item);
            buffer.writeVarInt(Math.max(1, stack.getCount()));
            CompoundTag tag = null;
            if (item.isDamageable(stack) || item.shouldOverrideMultiplayerNbt()) {
                tag = limitedTag ? stack.getShareTag() : stack.getTag();
            }
            buffer.writeNbt(tag);
        }
        return buffer;
    }

    public static ItemStack readItem(FriendlyByteBuf buffer) {
        if (!buffer.readBoolean()) {
            return ItemStack.EMPTY;
        }
        Item item = buffer.readById(BuiltInRegistries.ITEM);
        int count = Math.max(1, buffer.readVarInt());
        ItemStack stack = new ItemStack(item, count);
        stack.readShareTag(buffer.readNbt());
        return stack;
    }

    private NumMaxByteBuf() {
    }
}
