package ${package}.nummax;

import java.util.Locale;

public final class NumMaxFormat {
    public static String format(int count) {
        if (count < 1000) {
            return Integer.toString(count);
        }
        if (count < 10000) {
            return compact(count / 1000.0) + "k";
        }
        if (count < 1000000) {
            return compact(count / 10000.0) + "w";
        }
        return compact(count / 1000000.0) + "m";
    }

    /** Visible width of a slot inner area in pixels; longer labels are scaled down. */
    public static final int SLOT_TEXT_WIDTH = 16;

    /** Smallest scale used for an oversized label so it stays legible. */
    public static final float MIN_COUNT_SCALE = 0.4f;

    /**
     * Scale factor for the stack-count label drawn inside a 16x16 slot: 1.0 while the label
     * fits (up to 4 characters), otherwise just enough to fit, never below MIN_COUNT_SCALE.
     */
    public static float countScale(int textWidth, int textLength) {
        if (textLength <= 4 && textWidth <= SLOT_TEXT_WIDTH) {
            return 1.0f;
        }
        float fit = (float) SLOT_TEXT_WIDTH / Math.max(1, textWidth);
        if (fit > 1.0f) {
            fit = 1.0f;
        }
        if (fit < MIN_COUNT_SCALE) {
            fit = MIN_COUNT_SCALE;
        }
        return fit;
    }

    private static String compact(double value) {
        double floored = Math.floor(value * 100.0) / 100.0;
        String text = String.format(Locale.ROOT, "%.2f", floored);
        while (text.endsWith("0")) {
            text = text.substring(0, text.length() - 1);
        }
        if (text.endsWith(".")) {
            text = text.substring(0, text.length() - 1);
        }
        return text;
    }

    private NumMaxFormat() {
    }
}
