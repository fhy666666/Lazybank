package ${package}.mixin;

import net.minecraft.core.NonNullList;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractContainerMenu.class)
public abstract class NumMaxAbstractContainerMenuMixin {
    @Shadow
    public NonNullList<Slot> slots;

    @Inject(method = "moveItemStackTo(Lnet/minecraft/world/item/ItemStack;IIZ)Z", at = @At("HEAD"), cancellable = true)
    private void nummax$moveItemStackTo(ItemStack source, int start, int end, boolean reverse,
            CallbackInfoReturnable<Boolean> cir) {
        boolean changed = false;
        int index = start;
        if (reverse) {
            index = end - 1;
        }

        if (source.isStackable()) {
            while (!source.isEmpty()) {
                if (reverse) {
                    if (index < start) {
                        break;
                    }
                } else if (index >= end) {
                    break;
                }

                Slot slot = this.slots.get(index);
                ItemStack existing = slot.getItem();
                if (!existing.isEmpty() && ItemStack.isSameItemSameTags(source, existing)) {
                    int combined = existing.getCount() + source.getCount();
                    // 1.20.1 vanilla uses min(slot max, stack max); ask the slot instead so
                    // ItemStackHandler slot limits above 64 can merge.
                    int maxSize = slot.getMaxStackSize(source);
                    if (combined <= maxSize) {
                        source.setCount(0);
                        existing.setCount(combined);
                        slot.setChanged();
                        changed = true;
                    } else if (existing.getCount() < maxSize) {
                        source.shrink(maxSize - existing.getCount());
                        existing.setCount(maxSize);
                        slot.setChanged();
                        changed = true;
                    }
                }

                if (reverse) {
                    --index;
                } else {
                    ++index;
                }
            }
        }

        if (!source.isEmpty()) {
            if (reverse) {
                index = end - 1;
            } else {
                index = start;
            }

            while (true) {
                if (reverse) {
                    if (index < start) {
                        break;
                    }
                } else if (index >= end) {
                    break;
                }

                Slot slot = this.slots.get(index);
                ItemStack existing = slot.getItem();
                if (existing.isEmpty() && slot.mayPlace(source)) {
                    if (source.getCount() > slot.getMaxStackSize(source)) {
                        slot.setByPlayer(source.split(slot.getMaxStackSize(source)));
                    } else {
                        slot.setByPlayer(source.split(source.getCount()));
                    }
                    slot.setChanged();
                    changed = true;
                    break;
                }

                if (reverse) {
                    --index;
                } else {
                    ++index;
                }
            }
        }

        cir.setReturnValue(changed);
    }
}
