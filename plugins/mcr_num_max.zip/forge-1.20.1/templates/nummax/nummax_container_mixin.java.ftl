package ${package}.mixin;

import ${package}.nummax.NumMax;
import net.minecraft.world.Container;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(Container.class)
public interface NumMaxContainerMixin {
    /**
     * @author mcr_num_max
     * @reason Allow container slots to hold up to NumMax.MAX_STACK items.
     */
    @Overwrite
    default int getMaxStackSize() {
        return NumMax.MAX_STACK;
    }
}
