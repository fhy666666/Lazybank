package ${package}.mixin;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ItemStack.class)
public abstract class NumMaxItemStackMixin {
    @Shadow
    private int count;

    @Inject(method = "save(Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag;", at = @At("TAIL"))
    private void nummax$saveCount(CompoundTag tag, CallbackInfoReturnable<CompoundTag> cir) {
        tag.putInt("Count", this.count);
    }

    @Inject(method = "of(Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/item/ItemStack;", at = @At("RETURN"))
    private static void nummax$loadCount(CompoundTag tag, CallbackInfoReturnable<ItemStack> cir) {
        if (tag.contains("Count")) {
            ItemStack stack = cir.getReturnValue();
            if (stack != ItemStack.EMPTY) {
                stack.setCount(tag.getInt("Count"));
            }
        }
    }
}
