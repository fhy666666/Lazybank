package ${package}.mixin;

import ${package}.nummax.NumMaxByteBuf;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.game.ServerboundSetCreativeModeSlotPacket;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(ServerboundSetCreativeModeSlotPacket.class)
public class NumMaxServerboundSetCreativeModeSlotPacketMixin {
    @Redirect(method = "write(Lnet/minecraft/network/FriendlyByteBuf;)V",
              at = @At(value = "INVOKE",
                      target = "Lnet/minecraft/network/FriendlyByteBuf;writeItemStack(Lnet/minecraft/world/item/ItemStack;Z)Lnet/minecraft/network/FriendlyByteBuf;",
                      remap = false))
    private FriendlyByteBuf nummax$writeItemStack(FriendlyByteBuf buffer, ItemStack stack, boolean limitedTag) {
        return NumMaxByteBuf.writeItemStack(buffer, stack, limitedTag);
    }
}
