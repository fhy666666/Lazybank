package ${package}.mixin;

import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.items.SlotItemHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(SlotItemHandler.class)
public abstract class NumMaxSlotItemHandlerMixin {
    @Shadow
    private IItemHandler itemHandler;
    @Shadow
    private int index;

    @Inject(method = "getMaxStackSize(Lnet/minecraft/world/item/ItemStack;)I", at = @At("HEAD"), cancellable = true)
    private void nummax$slotMax(ItemStack stack, CallbackInfoReturnable<Integer> cir) {
        int slotLimit = this.itemHandler.getSlotLimit(this.index);
        int itemMax = stack.getMaxStackSize();
        if (itemMax <= 1 || slotLimit <= 99 || slotLimit <= itemMax) {
            return;
        }
        ItemStack maxAdd = stack.copy();
        maxAdd.setCount(slotLimit);
        ItemStack current = this.itemHandler.getStackInSlot(this.index);
        if (this.itemHandler instanceof IItemHandlerModifiable modifiable) {
            modifiable.setStackInSlot(this.index, ItemStack.EMPTY);
            ItemStack remainder = modifiable.insertItem(this.index, maxAdd, true);
            modifiable.setStackInSlot(this.index, current);
            cir.setReturnValue(slotLimit - remainder.getCount());
        } else {
            ItemStack remainder = this.itemHandler.insertItem(this.index, maxAdd, true);
            cir.setReturnValue(current.getCount() + (slotLimit - remainder.getCount()));
        }
    }
}
