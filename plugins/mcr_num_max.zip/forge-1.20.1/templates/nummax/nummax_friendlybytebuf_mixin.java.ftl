package ${package}.mixin;

import ${package}.nummax.NumMaxByteBuf;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(FriendlyByteBuf.class)
public abstract class NumMaxFriendlyByteBufMixin {
    @Redirect(method = "writeItem(Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/network/FriendlyByteBuf;",
              at = @At(value = "INVOKE",
                      target = "Lnet/minecraft/network/FriendlyByteBuf;writeItemStack(Lnet/minecraft/world/item/ItemStack;Z)Lnet/minecraft/network/FriendlyByteBuf;",
                      remap = false))
    private FriendlyByteBuf nummax$writeItem(FriendlyByteBuf buffer, ItemStack stack, boolean limitedTag) {
        return NumMaxByteBuf.writeItemStack(buffer, stack, limitedTag);
    }

    @Inject(method = "readItem()Lnet/minecraft/world/item/ItemStack;", at = @At("HEAD"), cancellable = true)
    private void nummax$readItem(CallbackInfoReturnable<ItemStack> cir) {
        cir.setReturnValue(NumMaxByteBuf.readItem((FriendlyByteBuf) (Object) this));
    }
}
