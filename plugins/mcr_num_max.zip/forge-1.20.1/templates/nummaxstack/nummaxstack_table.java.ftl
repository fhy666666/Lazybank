package ${package}.nummaxstack;

import net.minecraft.world.item.Item;

import java.util.HashMap;
import java.util.Map;

/**
 * 工作区里所有「物品堆叠突破」元素的合并结果。
 *
 * <p>由 nummaxstack 元素类型按工作区生成一次（定义里的 {@code global_templates}）。只有工作区里
 * 至少存在一个该类型的元素时才会生成，所以不含该元素的工作区完全不会出现本类与配套的 mixin。</p>
 *
 * <p>合并规则：</p>
 * <ul>
 *   <li><b>全突破</b>：本 mod 命名空间下、<b>原本就能堆叠</b>（原版上限 > 1）的物品一律抬到
 *       {@link #MAX_STACK}。</li>
 *   <li><b>选择性突破</b>：只有列出的物品按各自上限生效，未列出的保持原版。</li>
 *   <li>多个元素同时存在时：任一元素开了全突破就按全突破；选择性条目取<b>最大值</b>合并。</li>
 * </ul>
 *
 * <p><b>延迟初始化</b>：元素配置里会写 {@code ModBlocks.XXX.get()} 这类注册表查询，mod 构造期
 * 注册表还没冻结，所以这里第一次真正查表时才构建（那时游戏早已跑起来）。</p>
 *
 * <p>生成的文件，请勿编辑。</p>
 */
public final class NumMaxStackTable {

    /** 与 NumMax.MAX_STACK 一致。 */
    public static final int MAX_STACK = 999000000;

    private static final String MOD_ID = "${modid}";

    private static Map<Item, Integer> limits = null;

    private static boolean breakAll = false;

    private NumMaxStackTable() {
    }

    private static synchronized void ensureInitialized() {
        if (limits != null) {
            return;
        }

        Accumulator accumulator = new Accumulator();
<#list nummaxstacks as element>
        ${element.getModElement().getName()}StackConfig.apply(accumulator);
</#list>
        breakAll = accumulator.breakAll;
        limits = accumulator.limits;
    }

    /**
     * @param item         要查询的物品
     * @param vanillaLimit 该物品原本的堆叠上限
     * @return 要用的上限；-1 表示不干预（保持原版）
     */
    public static int limitFor(Item item, int vanillaLimit) {
        if (item == null || vanillaLimit <= 1) {
            return -1;
        }

        ensureInitialized();

        Integer explicit = limits.get(item);
        if (explicit != null) {
            return explicit.intValue();
        }

        if (breakAll) {
            net.minecraft.resources.ResourceLocation key = net.minecraft.core.registries.BuiltInRegistries.ITEM
                    .getKey(item);
            if (key != null && MOD_ID.equals(key.getNamespace())) {
                return MAX_STACK;
            }
        }

        return -1;
    }

    /** 当前是否全突破（调试用）。 */
    public static boolean isBreakAll() {
        ensureInitialized();
        return breakAll;
    }

    /** 当前选择性条目数（调试用）。 */
    public static int size() {
        ensureInitialized();
        return limits.size();
    }

    /** 各元素的配置往这里累加；同一个工作区的多个元素在首次查表时依次调用。 */
    public static final class Accumulator {

        boolean breakAll;

        final Map<Item, Integer> limits = new HashMap<>();

        public void breakAll(boolean value) {
            if (value) {
                this.breakAll = true;
            }
        }

        public void limit(Item item, int limit) {
            if (item == null || limit <= 1) {
                return;
            }
            Integer previous = this.limits.get(item);
            if (previous == null || limit > previous.intValue()) {
                this.limits.put(item, Integer.valueOf(limit));
            }
        }
    }
}
