package ${package}.mixin;

import ${package}.nummaxstack.NumMaxStackTable;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 让「物品堆叠突破」元素对<b>已经创建好</b>的物品生效：不改任何物品类的生成代码，
 * 直接在 {@code ItemStack#getMaxStackSize()} 的 HEAD 处查表。
 *
 * <p>为什么选这个注入点：两个分支的 {@code ItemStack#getMaxStackSize()} 字节码都是
 * {@code getItem().getMaxStackSize(this)}，而 {@code Slot#getMaxStackSize(ItemStack)}、
 * 合并、快捷移动、漏斗传输全部经过它，所以一处注入即可覆盖所有堆叠判定。</p>
 *
 * <p>递归保护：handler 里读原版上限用的是 {@code item.getMaxStackSize(stack)}（两个分支都是
 * 接口 default 方法，不会回调 {@code ItemStack#getMaxStackSize()}）；再加一个 ThreadLocal 兜底，
 * 防止别的模组覆写该方法后形成回环。</p>
 */
@Mixin(ItemStack.class)
public class NumMaxStackTableMixin {

    private static final ThreadLocal<Boolean> NUMMAX_BUSY = ThreadLocal.withInitial(() -> Boolean.FALSE);

    @Inject(method = "getMaxStackSize()I", at = @At("HEAD"), cancellable = true)
    private void nummax$stackTableLimit(CallbackInfoReturnable<Integer> cir) {
        if (NUMMAX_BUSY.get().booleanValue()) {
            return;
        }

        ItemStack self = (ItemStack) (Object) this;
        if (self.isEmpty()) {
            return;
        }

        NUMMAX_BUSY.set(Boolean.TRUE);
        try {
            int vanilla = self.getItem().getMaxStackSize(self);
            int limit = NumMaxStackTable.limitFor(self.getItem(), vanilla);
            if (limit > 0) {
                cir.setReturnValue(Integer.valueOf(limit));
            }
        } finally {
            NUMMAX_BUSY.set(Boolean.FALSE);
        }
    }
}