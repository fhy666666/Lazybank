<#-- Per element stack break configuration. Pure data: the merge logic lives in NumMaxStackTable. -->
<#include "../mcitems.ftl">
package ${package}.nummaxstack;

<#-- Vanilla references come out of mcitems.ftl as Blocks.X / Items.X, so both classes are imported
     explicitly instead of relying on the import organizer to disambiguate them. -->
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;

/**
 * 模组元素 "${name}" 的堆叠突破配置。
 *
 * <p>生成的文件，请勿编辑。</p>
 */
public final class ${name}StackConfig {

    private ${name}StackConfig() {
    }

    public static void apply(NumMaxStackTable.Accumulator accumulator) {
        accumulator.breakAll(${data.breakAll?c});
<#list (data.items)![] as row>
    <#if row.item?? && row.item.getUnmappedValue()?has_content && !row.item.getUnmappedValue()?ends_with("deleted_mod_element") && !row.item.getUnmappedValue()?starts_with("TAG:")>
        <#assign raw = row.item.getUnmappedValue()>
        <#if raw?starts_with("EXTERNAL:")>
        accumulator.limit(BuiltInRegistries.ITEM.get(ResourceLocation.tryParse("${raw?remove_beginning("EXTERNAL:")?j_string}")), ${row.limit});
        <#else>
        accumulator.limit(${mappedMCItemToItem(row.item)}, ${row.limit});
        </#if>
    </#if>
</#list>
    }
}
