(${input$entity}.getStringUUID())
