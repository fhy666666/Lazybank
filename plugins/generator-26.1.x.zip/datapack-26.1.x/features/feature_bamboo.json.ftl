{
  "probability": ${field$probability}
}