{
  "absolute": ${field$value}
}