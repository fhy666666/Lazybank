RegPacketProcedure.sendMsg(${input$tagValue});
