<#include "mcitems.ftl">
<#assign _hxName = "hxyzg_attr_" + field$attribute?lower_case?replace(":", "_")?replace(" ", "_") + "_" + field$slots?lower_case?replace(":", "_")?replace(" ", "_")>
{
	net.minecraft.world.item.ItemStack _stack = ${mappedMCItemToItemStackCode(input$item, 1)};
	_stack.set(DataComponents.ATTRIBUTE_MODIFIERS, _stack.getOrDefault(DataComponents.ATTRIBUTE_MODIFIERS, ItemAttributeModifiers.EMPTY).withModifierAdded(${generator.map(field$attribute, "attributes")}, new AttributeModifier(ResourceLocation.fromNamespaceAndPath("${modid}", "${_hxName}"), ${input$tagValue}, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.${generator.map(field$slots, "slots")}));
}