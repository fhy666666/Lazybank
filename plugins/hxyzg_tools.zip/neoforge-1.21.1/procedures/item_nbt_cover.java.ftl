<#include "mcitems.ftl">
{
	net.minecraft.world.item.ItemStack _stack = ${mappedMCItemToItemStackCode(input$item, 1)};
	try {
		_stack.set(DataComponents.CUSTOM_DATA, CustomData.of(TagParser.parseTag(${input$nbtConvert})));
	} catch (Exception _e) {
		_e.printStackTrace();
	}
}