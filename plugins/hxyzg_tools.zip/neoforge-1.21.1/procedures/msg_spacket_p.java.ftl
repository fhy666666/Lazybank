RegPacketProcedure.sendMsgTo(${input$entity}, ${input$tagValue});
