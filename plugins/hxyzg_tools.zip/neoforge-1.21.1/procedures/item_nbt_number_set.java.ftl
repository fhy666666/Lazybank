<#include "mcitems.ftl">
{
	final String _tagName = ${input$tagName};
	final double _tagValue = ${input$tagValue};
	<#if field$type=="Double">
	CustomData.update(DataComponents.CUSTOM_DATA, ${mappedMCItemToItemStackCode(input$item, 1)}, tag -> tag.putDouble(_tagName, _tagValue));
	<#elseif field$type=="Float">
	CustomData.update(DataComponents.CUSTOM_DATA, ${mappedMCItemToItemStackCode(input$item, 1)}, tag -> tag.putFloat(_tagName, (float) _tagValue));
	<#elseif field$type=="Int">
	CustomData.update(DataComponents.CUSTOM_DATA, ${mappedMCItemToItemStackCode(input$item, 1)}, tag -> tag.putInt(_tagName, (int) _tagValue));
	<#elseif field$type=="Long">
	CustomData.update(DataComponents.CUSTOM_DATA, ${mappedMCItemToItemStackCode(input$item, 1)}, tag -> tag.putLong(_tagName, (long) _tagValue));
	<#elseif field$type=="Short">
	CustomData.update(DataComponents.CUSTOM_DATA, ${mappedMCItemToItemStackCode(input$item, 1)}, tag -> tag.putShort(_tagName, (short) _tagValue));
	<#else>
	CustomData.update(DataComponents.CUSTOM_DATA, ${mappedMCItemToItemStackCode(input$item, 1)}, tag -> tag.putByte(_tagName, (byte) _tagValue));
	</#if>
}