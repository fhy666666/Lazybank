<#include "mcitems.ftl">
(new Object() {
    public String getString() {
        if (net.neoforged.fml.loading.FMLEnvironment.dist != net.neoforged.api.distmarker.Dist.CLIENT) return "Server side - cannot get texture";
        
        net.minecraft.world.item.ItemStack stack = ${mappedMCItemToItemStackCode(input$item, 1)};
        if (stack.isEmpty()) return "No item in hand";
        
        net.minecraft.resources.ResourceLocation itemId = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(stack.getItem());
        if (itemId != null) {
            return net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(itemId.getNamespace(), 
                "textures/item/" + itemId.getPath() + ".png").toString();
        }
        
        return "Unknown texture";
    }
}.getString())