{
	${field$modid}ModVariables.PlayerVariables _vars = ${input$entity}.getData(${field$modid}ModVariables.PLAYER_VARIABLES);
	_vars.${field$varName} = ${input$tagValue};
	_vars.markSyncDirty();
}