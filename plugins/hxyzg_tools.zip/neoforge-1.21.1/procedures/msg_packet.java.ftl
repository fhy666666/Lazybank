if (${input$entity} instanceof ServerPlayer _splayer && !_splayer.level().isClientSide()) {
    CompoundTag nbtTemp = _splayer.getPersistentData();
    nbtTemp.putDouble("Attack", _splayer.getAttribute(Attributes.ATTACK_DAMAGE).getBaseValue());
    RegPacketProcedure.sendToPlayer(_splayer, nbtTemp);
}
