<#include "aiconditions.java.ftl">
this.goalSelector.addGoal(${cbi+1}, new MoveTowardsTargetGoal(this, ${field$speed}, (float) ${field$distance})<@conditionCode field$condition/>);
