<#if !data.flyingMob && !data.waterMob>
<#include "aiconditions.java.ftl">
this.goalSelector.addGoal(${cbi+1}, new MoveThroughVillageGoal(this, ${field$speed}, ${field$only_night?lower_case}, (int) ${field$distance}, () -> ${field$open_doors?lower_case})<@conditionCode field$condition/>);
</#if>
