<#-- @formatter:off -->
<#include "procedures.java.ftl">
<#if field$condition?has_content>
	<#assign conditions = generator.procedureNamesToObjects(field$condition)>
<#else>
	<#assign conditions = ["", ""]>
</#if>
this.goalSelector.addGoal(${cbi+1}, new Goal() {
	{
		this.setFlags(EnumSet.of(Goal.Flag.MOVE));
	}

	@Override public boolean canUse() {
		if (${name}Entity.this.getHealth() > ${name}Entity.this.getMaxHealth() * ${field$health} / 100.0)
			return false;
		if (${name}Entity.this.getTarget() == null || !${name}Entity.this.getTarget().isAlive())
			return false;
		<#if hasProcedure(conditions[0])>
		double x = ${name}Entity.this.getX();
		double y = ${name}Entity.this.getY();
		double z = ${name}Entity.this.getZ();
		Entity entity = ${name}Entity.this;
		Level world = ${name}Entity.this.level();
		return <@procedureOBJToConditionCode conditions[0]/>;
		<#else>
		return true;
		</#if>
	}

	@Override public boolean canContinueToUse() {
		<#if hasProcedure(conditions[1])>
		double x = ${name}Entity.this.getX();
		double y = ${name}Entity.this.getY();
		double z = ${name}Entity.this.getZ();
		Entity entity = ${name}Entity.this;
		Level world = ${name}Entity.this.level();
		return <@procedureOBJToConditionCode conditions[1]/> && this.canUse();
		<#else>
		return this.canUse();
		</#if>
	}

	@Override public void tick() {
		LivingEntity _target = ${name}Entity.this.getTarget();
		if (_target == null)
			return;
		Vec3 _away = ${name}Entity.this.position().subtract(_target.position());
		if (_away.lengthSqr() < 1.0E-4)
			_away = new Vec3(1.0, 0.0, 0.0);
		Vec3 _dest = _target.position().add(_away.normalize().scale(${field$distance}));
		${name}Entity.this.getNavigation().moveTo(_dest.x, _dest.y, _dest.z, ${field$speed});
	}
});
<#-- @formatter:on -->
