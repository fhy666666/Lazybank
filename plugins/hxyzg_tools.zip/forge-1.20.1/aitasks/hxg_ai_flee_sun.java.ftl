<#include "aiconditions.java.ftl">
this.goalSelector.addGoal(${cbi+1}, new FleeSunGoal(this, ${field$speed})<@conditionCode field$condition/>);
