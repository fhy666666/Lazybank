<#if !data.flyingMob && !data.waterMob>
<#include "aiconditions.java.ftl">
this.goalSelector.addGoal(${cbi+1}, new GolemRandomStrollInVillageGoal(this, ${field$speed})<@conditionCode field$condition/>);
</#if>
