<#if data.flyingMob>
<#include "aiconditions.java.ftl">
this.goalSelector.addGoal(${cbi+1}, new WaterAvoidingRandomFlyingGoal(this, ${field$speed})<@conditionCode field$condition/>);
</#if>
