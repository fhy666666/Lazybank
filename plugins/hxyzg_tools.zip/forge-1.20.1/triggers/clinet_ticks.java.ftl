<#include "procedures.java.ftl">
@Mod.EventBusSubscriber(value={Dist.CLIENT}) public class ${name}Procedure {
	@SubscribeEvent public static void onClientTick(TickEvent.ClientTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			Minecraft mc = Minecraft.getInstance();
			if (mc.level == null || mc.player == null) {
			    return;
			}
			double x = mc.player.getX();
			double y = mc.player.getY();
			double z = mc.player.getZ();
		<#assign dependenciesCode><#compress>
			<@procedureDependenciesCode dependencies, {
				"entity": "mc.player",
				"x": "x",
				"y": "y",
				"z": "z",
				"world": "mc.level",
				"event": "event"
				}/>
		</#compress></#assign>
		execute(event<#if dependenciesCode?has_content>,</#if>${dependenciesCode});
		}
	}
