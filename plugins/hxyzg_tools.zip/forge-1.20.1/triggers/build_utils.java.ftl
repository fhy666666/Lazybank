<#include "procedures.java.ftl">
@Mod.EventBusSubscriber public class ${name}Procedure {
    /**
     * 一个正在搭建的结构. 方块按"从下到上"排好序; groups 把必须同刻放下的方块绑成一批
     * (门/高花是 DoubleBlockHalf, 床是 BedPart: 只放一半会被邻居更新打散, 所以两半一起放).
     */
    private static final class _B {
        final ServerLevel level;
        final java.util.List<BlockPos> pos;
        final java.util.List<BlockState> state;
        final java.util.List<CompoundTag> nbt;
        final java.util.List<int[]> groups;
        final double perTick;
        final String info;
        final boolean bulk;      // true = 结构群/大型建筑: 不做掉落视觉, 按每刻时间预算推进
        final long budgetMs;     // 每刻最多花多少毫秒落块
        int at = 0;
        double acc = 0.0;
        _B(ServerLevel _l, java.util.List<BlockPos> _p, java.util.List<BlockState> _s,
                java.util.List<CompoundTag> _t, java.util.List<int[]> _g, double _per, String _info, boolean _bulk,
                long _budget) {
            this.level = _l;
            this.pos = _p;
            this.state = _s;
            this.nbt = _t;
            this.groups = _g;
            this.perTick = _per;
            this.info = _info;
            this.bulk = _bulk;
            this.budgetMs = _budget;
        }
    }
    /**
     * 一批正在"掉下来"的方块. 视觉就是普通的掉落方块(FallingBlockEntity), 但它永远落不了地:
     * 离目标 _FALL_KEEP 格时整批由我们自己写进世界(状态 + 方块实体数据), 同时把视觉撤掉.
     * 这样原版的落地逻辑没机会插手, 箱子里的东西不会丢, 门/床也不会被拆散.
     */
    private static final class _P {
        final ServerLevel level;
        final _B b;
        final int[] idx;
        final java.util.ArrayList<FallingBlockEntity> vis = new java.util.ArrayList<>();
        final java.util.ArrayList<Double> visY = new java.util.ArrayList<>();
        int age = 0;
        _P(ServerLevel _l, _B _b, int[] _i) { this.level = _l; this.b = _b; this.idx = _i; }
    }
    /** 每个维度同时只保留一个搭建任务; 再调用一次就换掉它(已经在掉的那些批次会照常落地) */
    /** 同时进行的"演出搭建"最多这么多个 */
    private static final int _MAX_ANIM = 3;
    /** 正在演出搭建的任务: 同一个维度最多同时 3 个, 各自按自己的速度从下往上长 */
    private static final java.util.ArrayList<_B> _anim = new java.util.ArrayList<>();

    /**
     * 一批"无演出"落块任务: 直接引用解析缓存(_C) + 锚点, 不再把每个生成点的方块复制成大列表.
     * 成员/生成点之间按基准高度从下往上排; 每个结构内部用缓存里预先算好的"自下而上 + 双格成组"顺序.
     */
    private static final class _Pt {
        final _C c;
        final int ax, ay, az;
        _Pt(_C _c, int _x, int _y, int _z) {
            this.c = _c;
            this.ax = _x;
            this.ay = _y;
            this.az = _z;
        }
    }

    private static final class _Q {
        final ServerLevel level;
        String info = "";      // 日志信息(挂进队列前填好)
        final java.util.ArrayList<_Pt> pts = new java.util.ArrayList<>();
        int ci = 0;        // 当前处理到第几个结构
        int gi = 0;        // 该结构里处理到第几组
        long total = 0L;   // 方块总数(统计/日志用)
        _Q(ServerLevel _l) {
            this.level = _l;
        }
        void add(_C _c, int _ax, int _ay, int _az) {
            pts.add(new _Pt(_c, _ax, _ay, _az));
            total += _c.pos.size();
        }
        /** 按基准高度从下往上排(同一层先放低的, 和以前"整批从下往上"的效果一致) */
        void sortByY() {
            pts.sort((_a, _b) -> Integer.compare(_a.ay, _b.ay));
        }
    }

    /** 把批次挂进"待落块"队列(填好日志信息) */
    private static void _addQ(_Q _q, String _info) {
        _q.info = _info;
        _bulk.add(_q);
    }

    /** 把一个成员解析成"缓存 + 锚点"塞进批次, 成功(结构读到了)返回 true */
    private static boolean _put(ServerLevel _level, MinecraftServer _srv, _M _m, long _h, double _x, double _y,
            double _z, _Q _q) {
        if (_m == null || _m.id == null) return false;
        int _rot = _m.rotation < 0 ? (int) Math.floorMod(_h >>> 20, 4L) : _m.rotation;
        _C _c = _cached(_level, _srv, _m.id, _rot, 0);
        if (_c == null) return false;
        if (_q.total + _c.pos.size() > _MAX_TOTAL) return false;   // 到总数上限就不再加了
        _q.add(_c, (int) Math.floor(_x + _m.ox), (int) Math.floor(_y + _m.oy), (int) Math.floor(_z + _m.oz));
        return true;
    }

    /** 推进一组方块(1 个或一对双格方块); 所有结构走完就结束 */
    private static void _stepQ(ServerLevel _level, _Q _q) {
        while (_q.ci < _q.pts.size()) {
            _Pt _pt = _q.pts.get(_q.ci);
            if (_pt.c == null || _q.gi >= _pt.c.groups.size()) {
                _q.ci++;
                _q.gi = 0;
                continue;
            }
            int[] _g = _pt.c.groups.get(_q.gi);
            _q.gi++;
            for (int _j : _g) _placeQ(_level, _pt, _j);
            return;
        }
    }

    /** 把缓存结构里的第 _j 个方块按锚点写进世界(坐标现算, 不预先复制) */
    private static void _placeQ(ServerLevel _level, _Pt _pt, int _j) {
        _write(_level, _pt.c.pos.get(_j).offset(_pt.ax, _pt.ay, _pt.az), _pt.c.state.get(_j), _pt.c.nbt.get(_j),
                false);
    }

    /** 批次要放的方块覆盖到的区块先加载好(已经加载的跳过): 跨区块的结构不会丢方块 */
    private static void _preloadQ(ServerLevel _level, _Q _q) {
        if (_q.pts.isEmpty()) return;
        int _mnx = Integer.MAX_VALUE, _mxx = Integer.MIN_VALUE, _mnz = Integer.MAX_VALUE, _mxz = Integer.MIN_VALUE;
        for (int _i = 0; _i < _q.pts.size(); _i++) {
            _Pt _pt = _q.pts.get(_i);
            if (_pt.c.minX + _pt.ax < _mnx) _mnx = _pt.c.minX + _pt.ax;
            if (_pt.c.maxX + _pt.ax > _mxx) _mxx = _pt.c.maxX + _pt.ax;
            if (_pt.c.minZ + _pt.az < _mnz) _mnz = _pt.c.minZ + _pt.az;
            if (_pt.c.maxZ + _pt.az > _mxz) _mxz = _pt.c.maxZ + _pt.az;
        }
        if (_mnx > _mxx || _mnz > _mxz) return;
        for (int _cx = _mnx >> 4; _cx <= (_mxx >> 4); _cx++) {
            for (int _cz = _mnz >> 4; _cz <= (_mxz >> 4); _cz++) {
                if (_level.isLoaded(new BlockPos(_cx << 4, 64, _cz << 4))) continue;
                try {
                    _level.getChunk(_cx, _cz);
                } catch (Throwable _ex) {
                }
            }
        }
    }

    private static final java.util.ArrayList<_P> _pending = new java.util.ArrayList<>();
    private static final int _MAX_SIZE = 512;         // 单个结构尺寸上限: 512x512x512(超过就拒绝并告警)
    private static final int _MAX_BLOCKS = 8000000;   // 单个结构方块数保险上限(512^3 理论最多 1.3 亿, 内存顶不住)
    private static final int _MAX_TOTAL = 16000000;   // 一次生成(结构群/大型建筑)方块总数上限
    private static final int _MAX_PENDING = 64;      // 同时"掉落中"的批次上限
    private static final int _MAX_GROUP = 16;        // 一批超过这么多方块就不做掉落视觉, 直接落地
    private static final int _FALL_UP = 4;           // 从目标上方几格开始掉
    private static final double _FALL_KEEP = 1.2;    // 离目标还剩几格时落地(高于方块顶面, 不给原版落地的机会)

    /**
     * 从下往上, 一个方块一个方块把结构文件搭出来.
     * _speed = 每秒搭几个方块(会被限到约 0.2 ~ 1280); 结构文件要放在 data/<命名空间>/structures/<名字>.nbt.
     * _dual = 1 = 双点: 同一个结构从它 bounding box 的两个对角开始, 两条前沿同时往中间长(仍然是从下往上).
     */
    public static void build(LevelAccessor _a, ResourceLocation _id, double _x, double _y, double _z,
            double _speed, int _rotation, int _mirror, int _dual) {
        if (!(_a instanceof ServerLevel)) {   // 只在服务端搭: 客户端自己也搭会和服务端打架
            System.out.println("[hxyzg] 结构搭建: 这次调用在客户端(ClientLevel), 已忽略 - 搭建要由服务端执行");

            return;
        }
        ServerLevel _level = (ServerLevel) _a;
        MinecraftServer _srv = _level.getServer();
        if (_srv == null) return;
        int _bx = (int) Math.floor(_x), _by = (int) Math.floor(_y), _bz = (int) Math.floor(_z);
        StructurePlaceSettings _set = _settings(_rotation, _mirror);
        java.util.List<BlockPos> _pos = new java.util.ArrayList<>();
        java.util.List<BlockState> _state = new java.util.ArrayList<>();
        java.util.List<CompoundTag> _nbt = new java.util.ArrayList<>();
        String _from = _load(_level, _srv, _id, _set, _bx, _by, _bz, _pos, _state, _nbt);
        int _n = _pos.size();
        if (_n <= 0) {
            System.out.println("[hxyzg] 结构搭建: 读不到 " + _id + " 的方块 (" + _from + ")");
            _warn(_level, "[hxyzg] 读不到结构 " + _id + " (" + _from + ")");

            return;
        }
        boolean _cut = _n >= _MAX_BLOCKS;
        java.util.List<int[]> _groups = _order(_pos, _state);
        double _per = _speed / 20.0;                  // 方块/秒 -> 方块/刻
        if (!(_per > 0.01)) _per = 0.01;              // 最慢约 5 秒一块
        if (_per > 64.0) _per = 64.0;                 // 最快约 1280 块/秒
        String _info = "结构 " + _id + " 共 " + _n + " 方块 / " + _groups.size() + " 批, 速度 " + _speed
                + " 块/秒, 起点 " + _bx + "," + _by + "," + _bz;
        if (_dual == 1) {
            // 双点: 同一个结构, 层内改成"从两个对角同时往中间"的顺序
            int _mnX = _pos.get(0).getX(), _mxX = _mnX, _mnZ = _pos.get(0).getZ(), _mxZ = _mnZ;
            for (int _i = 0; _i < _n; _i++) {
                BlockPos _p = _pos.get(_i);
                if (_p.getX() < _mnX) _mnX = _p.getX();
                if (_p.getX() > _mxX) _mxX = _p.getX();
                if (_p.getZ() < _mnZ) _mnZ = _p.getZ();
                if (_p.getZ() > _mxZ) _mxZ = _p.getZ();
            }
            _groups = _orderDual(_pos, _groups, _mnX, _mxX, _mnZ, _mxZ);
            _info = _info + " (双点: 对角 " + _mnX + "," + _mnZ + " <-> " + _mxX + "," + _mxZ + ")";
        }
        if (_anim.size() >= _MAX_ANIM) {
            String _w = "[hxyzg] 结构搭建: 同时演出的结构最多 " + _MAX_ANIM + " 个, 这次(" + _id + ")没有开始";
            System.out.println(_w);
            _warn(_level, _w);
            return;
        }
        _anim.add(new _B(_level, _pos, _state, _nbt, _groups, _per, _info, false, 3L));
        System.out.println("[hxyzg] 结构搭建开始: " + _info);
        if (_cut) {
            _warn(_level, "[hxyzg] 结构 " + _id + " 的方块数到了保险上限 " + _MAX_BLOCKS + ", 只搭了前 " + _n
                    + " 个(按文件顺序)。建议拆成几个结构文件, 或改用\"大型建筑\"积木。");
        }

    }

    @SubscribeEvent public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel)) return;
        _tick((ServerLevel) event.level);
    }

    /**
     * 主世界卸载(退出存档/关服)时清空"同一格只生成一次"的记录: 不清的话, 同一次游戏里
     * "退回主菜单再进另一个存档"会带着上一个存档的生成记录继续跑(该生成的格子被跳过).
     */
    @SubscribeEvent public static void onWorldUnload(net.minecraftforge.event.level.LevelEvent.Unload event) {
        if (!(event.getLevel() instanceof ServerLevel)) return;
        ServerLevel _level = (ServerLevel) event.getLevel();
        if (!Level.OVERWORLD.equals(_level.dimension())) return;
        _groupDone.clear();
    }

    private static void _tick(ServerLevel _level) {
        _tickBulk(_level);
        // 1) 掉落中的批次: 到了位置就整批落地
        for (int _i = _pending.size() - 1; _i >= 0; _i--) {
            _P _p = _pending.get(_i);
            if (_p.level != _level) continue;
            _p.age++;
            boolean _land = _p.age > 200;
            if (!_land) {
                for (int _k = 0; _k < _p.vis.size(); _k++) {
                    FallingBlockEntity _e = _p.vis.get(_k);
                    if (_e.isRemoved() || !_e.isAlive()
                            || _e.getY() <= _p.visY.get(_k).doubleValue() + _FALL_KEEP) {
                        _land = true;
                        break;
                    }
                }
            }
            if (_land) {
                for (int _j : _p.idx) _place(_level, _p.b, _j, true);
                for (FallingBlockEntity _e : _p.vis) {
                    try {
                        _e.discard();
                    } catch (Exception _ex) {
                    }
                }
                _pending.remove(_i);
            }
        }
        // 2) 继续往上搭: 同一个维度最多同时演 3 个, 各自按自己的速度推进
        for (int _i = _anim.size() - 1; _i >= 0; _i--) {
            _B _b = _anim.get(_i);
            if (_b.level != _level) continue;
            if (_stepAnim(_level, _b)) {
                _anim.remove(_i);
                System.out.println("[hxyzg] 结构搭建完成: " + _b.info);
            }
        }
    }

    /** 放出一批: 能看见掉落就先生成视觉, 到位置再落地; 方块太多就直接落地(不做视觉, 免得卡) */
    private static void _emit(ServerLevel _level, _B _b, int[] _g) {
        if (_g.length > _MAX_GROUP || _pending.size() >= _MAX_PENDING) {
            for (int _j : _g) _place(_level, _b, _j, false);
            return;
        }
        // 流体(水/岩浆)不演出: 直接放置 —— 掉落方块形态没意义, 而且它们一落地就四处流
        for (int _j : _g) {
            if (_b.state.get(_j).getBlock() instanceof LiquidBlock) {
                for (int _k : _g) _place(_level, _b, _k, false);
                return;
            }
        }
        _P _p = new _P(_level, _b, _g);
        for (int _j : _g) {
            BlockPos _bp = _b.pos.get(_j);
            if (!_level.isLoaded(_bp)) continue;
            FallingBlockEntity _e = _spawn(_level, _bp, _b.state.get(_j));
            if (_e != null) {
                _p.vis.add(_e);
                _p.visY.add(Double.valueOf((double) _bp.getY()));
            }
        }
        if (_p.vis.isEmpty()) {
            for (int _j : _g) _place(_level, _b, _j, true);
            return;
        }
        _pending.add(_p);
    }

    /**
     * 在目标正上方找一段全是空气的高度, 从那里丢一个掉落方块下来.
     * 找不到就不做视觉 —— 顺便保证它落下来的一路上不会撞到别的方块(撞到就会被原版提前放下).
     */
    private static FallingBlockEntity _spawn(ServerLevel _level, BlockPos _bp, BlockState _state) {
        int _up = 0;
        while (_up < _FALL_UP && _level.getBlockState(_bp.above(_up + 1)).isAir()) _up++;
        if (_up < 2) return null;
        BlockPos _sp = _bp.above(_up);
        if (!_level.getBlockState(_sp).isAir()) return null;
        try {
            FallingBlockEntity _e = FallingBlockEntity.fall(_level, _sp, _state);
            _e.setHurtsEntities(0.0F, 0);
            _e.setDeltaMovement(0.0, -0.3, 0.0);
            return _e;
        } catch (Exception _ex) {
            return null;
        }
    }

    /**
     * 真正把方块写进世界. flags = 2|16|32 = 只同步客户端 + 不触发形状/邻居更新 + 不掉落:
     * 火把/铁轨/门/床这类靠邻居活着的方块不会被更新打散, 朝向也保持结构文件里的.
     * 方块实体数据(箱子里的东西、告示牌文字、刷怪笼…)从结构文件里读出来写回新方块实体.
     */
    private static void _place(ServerLevel _level, _B _b, int _i, boolean _fx) {
        _write(_level, _b.pos.get(_i), _b.state.get(_i), _b.nbt.get(_i), _fx);
    }

    /** 把一个方块(含方块实体数据)写进世界 */
    private static void _write(ServerLevel _level, BlockPos _p, BlockState _st, CompoundTag _nbt, boolean _fx) {
        if (!_level.isLoaded(_p)) return;
        _level.setBlock(_p, _st, 2 | 16 | 32);
        if (_nbt != null) {
            BlockEntity _be = _level.getBlockEntity(_p);
            if (_be != null) {
                try {
                    _be.load(_nbt.copy());
                    _be.setChanged();
                } catch (Exception _ex) {
                }
            }
        }
        if (_fx) {
            try {
                _level.levelEvent(2001, _p, Block.getId(_st));
            } catch (Exception _ex) {
            }
        }
    }

    /**
     * 这个方块状态是不是"两个方块凑一起才完整". 靠属性值的枚举类名认:
     * 门/高花是 DoubleBlockHalf(UPPER/LOWER), 床是 BedPart(HEAD/FOOT);
     * 活板门的 half 是同一个方块的上下, 枚举是 Half, 所以不算.
     */
    @SuppressWarnings("rawtypes")
    private static Property<?> _doubleProp(BlockState _s) {
        for (Property<?> _p : _s.getProperties()) {
            Comparable<?> _v = _s.getValue((Property) _p);
            if (!(_v instanceof Enum)) continue;
            String _cn = _v.getClass().getSimpleName();
            if ("DoubleBlockHalf".equals(_cn) || "BedPart".equals(_cn)) return _p;
        }
        return null;
    }

    /** 在六个邻居里找这个双方块方块的另一半(同方块、该属性值互补、且还没排进别的批次) */
    @SuppressWarnings("rawtypes")
    private static int _partner(java.util.List<BlockPos> _pos, java.util.List<BlockState> _state, int[] _step,
            int _i, Property<?> _p) {
        BlockPos _p0 = _pos.get(_i);
        BlockState _s0 = _state.get(_i);
        Comparable<?> _v0 = _s0.getValue((Property) _p);
        Direction[] _dirs = new Direction[]{Direction.UP, Direction.DOWN, Direction.NORTH, Direction.SOUTH,
                Direction.WEST, Direction.EAST};
        for (Direction _d : _dirs) {
            BlockPos _q = _p0.relative(_d);
            for (int _j = 0; _j < _pos.size(); _j++) {
                if (_j == _i || _step[_j] >= 0) continue;
                if (!_pos.get(_j).equals(_q)) continue;
                BlockState _s1 = _state.get(_j);
                if (_s1.getBlock() != _s0.getBlock()) continue;
                if (_s1.getValue((Property) _p).equals(_v0)) continue;
                return _j;
            }
        }
        return -1;
    }



    /**
     * 读结构文件: 先按数据包文件直接读(MCreator 的结构就存在 data/<命名空间>/structures/<名字>.nbt,
     * 结构预览走的就是这条路), 读不到再问服务端结构管理器. 返回一句给人看的来源说明.
     */
    private static String _load(ServerLevel _level, MinecraftServer _srv, ResourceLocation _id,
            StructurePlaceSettings _set, int _bx, int _by, int _bz, java.util.List<BlockPos> _pos,
            java.util.List<BlockState> _state, java.util.List<CompoundTag> _nbt) {
        String _from = "没读到 data/" + _id.getNamespace() + "/structures/" + _id.getPath() + ".nbt";
        try {
            String[] _dirs = new String[]{"structures/", "structure/"};
            for (int _d = 0; _d < _dirs.length; _d++) {
                ResourceLocation _file = _id.withPrefix(_dirs[_d]).withSuffix(".nbt");
                java.util.Optional<Resource> _res = _srv.getResourceManager().getResource(_file);
                if (!_res.isPresent()) continue;
                CompoundTag _t;
                try (InputStream _in = _res.get().open()) {
                    _t = NbtIo.readCompressed(_in);
                }
                if (_readTag(_level, _t, _set, _bx, _by, _bz, _pos, _state, _nbt))
                    return _sizeOk(_level, _id, _pos, _state, _nbt) ? "文件 " + _file : "尺寸超限(见告警)";
                _from = _file + " 里没有方块";
            }
        } catch (Exception _ex) {
            _from = "读文件出错(" + _ex.getClass().getSimpleName() + ")";
        }
        try {
            StructureTemplate _tpl = _srv.getStructureManager().get(_id).orElse(null);
            if (_tpl != null) {
                for (StructureTemplate.StructureBlockInfo _i : _tpl.filterBlocks(BlockPos.ZERO, _set, null)) {
                    if (_i == null || _i.state().isAir()) continue;
                    _pos.add(_i.pos().offset(_bx, _by, _bz));
                    _state.add(_i.state());
                    _nbt.add(_i.nbt());
                    if (_pos.size() >= _MAX_BLOCKS) break;
                }
                if (!_pos.isEmpty())
                    return _sizeOk(_level, _id, _pos, _state, _nbt) ? "结构管理器" : "尺寸超限(见告警)";
            }
        } catch (Exception _ex) {
            _from = "结构管理器出错(" + _ex.getClass().getSimpleName() + ")";
        }
        return _from;
    }

    /** 解析结构 NBT 的根: blocks + palette(或 palettes[0]); 位置按旋转/镜像变换, 状态也 mirror/rotate, nbt 一起带上 */
    private static boolean _readTag(ServerLevel _level, CompoundTag _t, StructurePlaceSettings _set,
            int _bx, int _by, int _bz, java.util.List<BlockPos> _pos, java.util.List<BlockState> _state,
            java.util.List<CompoundTag> _nbt) {
        ListTag _blocks = _t.getList("blocks", 10);
        ListTag _palette = _t.getList("palette", 10);
        if (_palette.size() <= 0) {
            ListTag _pals = _t.getList("palettes", 9);
            if (_pals.size() > 0) _palette = _pals.getList(0);
        }
        if (_blocks.size() <= 0 || _palette.size() <= 0) return false;
        for (int _i = 0; _i < _blocks.size(); _i++) {
            CompoundTag _b = _blocks.getCompound(_i);
            int _si = _b.getInt("state");
            if (_si < 0 || _si >= _palette.size()) continue;
            BlockState _st = NbtUtils.readBlockState(_level.holderLookup(Registries.BLOCK), _palette.getCompound(_si));
            if (_st.isAir()) continue;
            int[] _ip = _posOf(_b);
            if (_ip.length < 3) continue;
            _pos.add(StructureTemplate.calculateRelativePosition(_set, new BlockPos(_ip[0], _ip[1], _ip[2]))
                    .offset(_bx, _by, _bz));
            _state.add(_st.mirror(_set.getMirror()).rotate(_set.getRotation()));
            CompoundTag _n = _b.getCompound("nbt");
            _nbt.add(_n.isEmpty() ? null : _n);
            if (_pos.size() >= _MAX_BLOCKS) break;
        }
        return !_pos.isEmpty();
    }

    /** 结构文件里 pos 有的写成 IntArray, 有的写成 List<Int>, 两种都收 */
    private static int[] _posOf(CompoundTag _b) {
        int[] _a = _b.getIntArray("pos");
        if (_a.length >= 3) return _a;
        ListTag _l = _b.getList("pos", 3);
        if (_l.size() >= 3) return new int[]{_l.getInt(0), _l.getInt(1), _l.getInt(2)};
        return new int[0];
    }

    // ================= 解析缓存 =================
    /** 一个结构解析好的样子(位置相对结构原点, 已经按旋转/镜像变换过); 附带预先算好的落块顺序与包围盒 */
    private static final class _C {
        final java.util.List<BlockPos> pos;
        final java.util.List<BlockState> state;
        final java.util.List<CompoundTag> nbt;
        final java.util.List<int[]> groups;              // 自下而上 + 双格方块成组(相对坐标, 与锚点无关, 算一次就够)
        final int minX, minY, minZ, maxX, maxY, maxZ;    // 相对包围盒(补加载区块用)
        _C(java.util.List<BlockPos> _p, java.util.List<BlockState> _s, java.util.List<CompoundTag> _t) {
            this.pos = _p;
            this.state = _s;
            this.nbt = _t;
            this.groups = _order(_p, _s);
            int _nx = 0, _ny = 0, _nz = 0, _xx = 0, _xy = 0, _xz = 0;
            for (int _i = 0; _i < _p.size(); _i++) {
                BlockPos _b = _p.get(_i);
                if (_i == 0) {
                    _nx = _xx = _b.getX();
                    _ny = _xy = _b.getY();
                    _nz = _xz = _b.getZ();
                    continue;
                }
                if (_b.getX() < _nx) _nx = _b.getX();
                if (_b.getX() > _xx) _xx = _b.getX();
                if (_b.getY() < _ny) _ny = _b.getY();
                if (_b.getY() > _xy) _xy = _b.getY();
                if (_b.getZ() < _nz) _nz = _b.getZ();
                if (_b.getZ() > _xz) _xz = _b.getZ();
            }
            this.minX = _nx;
            this.minY = _ny;
            this.minZ = _nz;
            this.maxX = _xx;
            this.maxY = _xy;
            this.maxZ = _xz;
        }
    }
    private static final java.util.HashMap<String, _C> _cache = new java.util.HashMap<>();
    private static long _cacheBlocks = 0L;
    private static final int _CACHE_MAX = 64;

    /**
     * 取解析好的结构(带缓存). 大型建筑和结构群会反复用到同一个结构文件, 每次都重新读盘、重解析调色板太贵,
     * 所以按 "结构名|旋转|镜像" 缓存一份; 缓存里的坐标是相对结构原点的, 用的时候再加锚点.
     */
    private static _C _cached(ServerLevel _level, MinecraftServer _srv, ResourceLocation _id, int _rot, int _mirror) {
        String _k = _id + "|" + _rot + "|" + _mirror;
        _C _c = _cache.get(_k);
        if (_c != null) return _c;
        java.util.List<BlockPos> _p = new java.util.ArrayList<>();
        java.util.List<BlockState> _s = new java.util.ArrayList<>();
        java.util.List<CompoundTag> _t = new java.util.ArrayList<>();
        String _from = _load(_level, _srv, _id, _settings(_rot, _mirror), 0, 0, 0, _p, _s, _t);
        if (_p.isEmpty()) {
            System.out.println("[hxyzg] 结构: 没读到 " + _id + " (" + _from + ")");
            return null;
        }
        if (_cache.size() >= _CACHE_MAX || _cacheBlocks > 8000000L) {
            _cache.clear();
            _cacheBlocks = 0L;
        }
        _c = new _C(_p, _s, _t);
        _cache.put(_k, _c);
        _cacheBlocks += _p.size();
        return _c;
    }

    // ================= 大型单一建筑 =================
    /**
     * 开一栋"大型建筑": 由多个结构文件按相对偏移拼成(用同一套"结构群成员"积木填).
     * _heightmap 地面检测类型; _heightMode 0 贴地 / 2 固定高度(用 _hMin); _rot 整栋旋转(0~3 个 90°);
     * _budgetMs 每刻最多花多少毫秒落块(1~20, 越大越快但越可能掉帧).
     */
    public static void buildingBegin(LevelAccessor _a, double _x, double _y, double _z, int _heightmap,
            int _heightMode, double _hMin, int _rot, double _budgetMs) {
        if (!(_a instanceof ServerLevel)) {
            System.out.println("[hxyzg] 大型建筑: 只在服务端生成, 这次调用被忽略");
            return;
        }
        _G _g = new _G((ServerLevel) _a, _x, _y, _z, 1.0, 1.0, 1.0, 0.0, _heightmap, _heightMode,
                _hMin, _hMin, 1, 0L);
        _g.building = true;
        _g.wholeRot = (int) Math.floorMod((long) _rot, 4L);
        _g.budgetMs = (long) Math.max(1.0, Math.min(20.0, _budgetMs));
        _groupStack.add(_g);
    }

    /** 整栋建筑: 先把覆盖到的区块加载好, 再按整栋旋转把每个成员摆到锚点上, 合成一条队列慢慢落块 */
    private static void _raise(_G _g) {
        ServerLevel _level = _g.level;
        MinecraftServer _srv = _level.getServer();
        if (_srv == null) return;
        long _seed = _g.seed != 0L ? _g.seed : _level.getSeed();
        java.util.ArrayList<_C> _cs = new java.util.ArrayList<>();
        java.util.ArrayList<int[]> _anchors = new java.util.ArrayList<>();
        int _minX = 0, _maxX = 0, _minZ = 0, _maxZ = 0, _miss = 0;
        boolean _first = true;
        for (int _i = 0; _i < _g.members.size(); _i++) {
            _M _m = _g.members.get(_i);
            int _mr = _m.rotation < 0 ? (int) Math.floorMod(_mix(_seed, _i, _g.members.size()), 4L) : _m.rotation;
            int _rot = (int) Math.floorMod((long) (_mr + _g.wholeRot), 4L);
            _C _c = _cached(_level, _srv, _m.id, _rot, 0);
            if (_c == null) {
                _miss++;
                _cs.add(null);
                _anchors.add(new int[]{0, 0, 0});
                continue;
            }
            int _ox = (int) Math.floor(_m.ox), _oy = (int) Math.floor(_m.oy), _oz = (int) Math.floor(_m.oz);
            int _rx, _rz;
            if (_g.wholeRot == 1) { _rx = -_oz; _rz = _ox; }
            else if (_g.wholeRot == 2) { _rx = -_ox; _rz = -_oz; }
            else if (_g.wholeRot == 3) { _rx = _oz; _rz = -_ox; }
            else { _rx = _ox; _rz = _oz; }
            _cs.add(_c);
            _anchors.add(new int[]{_rx, _oy, _rz});
            for (BlockPos _p : _c.pos) {
                int _px = _rx + _p.getX(), _pz = _rz + _p.getZ();
                if (_first) {
                    _minX = _maxX = _px;
                    _minZ = _maxZ = _pz;
                    _first = false;
                } else {
                    if (_px < _minX) _minX = _px;
                    if (_px > _maxX) _maxX = _px;
                    if (_pz < _minZ) _minZ = _pz;
                    if (_pz > _maxZ) _maxZ = _pz;
                }
            }
        }
        if (_first) {
            System.out.println("[hxyzg] 大型建筑: 一个方块都没读到 (没读到的结构 " + _miss + " 个)");
            return;
        }
        // 整栋覆盖到的区块先加载好(不加载会丢方块), 再取地面高度
        int _ax = (int) Math.floor(_g.x), _az = (int) Math.floor(_g.z);
        int _chx0 = (_ax + _minX - 16) >> 4, _chx1 = (_ax + _maxX + 16) >> 4;
        int _chz0 = (_az + _minZ - 16) >> 4, _chz1 = (_az + _maxZ + 16) >> 4;
        int _loaded = 0, _failed = 0;
        for (int _cx = _chx0; _cx <= _chx1; _cx++) {
            for (int _cz = _chz0; _cz <= _chz1; _cz++) {
                try {
                    _level.getChunk(_cx, _cz);
                    _loaded++;
                } catch (Exception _ex) {
                    _failed++;
                }
            }
        }
        double _ay = _ground(_level, _g, _g.x, _g.z, _mix(_seed, _ax, _az));
        _Q _q = new _Q(_level);
        for (int _i = 0; _i < _cs.size(); _i++) {
            _C _c = _cs.get(_i);
            if (_c == null) continue;
            int[] _a = _anchors.get(_i);
            _q.add(_c, _ax + _a[0], (int) Math.floor(_ay) + _a[1], _az + _a[2]);
        }
        if (_q.pts.isEmpty()) {
            System.out.println("[hxyzg] 大型建筑: 拼出来是空的");
            return;
        }
        _q.sortByY();
        String _info = "大型建筑 " + _g.members.size() + " 个结构 / " + _q.total + " 方块, 锚点 " + _ax + ","
                + (int) _ay + "," + _az + ", 整栋旋转 " + (_g.wholeRot * 90) + " 度, 每刻预算 " + _g.budgetMs
                + " ms, 预加载 " + _loaded + " 区块" + (_failed > 0 ? " (失败 " + _failed + ")" : "")
                + (_miss > 0 ? " 没读到 " + _miss + " 个结构" : "");
        _addQ(_q, _info);
        System.out.println("[hxyzg] 大型建筑开始生成: " + _info);
    }

    /** 从下到上(同层按 x/z)排好, 并把必须同刻放下的方块(门/床/高花)绑成一批 */
    private static java.util.List<int[]> _order(java.util.List<BlockPos> _pos, java.util.List<BlockState> _state) {
        int _n = _pos.size();
        Integer[] _order = new Integer[_n];
        for (int _i = 0; _i < _n; _i++) _order[_i] = Integer.valueOf(_i);
        java.util.Arrays.sort(_order, (_p, _q) -> {
            BlockPos _pp = _pos.get(_p.intValue()), _pq = _pos.get(_q.intValue());
            if (_pp.getY() != _pq.getY()) return Integer.compare(_pp.getY(), _pq.getY());
            if (_pp.getX() != _pq.getX()) return Integer.compare(_pp.getX(), _pq.getX());
            return Integer.compare(_pp.getZ(), _pq.getZ());
        });
        int[] _step = new int[_n];
        java.util.Arrays.fill(_step, -1);
        java.util.List<int[]> _groups = new java.util.ArrayList<>();
        for (int _o = 0; _o < _n; _o++) {
            int _i = _order[_o].intValue();
            if (_step[_i] >= 0) continue;
            java.util.ArrayList<Integer> _g = new java.util.ArrayList<>();
            _g.add(Integer.valueOf(_i));
            _step[_i] = _groups.size();
            Property<?> _dp = _doubleProp(_state.get(_i));
            if (_dp != null) {
                int _j = _partner(_pos, _state, _step, _i, _dp);
                if (_j >= 0) {
                    _step[_j] = _groups.size();
                    _g.add(Integer.valueOf(_j));
                }
            }
            int[] _arr = new int[_g.size()];
            for (int _k = 0; _k < _arr.length; _k++) _arr[_k] = _g.get(_k).intValue();
            _groups.add(_arr);
        }
        return _groups;
    }

    // ================= 结构群 =================
    /** 群里的一个"单结构": 结构文件 + 权重 + 相对锚点的偏移 + 旋转 */
    private static final class _M {
        final ResourceLocation id;
        final double weight, ox, oy, oz;
        final int rotation;
        _M(ResourceLocation _i, double _w, double _ox, double _oy, double _oz, int _r) {
            this.id = _i;
            this.weight = _w;
            this.ox = _ox;
            this.oy = _oy;
            this.oz = _oz;
            this.rotation = _r;
        }
    }
    /** 一次群的调用: 外层积木的参数 + 内层积木加进来的成员 */
    private static final class _G {
        final ServerLevel level;
        final double x, y, z, radius, spMin, spMax, sep, hMin, hMax;
        final long seed;
        final int heightmap, heightMode, mode;
        boolean building = false;   // true = 大型单一建筑(只在锚点摆一次, 不按间距铺开)
        int wholeRot = 0;           // 整栋旋转(0~3 个 90°)
        long budgetMs = 3L;         // 每刻落块的时间预算
        final java.util.ArrayList<_M> members = new java.util.ArrayList<>();
        _G(ServerLevel _l, double _x, double _y, double _z, double _r, double _smin, double _smax,
                double _sep, int _hm, int _hmo, double _hmin, double _hmax, int _mode, long _seed) {
            this.level = _l;
            this.x = _x;
            this.y = _y;
            this.z = _z;
            this.radius = _r;
            this.spMin = _smin;
            this.spMax = _smax;
            this.sep = _sep;
            this.heightmap = _hm;
            this.heightMode = _hmo;
            this.hMin = _hmin;
            this.hMax = _hmax;
            this.mode = _mode;
            this.seed = _seed;
        }
    }
    private static final java.util.ArrayList<_G> _groupStack = new java.util.ArrayList<>();
    private static final java.util.HashSet<String> _groupDone = new java.util.HashSet<>();
    /** 结构群: 群里的方块统一进这条队列, 按每刻时间预算落块(不演出) */
    private static final java.util.ArrayList<_Q> _bulk = new java.util.ArrayList<>();
    private static final Heightmap.Types[] _HX_HEIGHTMAPS = new Heightmap.Types[]{
            Heightmap.Types.WORLD_SURFACE, Heightmap.Types.OCEAN_FLOOR,
            Heightmap.Types.MOTION_BLOCKING, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES};

    /**
     * 开一个"结构群". 参数对应 MCreator 结构界面:
     * _radius 范围半径(格); _spMin/_spMax 分布方式的间距最小/最大值(区块); _sep 分离度(区块);
     * _heightmap 地面检测类型(0 地表 / 1 海底 / 2 阻挡方块 / 3 忽略树叶);
     * _heightMode 高度方式(0 贴地 / 1 在高度范围内随机 / 2 固定高度), _hMin/_hMax 高度范围;
     * _mode 0 = 每个生成点从群里随机挑一个, 1 = 每个生成点把整群一起放;
     * _seed 0 = 用世界种子.
     * 生物群系过滤只在"随地图生成"积木上(那里有"生物群系"格子); 结构群想按群系过滤, 用现成的判断积木把它包一层.
     */
    public static void groupBegin(LevelAccessor _a, double _x, double _y, double _z, double _radius,
            double _spMin, double _spMax, double _sep, int _heightmap, int _heightMode,
            double _hMin, double _hMax, int _mode, double _seed) {
        if (!(_a instanceof ServerLevel)) {
            System.out.println("[hxyzg] 结构群: 只在服务端生成, 这次调用被忽略");
            return;
        }
        _groupStack.add(new _G((ServerLevel) _a, _x, _y, _z, _radius, _spMin, _spMax, _sep,
                _heightmap, _heightMode, _hMin, _hMax, _mode, (long) _seed));
    }

    /** 往当前群里加一个单结构(必须写在外层"结构群"积木里面) */
    public static void member(String _id, double _weight, double _ox, double _oy, double _oz, int _rotation) {
        if (_groupStack.isEmpty()) {
            System.out.println("[hxyzg] 结构群: 这个\"单结构\"积木没放在\"结构群\"积木里面, 已忽略: " + _id);
            return;
        }
        ResourceLocation _rid = ResourceLocation.tryParse(_id);
        if (_rid == null) {
            System.out.println("[hxyzg] 结构群: 结构名写错了(要 命名空间:名字): " + _id);
            return;
        }
        _groupStack.get(_groupStack.size() - 1).members.add(
                new _M(_rid, _weight > 0.0 ? _weight : 1.0, _ox, _oy, _oz, _rotation));
    }

    /** 关闭当前群并开始生成 */
    public static void groupStart() {
        if (_groupStack.isEmpty()) return;
        _G _g = _groupStack.remove(_groupStack.size() - 1);
        if (_g.members.isEmpty()) {
            System.out.println("[hxyzg] 结构群: 群里没有\"单结构\"积木, 什么都没生成");
            return;
        }
        if (_g.building) _raise(_g);
        else _spread(_g);
    }

    /** 按间距/分离度挑生成点, 把选中的结构解析出来合并成一条自下而上的队列 */
    private static void _spread(_G _g) {
        ServerLevel _level = _g.level;
        MinecraftServer _srv = _level.getServer();
        if (_srv == null) return;
        long _seed = _g.seed != 0L ? _g.seed : _level.getSeed();
        int _spMin = (int) Math.max(1, Math.min(_g.spMin, _g.spMax));
        int _spMax = (int) Math.max(_spMin, Math.max(_g.spMin, _g.spMax));
        int _sep = (int) Math.max(0, _g.sep);
        double _radius = Math.max(16.0, _g.radius);
        if (_radius > 512.0) {
            String _w = "[hxyzg] 结构群: 半径 " + (int) _radius + " 格偏大(要在这么大范围里逐格找生成点), 一轮会比较慢; "
                    + "建议 512 以内, 或者改用\"随地图生成\"(跟着区块加载走, 不主动加载区块)";
            System.out.println(_w);
            _warn(_level, _w);
        }
        String _key = _level.dimension().location() + "@" + ((long) _g.x) + "," + ((long) _g.z) + "#" + _seed
                + "/" + ((long) _radius) + "x" + _g.members.size();
        if (!_groupDone.add(_key)) {
            System.out.println("[hxyzg] 结构群: 这个位置用同样参数已经生成过了, 跳过");
            return;
        }
        int _cx0 = (int) Math.floor((_g.x - _radius) / 16.0);
        int _cx1 = (int) Math.floor((_g.x + _radius) / 16.0);
        int _cz0 = (int) Math.floor((_g.z - _radius) / 16.0);
        int _cz1 = (int) Math.floor((_g.z + _radius) / 16.0);
        _Q _q = new _Q(_level);
        int _dots = 0, _miss = 0, _skipped = 0, _notLoaded = 0;
        for (int _cxi = _cx0; _cxi <= _cx1; _cxi++) {
            for (int _czi = _cz0; _czi <= _cz1; _czi++) {
                long _h = _mix(_seed, _cxi, _czi);
                // 间距越大越稀: 格子边长 = 间距最小值, 保留概率 = 最小值/最大值
                if (_spMax > _spMin && Math.floorMod(_h >>> 8, 1000L) >= 1000L * _spMin / _spMax) continue;
                int _span = Math.max(1, _spMin - _sep);
                int _chx = _cxi * _spMin + (int) Math.floorMod(_h >>> 24, (long) _span);
                int _chz = _czi * _spMin + (int) Math.floorMod(_h >>> 40, (long) _span);
                double _ax = _chx * 16.0 + 8.0 + (double) (int) Math.floorMod(_h >>> 56, 8L);
                double _az = _chz * 16.0 + 8.0 + (double) (int) Math.floorMod(_h >>> 12, 8L);
                if (Math.abs(_ax - _g.x) > _radius || Math.abs(_az - _g.z) > _radius) continue;
                // 没加载的区块直接跳过: 以前这一步会通过取高度图把区块同步加载/生成出来, 半径大时会一口气加载成百上千个区块
                if (!_level.isLoaded(new BlockPos((int) Math.floor(_ax), 64, (int) Math.floor(_az)))) {
                    _notLoaded++;
                    continue;
                }
                double _ay = _ground(_level, _g, _ax, _az, _h);
                _dots++;
                _M _m = _g.mode == 1 ? null : _pick(_g, _h);
                int _mi0 = 0, _mi1 = _g.members.size() - 1;
                if (_m != null) _mi0 = _mi1 = _g.members.indexOf(_m);
                for (int _mi = _mi0; _mi <= _mi1; _mi++) {
                    _M _mm = _g.members.get(_mi);
                    if (!_put(_level, _srv, _mm, _h, _ax, _ay, _az, _q)) _miss++;
                }
            }
        }
        if (_q.pts.isEmpty()) {
            System.out.println("[hxyzg] 结构群: " + _dots + " 个生成点, 一个方块都没读到 (没读到的结构 " + _miss
                    + " 个" + (_notLoaded > 0 ? ", 未加载区块跳过 " + _notLoaded + " 个点" : "") + ")");
            return;
        }
        _q.sortByY();
        _preloadQ(_level, _q);
        String _info = "结构群 " + _g.members.size() + " 种结构 / " + _dots + " 个生成点 / " + _q.total + " 方块 / "
                + _q.pts.size() + " 份结构, 半径 " + (int) _radius + " 格, 间距 " + _spMin + "~" + _spMax
                + " 区块, 高度方式 " + _g.heightMode
                + (_notLoaded > 0 ? ", 未加载区块跳过 " + _notLoaded + " 个点" : "");
        _addQ(_q, _info);
        System.out.println("[hxyzg] 结构群开始生成: " + _info);
    }

    /** 按权重从群里挑一个成员(确定性: 同一格永远挑同一个) */
    private static _M _pick(_G _g, long _h) {
        double _total = 0.0;
        for (_M _m : _g.members) _total += _m.weight;
        double _r = (double) Math.floorMod(_h >>> 16, 10000L) / 10000.0 * _total;
        double _acc = 0.0;
        for (_M _m : _g.members) {
            _acc += _m.weight;
            if (_r < _acc) return _m;
        }
        return _g.members.get(_g.members.size() - 1);
    }

    /** 生成点的 Y: 贴地(按高度图) / 在高度范围内随机 / 固定高度 */
    private static double _ground(ServerLevel _level, _G _g, double _x, double _z, long _h) {
        if (_g.heightMode == 1) {
            double _lo = Math.min(_g.hMin, _g.hMax), _hi = Math.max(_g.hMin, _g.hMax);
            return _lo + (double) Math.floorMod(_h >>> 30, (long) Math.max(1.0, _hi - _lo + 1.0));
        }
        if (_g.heightMode == 2) return _g.hMin;
        Heightmap.Types _t = _HX_HEIGHTMAPS[Math.max(0, Math.min(_HX_HEIGHTMAPS.length - 1, _g.heightmap))];
        try {
            return (double) _level.getHeightmapPos(_t, BlockPos.containing(_x, 0.0, _z)).getY();
        } catch (Exception _ex) {
            return _g.y;
        }
    }

    /** 区块级确定性哈希(同一世界种子 + 同一格 = 同一结果) */
    private static long _mix(long _seed, int _x, int _z) {
        long _h = _seed * 6364136223846793005L + 1442695040888963407L;
        _h ^= (long) _x * -7046029254386353131L;
        _h = Long.rotateLeft(_h, 31);
        _h ^= (long) _z * -4417276706812531889L;
        _h ^= _h >>> 29;
        _h *= -4658895280553007687L;
        _h ^= _h >>> 32;
        return _h;
    }

    /** 结构群: 每刻最多花 _BULK_MS 毫秒落块, 剩下的下刻继续(不卡主线程) */
    /**
     * 每刻推进所有"无演出"批次: 整趟共用一个时间预算(_BULK_MS), 批次之间轮流各放一组,
     * 避免同一刻有多个生成点同时开时各自吃满预算叠在一起卡顿. 检查粒度是"一组方块"(1 个或一对双格方块).
     */
    private static void _tickBulk(ServerLevel _level) {
        if (_bulk.isEmpty()) return;
        long _deadline = System.nanoTime() + _BULK_MS * 1000000L;
        boolean _any = true;
        while (_any) {
            _any = false;
            for (int _i = _bulk.size() - 1; _i >= 0; _i--) {
                _Q _q = _bulk.get(_i);
                if (_q.level != _level) continue;
                if (_q.ci >= _q.pts.size()) {
                    _bulk.remove(_i);
                    System.out.println("[hxyzg] 结构群生成完成: " + _q.info);
                    continue;
                }
                _stepQ(_level, _q);
                _any = true;
                if (System.nanoTime() >= _deadline) return;
            }
        }
    }
    private static final long _BULK_MS = 3L;

    /**
     * 单个大型结构: 一次摆到位, 无掉落演出, 按每刻时间预算落块(尺寸上限 512x512x512).
     * 和"大型建筑"的区别: 这里只放一个结构文件, 不用在里面放"结构群成员"积木.
     */
    public static void big(LevelAccessor _a, ResourceLocation _id, double _x, double _y, double _z,
            int _rotation, int _mirror, double _budgetMs) {
        if (!(_a instanceof ServerLevel)) {
            System.out.println("[hxyzg] 大型结构: 只在服务端生成, 这次调用被忽略");
            return;
        }
        ServerLevel _level = (ServerLevel) _a;
        MinecraftServer _srv = _level.getServer();
        if (_srv == null) return;
        _C _c = _cached(_level, _srv, _id, _rotation, _mirror);
        if (_c == null) {
            _warn(_level, "[hxyzg] 大型结构: 读不到 " + _id + " (不存在, 或尺寸超过上限)");
            return;
        }
        int _bx = (int) Math.floor(_x), _by = (int) Math.floor(_y), _bz = (int) Math.floor(_z);
        long _budget = (long) Math.max(1.0, Math.min(20.0, _budgetMs));
        int _minX = 0, _maxX = 0, _minZ = 0, _maxZ = 0;
        for (int _i = 0; _i < _c.pos.size(); _i++) {
            BlockPos _p = _c.pos.get(_i);
            if (_i == 0) {
                _minX = _maxX = _p.getX();
                _minZ = _maxZ = _p.getZ();
            } else {
                if (_p.getX() < _minX) _minX = _p.getX();
                if (_p.getX() > _maxX) _maxX = _p.getX();
                if (_p.getZ() < _minZ) _minZ = _p.getZ();
                if (_p.getZ() > _maxZ) _maxZ = _p.getZ();
            }
        }
        // 先把覆盖到的区块加载好(不加载会丢方块), 再排队落块
        int _loaded = 0, _failed = 0;
        for (int _cx = (_bx + _minX - 16) >> 4; _cx <= (_bx + _maxX + 16) >> 4; _cx++) {
            for (int _cz = (_bz + _minZ - 16) >> 4; _cz <= (_bz + _maxZ + 16) >> 4; _cz++) {
                try {
                    _level.getChunk(_cx, _cz);
                    _loaded++;
                } catch (Exception _ex) {
                    _failed++;
                }
            }
        }
        _Q _q = new _Q(_level);
        _q.add(_c, _bx, _by, _bz);
        _q.sortByY();
        String _info = "大型结构 " + _id + " / " + _q.total + " 方块 @ " + _bx + ","
                + _by + "," + _bz + ", 每刻预算 " + _budget + " ms, 预加载 " + _loaded + " 区块"
                + (_failed > 0 ? " (失败 " + _failed + ")" : "");
        _addQ(_q, _info);
        System.out.println("[hxyzg] 大型结构开始生成: " + _info);
    }

    /** 只在"出问题"时在游戏里说话(读不到结构/尺寸超限/超上限); 正常搭建不刷提示 */
    private static void _warn(Level _level, String _text) {
        if (!(_level instanceof ServerLevel)) return;
        try {
            for (ServerPlayer _p : ((ServerLevel) _level).players()) {
                _p.displayClientMessage(Component.literal("§c" + _text), false);
            }
        } catch (Throwable _ex) {
        }
    }

    /** 尺寸检查: 单个结构不能超过 _MAX_SIZE^3(512x512x512), 超了清空并告警(调用方会当成"没读到") */
    private static boolean _sizeOk(ServerLevel _level, ResourceLocation _id, java.util.List<BlockPos> _pos,
            java.util.List<BlockState> _state, java.util.List<CompoundTag> _nbt) {
        if (_pos.isEmpty()) return false;
        int _minX = _pos.get(0).getX(), _maxX = _minX;
        int _minY = _pos.get(0).getY(), _maxY = _minY;
        int _minZ = _pos.get(0).getZ(), _maxZ = _minZ;
        for (int _i = 1; _i < _pos.size(); _i++) {
            BlockPos _p = _pos.get(_i);
            if (_p.getX() < _minX) _minX = _p.getX();
            if (_p.getX() > _maxX) _maxX = _p.getX();
            if (_p.getY() < _minY) _minY = _p.getY();
            if (_p.getY() > _maxY) _maxY = _p.getY();
            if (_p.getZ() < _minZ) _minZ = _p.getZ();
            if (_p.getZ() > _maxZ) _maxZ = _p.getZ();
        }
        int _sx = _maxX - _minX + 1, _sy = _maxY - _minY + 1, _sz = _maxZ - _minZ + 1;
        if (_sx <= _MAX_SIZE && _sy <= _MAX_SIZE && _sz <= _MAX_SIZE) return true;
        String _w = "[hxyzg] 结构 " + _id + " 的尺寸 " + _sx + "x" + _sy + "x" + _sz + " 超过上限 " + _MAX_SIZE
                + "x" + _MAX_SIZE + "x" + _MAX_SIZE + ", 已跳过";
        System.out.println(_w);
        _warn(_level, _w);
        _pos.clear();
        _state.clear();
        _nbt.clear();
        return false;
    }

    /**
     * 双点: 把批次重排成"从两个对角同时往中间长".
     * 层内分别按"离角A(最小x最小z)的对角距离"和"离角B(最大x最大z)的对角距离"各排一遍名次,
     * 然后按两个名次里较小的那个升序交替取 —— 于是两条前沿同时推进、在中间会合; 层与层之间仍是从下往上.
     */
    private static java.util.List<int[]> _orderDual(java.util.List<BlockPos> _pos, java.util.List<int[]> _groups,
            int _minX, int _maxX, int _minZ, int _maxZ) {
        int _n = _groups.size();
        if (_n <= 1) return _groups;
        int[] _gy = new int[_n], _ga = new int[_n], _gb = new int[_n], _ra = new int[_n], _rb = new int[_n];
        for (int _i = 0; _i < _n; _i++) {
            int[] _g = _groups.get(_i);
            int _y = Integer.MAX_VALUE, _a = Integer.MAX_VALUE, _b = Integer.MAX_VALUE;
            for (int _j : _g) {
                BlockPos _p = _pos.get(_j);
                if (_p.getY() < _y) _y = _p.getY();
                int _da = (_p.getX() - _minX) + (_p.getZ() - _minZ);
                int _db = (_maxX - _p.getX()) + (_maxZ - _p.getZ());
                if (_da < _a) _a = _da;
                if (_db < _b) _b = _db;
            }
            _gy[_i] = _y;
            _ga[_i] = _a;
            _gb[_i] = _b;
        }
        // _groups 已经是自下而上的, 同一层是连续的一段: 逐段排两个名次
        java.util.ArrayList<Integer> _sa = new java.util.ArrayList<>();
        java.util.ArrayList<Integer> _sb = new java.util.ArrayList<>();
        int _i0 = 0;
        while (_i0 < _n) {
            int _i1 = _i0 + 1;
            while (_i1 < _n && _gy[_i1] == _gy[_i0]) _i1++;
            _sa.clear();
            _sb.clear();
            for (int _i = _i0; _i < _i1; _i++) {
                _sa.add(Integer.valueOf(_i));
                _sb.add(Integer.valueOf(_i));
            }
            final int[] _fav = _ga;
            _sa.sort((_p, _q) -> Integer.compare(_fav[_p.intValue()], _fav[_q.intValue()]));
            for (int _k = 0; _k < _sa.size(); _k++) _ra[_sa.get(_k).intValue()] = _k;
            final int[] _fbv = _gb;
            _sb.sort((_p, _q) -> Integer.compare(_fbv[_p.intValue()], _fbv[_q.intValue()]));
            for (int _k = 0; _k < _sb.size(); _k++) _rb[_sb.get(_k).intValue()] = _k;
            _i0 = _i1;
        }
        Integer[] _ord = new Integer[_n];
        for (int _i = 0; _i < _n; _i++) _ord[_i] = Integer.valueOf(_i);
        final int[] _fy = _gy, _fra = _ra, _frb = _rb;
        java.util.Arrays.sort(_ord, (_p, _q) -> {
            int _i = _p.intValue(), _j = _q.intValue();
            if (_fy[_i] != _fy[_j]) return Integer.compare(_fy[_i], _fy[_j]);
            int _mi = Math.min(_fra[_i], _frb[_i]);
            int _mj = Math.min(_fra[_j], _frb[_j]);
            if (_mi != _mj) return Integer.compare(_mi, _mj);
            int _si = _fra[_i] <= _frb[_i] ? 0 : 1;
            int _sj = _fra[_j] <= _frb[_j] ? 0 : 1;
            return Integer.compare(_si, _sj);
        });
        java.util.List<int[]> _out = new java.util.ArrayList<>(_n);
        for (int _i = 0; _i < _n; _i++) _out.add(_groups.get(_ord[_i].intValue()));
        return _out;
    }

    /** 推进一个"带掉落演出"的搭建任务; 返回 true 表示已经搭完 */
    private static boolean _stepAnim(ServerLevel _level, _B _b) {
        if (_b.at >= _b.groups.size()) return true;
        _b.acc += _b.perTick;
        int _n = (int) _b.acc;
        _b.acc -= (double) _n;
        if (_n <= 0 && _b.at == 0) _n = 1;   // 第一批立刻开始, 免得速度填得小看起来像没反应
        for (int _k = 0; _k < _n && _b.at < _b.groups.size(); _k++) {
            _emit(_level, _b, _b.groups.get(_b.at));
            _b.at++;
        }
        return _b.at >= _b.groups.size();
    }

    private static Rotation _toRotation(int _r) {

        switch (_r) {
            case 1: return Rotation.CLOCKWISE_90;
            case 2: return Rotation.CLOCKWISE_180;
            case 3: return Rotation.COUNTERCLOCKWISE_90;
            default: return Rotation.NONE;
        }
    }
    private static Mirror _toMirror(int _m) {
        switch (_m) {
            case 1: return Mirror.LEFT_RIGHT;
            case 2: return Mirror.FRONT_BACK;
            default: return Mirror.NONE;
        }
    }
    private static StructurePlaceSettings _settings(int _rotation, int _mirror) {
        return new StructurePlaceSettings().setRotation(_toRotation(_rotation)).setMirror(_toMirror(_mirror))
                .setIgnoreEntities(true);
    }
