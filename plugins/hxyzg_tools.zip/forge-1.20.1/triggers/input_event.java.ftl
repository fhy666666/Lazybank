<#include "procedures.java.ftl">
@Mod.EventBusSubscriber(value={Dist.CLIENT}) public class ${name}Procedure {
	@SubscribeEvent public static void onInputEvent(InputEvent.Key event) {
		<#assign dependenciesCode><#compress>
					<@procedureDependenciesCode dependencies, {
						"entity": "Minecraft.getInstance().player",
						"world": "Minecraft.getInstance().level",
						"event": "event"
						}/>
		</#compress></#assign>
		execute(event<#if dependenciesCode?has_content>,</#if>${dependenciesCode});
	}
	@SubscribeEvent public static void onInputEvent(InputEvent.MouseButton event) {
		<#assign dependenciesCode><#compress>
					<@procedureDependenciesCode dependencies, {
						"entity": "Minecraft.getInstance().player",
						"world": "Minecraft.getInstance().level",
						"event": "event"
						}/>
		</#compress></#assign>
		execute(event<#if dependenciesCode?has_content>,</#if>${dependenciesCode});
	}
	@SubscribeEvent public static void onInputEvent(InputEvent.MouseScrollingEvent event) {
		<#assign dependenciesCode><#compress>
					<@procedureDependenciesCode dependencies, {
						"entity": "Minecraft.getInstance().player",
						"world": "Minecraft.getInstance().level",
						"event": "event"
						}/>
		</#compress></#assign>
		execute(event<#if dependenciesCode?has_content>,</#if>${dependenciesCode});
	}
