<#include "procedures.java.ftl">
@Mod.EventBusSubscriber(value={Dist.CLIENT}) public class ${name}Procedure {
	@SubscribeEvent public static void onRenderTick(RenderTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			ClientLevel level = Minecraft.getInstance().level;
		<#assign dependenciesCode><#compress>
			<@procedureDependenciesCode dependencies, {
				"world": "level",
				"event": "event"
				}/>
		</#compress></#assign>
		execute(event<#if dependenciesCode?has_content>,</#if>${dependenciesCode});
		}
	}
