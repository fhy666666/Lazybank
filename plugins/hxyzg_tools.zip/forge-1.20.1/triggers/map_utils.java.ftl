<#include "procedures.java.ftl">
@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD) public class ${name}Procedure {
    public static void createTargetMap(ServerLevel level, Player player, BlockPos targetPos, String mapName, byte scale, int mapColor) {
        // 1. 创建地图（自动初始化 NBT 和地图数据）
        ItemStack mapStack = MapItem.create(level, targetPos.getX(), targetPos.getZ(), scale, true, true);

        // 2. 获取地图 ID
        Integer mapId = MapItem.getMapId(mapStack);
        if (mapId == null) return;

        // 3. 通过 ID 获取 MapItemSavedData（Minecraft 自动管理）
        MapItemSavedData mapData = MapItem.getSavedData(mapId, level);
        if (mapData == null) return;

        // 4. 添加红叉标记（注意：第一个参数是 ItemStack，传 mapStack 即可）
        mapData.addTargetDecoration(mapStack, targetPos, "target", MapDecoration.Type.RED_X);

        // 5. 设置地图名称
        mapStack.setHoverName(Component.literal(mapName));

        CompoundTag tag = mapStack.getOrCreateTag();
        CompoundTag displayTag = tag.getCompound("display");
        if (!displayTag.contains("MapColor")) {
            displayTag.putInt("MapColor", mapColor);
        }
        tag.put("display", displayTag);

        // 6. 给予玩家
        if (!player.getInventory().add(mapStack)) {
            player.drop(mapStack, false);
        }
    }