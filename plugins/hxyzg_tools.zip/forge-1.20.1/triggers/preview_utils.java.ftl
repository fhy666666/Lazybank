<#include "procedures.java.ftl">
@Mod.EventBusSubscriber(Dist.CLIENT) public class ${name}Procedure {
    private static final Direction[] _pvDirs = new Direction[]{Direction.DOWN, Direction.UP, Direction.NORTH,
            Direction.SOUTH, Direction.WEST, Direction.EAST};
    private static final int _PV_MAX = 4000;
    /**
     * 一整套预览数据。show() 可能在客户端线程, 也可能在单人存档的服务端线程被调用,
     * 所以这里先在局部变量里全部算好, 最后一次性发布(volatile 引用), 渲染线程只会看到完整状态。
     * 光照/色调/满方块判断这些只能在渲染线程做的缓存, 一律不进这里。
     */
    private static final class _Pv {
        final java.util.List<BlockPos> pos;
        final java.util.List<BlockState> state;
        final double x, y, z;
        final int sx, sy, sz;
        final String info;
        _Pv(java.util.List<BlockPos> _p, java.util.List<BlockState> _s, double _px0, double _py0, double _pz0,
                int _sx0, int _sy0, int _sz0, String _info0) {
            this.pos = _p;
            this.state = _s;
            this.x = _px0; this.y = _py0; this.z = _pz0;
            this.sx = _sx0; this.sy = _sy0; this.sz = _sz0;
            this.info = _info0;
        }
    }
    private static volatile _Pv _pv = null;
    private static volatile double _pvAlpha = 0.8;
    private static volatile boolean _pvShell = true;
    /** 下面这些缓存只在渲染线程里申请与填充(以前 show() 里填, 于是渲染线程会读到空数组 -> 越界崩溃) */
    private static int[] _pvLight = new int[0];
    private static int[] _pvTint = new int[0];
    private static boolean[] _pvCube = new boolean[0];
    private static final java.util.HashMap<Long, Boolean> _pvFull = new java.util.HashMap<>();
    private static long _pvLightAt = -100L;
    private static int _pvFrames = 0;

    /** 预览外观: 不透明度 0~100, 是否只画外壳(去掉被完全埋住的满方块, 也不画被满方块挡住的面) */
    public static void setStyle(int _alphaPercent, boolean _shell) {
        _pvAlpha = _alphaPercent <= 0 ? 0.05 : (_alphaPercent >= 100 ? 1.0 : (double) _alphaPercent / 100.0);
        _pvShell = _shell;
    }
    /** 上一次预览的结果说明(含已渲染帧数); 没显示出来时先看它 */
    public static String info() {
        _Pv _v = _pv;
        if (_v == null) return "结构预览: 未启用(还没调用预览积木)";
        return _v.info + " | 不透明度 " + (int) (_pvAlpha * 100.0) + "%" + (_pvShell ? " 只画外壳" : " 全部方块")
                + " | 已渲染 " + _pvFrames + " 帧";
    }
    public static void show(ResourceLocation _id, double _x, double _y, double _z, int _rotation, int _mirror) {
        Minecraft _mc = Minecraft.getInstance();
        java.util.List<BlockPos> _pos = new java.util.ArrayList<>();
        java.util.List<BlockState> _states = new java.util.ArrayList<>();
        int _ox = 0, _oy = 0, _oz = 0;
        String _info = "结构预览: 没有读到任何东西";
        _pvFrames = 0;
        do {
            if (_mc.level == null) {
                _info = "结构预览: 客户端还没进入世界";
                break;
            }
            CompoundTag _tag = null;
            String _from = "没找到结构文件";
            MinecraftServer _srv = _mc.getSingleplayerServer();
            // 1) 直接读数据包里的结构文件: MCreator 1.20.1/1.21.1 写 data/<命名空间>/structures/<名字>.nbt
            if (_srv != null) {
                String[] _dirs = new String[]{"structures/", "structure/"};
                for (int _d = 0; _d < _dirs.length && _tag == null; _d++) {
                    ResourceLocation _file = _id.withPrefix(_dirs[_d]).withSuffix(".nbt");
                    try {
                        java.util.Optional<Resource> _res = _srv.getResourceManager().getResource(_file);
                        if (_res.isPresent()) {
                            try (InputStream _in = _res.get().open()) {
                                CompoundTag _t = NbtIo.readCompressed(_in);
                                if (_t.getList("blocks", 10).size() > 0 || _t.getList("palette", 10).size() > 0
                                        || _t.getList("palettes", 9).size() > 0) {
                                    _tag = _t;
                                    _from = "文件 " + _file;
                                }
                            }
                        }
                    } catch (Exception _ex) {
                        _from = _file + " 读取出错(" + _ex.getClass().getSimpleName() + ")";
                    }
                }
            }
            // 2) 退路: 服务端结构管理器(存档里的结构 / 需要数据修复的老格式)
            if (_tag == null && _srv != null) {
                try {
                    StructureTemplate _tpl = _srv.getStructureManager().get(_id).orElse(null);
                    if (_tpl != null) {
                        CompoundTag _t = _tpl.save(new CompoundTag());
                        if (_t.getList("blocks", 10).size() > 0) {
                            _tag = _t;
                            _from = "结构管理器";
                        }
                    }
                } catch (Exception _ex) {
                    _from = "结构管理器出错(" + _ex.getClass().getSimpleName() + ")";
                }
            }
            if (_tag == null) {
                if (_srv == null) {
                    _info = "结构预览: 拿不到服务端(纯客户端/别人的服务器), 结构文件只在服务端数据包里有 " + _id;
                    break;
                }
                StringBuilder _sb = new StringBuilder();
                try {
                    _srv.getStructureManager().listTemplates().limit(8).forEach(_r -> _sb.append(_r).append(' '));
                } catch (Exception _ex) {
                }
                _info = "结构预览: 找不到 " + _id + " (" + _from + ") 服务端已知的结构: "
                        + (_sb.length() == 0 ? "(一个都没有)" : _sb.toString());
                break;
            }
            int _total = 0;
            try {
                ListTag _sizeTag = _tag.getList("size", 3);
                if (_sizeTag.size() >= 3) {
                    _ox = _sizeTag.getInt(0);
                    _oy = _sizeTag.getInt(1);
                    _oz = _sizeTag.getInt(2);
                }
                // 方块表固定挂在根上; 调色板是根 palette(单套) 或根 palettes(多套, 每个元素是一张状态表)
                ListTag _blocks = _tag.getList("blocks", 10);
                ListTag _palette = _tag.getList("palette", 10);
                if (_palette.size() <= 0) {
                    ListTag _pals = _tag.getList("palettes", 9);
                    if (_pals.size() > 0) _palette = _pals.getList(0);
                }
                if (_palette.size() <= 0) {
                    _info = "结构预览: " + _id + " 的调色板是空的 (" + _from + ")";
                    break;
                }
                StructurePlaceSettings _set = _settings(_rotation, _mirror);
                for (int _i = 0; _i < _blocks.size(); _i++) {
                    CompoundTag _b = _blocks.getCompound(_i);
                    int _si = _b.getInt("state");
                    if (_si < 0 || _si >= _palette.size()) continue;
                    BlockState _st = NbtUtils.readBlockState(_mc.level.holderLookup(Registries.BLOCK),
                            _palette.getCompound(_si));
                    if (_st.isAir()) continue;
                    int[] _ip = _posOf(_b);
                    if (_ip.length < 3) continue;
                    _pos.add(StructureTemplate.calculateRelativePosition(_set, new BlockPos(_ip[0], _ip[1], _ip[2])));
                    _states.add(_st.mirror(_toMirror(_mirror)).rotate(_toRotation(_rotation)));
                    _total++;
                }
            } catch (Exception _ex) {
                _pos.clear();
                _states.clear();
                _info = "结构预览: 解析 " + _id + " 出错 (" + _ex + ")";
                break;
            }
            if (_states.isEmpty()) {
                _info = "结构预览: " + _id + " 里没有可显示的方块 (" + _from + ")";
                break;
            }
            String _tail = "";
            if (_states.size() > _PV_MAX) {
                int _step = _states.size() / _PV_MAX + 1;
                for (int _i = _states.size() - 1; _i >= 0; _i--) {
                    if (_i % _step != 0) {
                        _pos.remove(_i);
                        _states.remove(_i);
                    }
                }
                _tail = " (方块多, 抽样显示 " + _states.size() + "/" + _total + ")";
            }
            if (_x == 0.0 && _y == 0.0 && _z == 0.0) {
                _tail = _tail + " [坐标是 0,0,0: 取坐标的射线多半没打中方块]";
            }
            _info = "结构预览: " + _id + " 尺寸 " + _ox + "x" + _oy + "x" + _oz + " 方块 " + _total
                    + " 位置 " + (int) _x + "," + (int) _y + "," + (int) _z + " [来源 " + _from + "]" + _tail;
            System.out.println("[hxyzg] " + _info);
        } while (false);
        _pv = new _Pv(_pos, _states, _x, _y, _z, _ox, _oy, _oz, _info);
    }
    /** StructureTemplate 写的是 List<Int>, 也有写入器用 IntArray, 两种都收 */
    private static int[] _posOf(CompoundTag _b) {
        int[] _a = _b.getIntArray("pos");
        if (_a.length >= 3) return _a;
        ListTag _l = _b.getList("pos", 3);
        if (_l.size() >= 3) return new int[]{_l.getInt(0), _l.getInt(1), _l.getInt(2)};
        return new int[0];
    }
    public static void hide() {
        _pv = null;
        _pvFrames = 0;
        _pvLightAt = -100L;
    }
    public static boolean isShowing() {
        _Pv _v = _pv;
        return _v != null && !_v.state.isEmpty();
    }
    public static double sizeX() {
        _Pv _v = _pv;
        return _v == null ? 0.0 : (double) _v.sx;
    }
    public static double sizeY() {
        _Pv _v = _pv;
        return _v == null ? 0.0 : (double) _v.sy;
    }
    public static double sizeZ() {
        _Pv _v = _pv;
        return _v == null ? 0.0 : (double) _v.sz;
    }
    /** 只能在渲染线程调用: 光照/群系色调/是不是满方块 */
    private static void _refreshPreviewLight(_Pv _v) {
        Minecraft _mc = Minecraft.getInstance();
        if (_mc.level == null) return;
        int _n = _v.state.size();
        if (_pvLight.length != _n) {
            _pvLight = new int[_n];
            _pvTint = new int[_n];
            _pvCube = new boolean[_n];
        }
        _pvFull.clear();
        for (int _i = 0; _i < _n; _i++) {
            BlockPos _lp = _v.pos.get(_i);
            BlockPos _wp = BlockPos.containing(_v.x + (double) _lp.getX(), _v.y + (double) _lp.getY(),
                    _v.z + (double) _lp.getZ());
            BlockState _st = _v.state.get(_i);
            _pvLight[_i] = LevelRenderer.getLightColor(_mc.level, _st, _wp);
            _pvTint[_i] = _mc.getBlockColors().getColor(_st, _mc.level, _wp, 0);
            try {
                // 台阶/楼梯/栅栏/玻璃板这类"不完整方块"这里是 false -> 永不被剔除
                _pvCube[_i] = _st.isCollisionShapeFullBlock(_mc.level, _wp);
            } catch (Exception _ex) {
                _pvCube[_i] = false;
            }
            _pvFull.put(_lp.asLong(), _pvCube[_i]);
        }
        _pvLightAt = _mc.level.getGameTime();
    }
    private static Rotation _toRotation(int _r) {
        switch (_r) {
            case 1: return Rotation.CLOCKWISE_90;
            case 2: return Rotation.CLOCKWISE_180;
            case 3: return Rotation.COUNTERCLOCKWISE_90;
            default: return Rotation.NONE;
        }
    }
    private static Mirror _toMirror(int _m) {
        switch (_m) {
            case 1: return Mirror.LEFT_RIGHT;
            case 2: return Mirror.FRONT_BACK;
            default: return Mirror.NONE;
        }
    }
    private static StructurePlaceSettings _settings(int _rotation, int _mirror) {
        return new StructurePlaceSettings().setRotation(_toRotation(_rotation)).setMirror(_toMirror(_mirror))
                .setIgnoreEntities(true);
    }
    @SubscribeEvent public static void onRenderLevel(RenderLevelStageEvent event) {
        final _Pv _v = _pv;
        if (_v == null) return;
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        _pvFrames++;
        Minecraft _mc = Minecraft.getInstance();
        if (_mc.level == null) return;
        Vec3 _camera = event.getCamera().getPosition();
        PoseStack _pose = event.getPoseStack();
        MultiBufferSource.BufferSource _buffers = _mc.renderBuffers().bufferSource();
        int _n = _v.state.size();
        if (_n <= 0) {
            // 没加载出来: 在目标坐标摆一个红色玻璃空壳. 看得到它=渲染通(原因看信息积木), 连它都没有=事件没跑到
            VertexConsumer _mark = _buffers.getBuffer(RenderType.translucent());
            BlockState _markState = Blocks.RED_STAINED_GLASS.defaultBlockState();
            BakedModel _markModel = _mc.getBlockRenderer().getBlockModel(_markState);
            float[] _mw = new float[]{1.0F, 1.0F, 1.0F, 1.0F};
            int[] _ml = new int[]{15728880, 15728880, 15728880, 15728880};
            RandomSource _mr = RandomSource.create(42L);
            for (int _mx = -1; _mx <= 1; _mx++) {
                for (int _my = -1; _my <= 1; _my++) {
                    for (int _mz = -1; _mz <= 1; _mz++) {
                        if (_mx == 0 && _my == 0 && _mz == 0) continue;
                        _pose.pushPose();
                        _pose.translate(_v.x + (double) _mx - _camera.x, _v.y + (double) _my - _camera.y,
                                _v.z + (double) _mz - _camera.z);
                        PoseStack.Pose _mp = _pose.last();
                        for (int _d = 0; _d < _pvDirs.length; _d++) {
                            for (BakedQuad _q : _markModel.getQuads(_markState, _pvDirs[_d], _mr)) {
                                _mark.putBulkData(_mp, _q, _mw, 1.0F, 0.25F, 0.25F, 0.5F, _ml,
                                        OverlayTexture.NO_OVERLAY, false);
                            }
                        }
                        for (BakedQuad _q : _markModel.getQuads(_markState, null, _mr)) {
                            _mark.putBulkData(_mp, _q, _mw, 1.0F, 0.25F, 0.25F, 0.5F, _ml,
                                    OverlayTexture.NO_OVERLAY, false);
                        }
                        _pose.popPose();
                    }
                }
            }
            _buffers.endBatch(RenderType.translucent());
            return;
        }
        // 光照/色调/满方块表: 只在这里(渲染线程)算, 所以不可能读到半成品
        if (_pvLight.length != _n || _mc.level.getGameTime() - _pvLightAt > 20L) _refreshPreviewLight(_v);
        VertexConsumer _vc = _buffers.getBuffer(RenderType.translucent());
        float[] _white = new float[]{1.0F, 1.0F, 1.0F, 1.0F};
        RandomSource _rand = RandomSource.create(42L);
        float _alpha = (float) _pvAlpha;
        boolean _shell = _pvShell;
        for (int _i = 0; _i < _n; _i++) {
            BlockState _st = _v.state.get(_i);
            BlockPos _lp = _v.pos.get(_i);
            // 只画外壳: 只有"自己就是满方块 + 六个邻居也全是满方块"才跳过.
            // 台阶/楼梯/栅栏这类不完整方块永远不跳(否则会整块不显示)
            if (_shell && _i < _pvCube.length && _pvCube[_i]) {
                boolean _buried = true;
                for (int _d = 0; _d < _pvDirs.length; _d++) {
                    if (!Boolean.TRUE.equals(_pvFull.get(_lp.relative(_pvDirs[_d]).asLong()))) {
                        _buried = false;
                        break;
                    }
                }
                if (_buried) continue;
            }
            _pose.pushPose();
            _pose.translate(_v.x + (double) _lp.getX() - _camera.x, _v.y + (double) _lp.getY() - _camera.y,
                    _v.z + (double) _lp.getZ() - _camera.z);
            PoseStack.Pose _last = _pose.last();
            if (_st.getRenderShape() == RenderShape.MODEL) {
                BakedModel _model = _mc.getBlockRenderer().getBlockModel(_st);
                int _tint = _i < _pvTint.length ? _pvTint[_i] : -1;
                float _r = (float) (_tint >> 16 & 255) / 255.0F;
                float _g = (float) (_tint >> 8 & 255) / 255.0F;
                float _b = (float) (_tint & 255) / 255.0F;
                int _light = _i < _pvLight.length ? _pvLight[_i] : 15728880;
                int[] _lights = new int[]{_light, _light, _light, _light};
                for (int _d = 0; _d < _pvDirs.length; _d++) {
                    // 只有邻居是"满方块"时才剔这一面: 邻居是台阶/楼梯/栅栏时, 这一面其实露在外面
                    if (_shell && Boolean.TRUE.equals(_pvFull.get(_lp.relative(_pvDirs[_d]).asLong()))) continue;
                    for (BakedQuad _q : _model.getQuads(_st, _pvDirs[_d], _rand)) {
                        _vc.putBulkData(_last, _q, _white, _r, _g, _b, _alpha, _lights, OverlayTexture.NO_OVERLAY, false);
                    }
                }
                for (BakedQuad _q : _model.getQuads(_st, null, _rand)) {
                    _vc.putBulkData(_last, _q, _white, _r, _g, _b, _alpha, _lights, OverlayTexture.NO_OVERLAY, false);
                }
            }
            _pose.popPose();
        }
        // 箱子/告示牌/床这类要由方块实体渲染器画的: 这里至少把方块模型本身画出来(不透明),
        // 否则它们在预览里会整块消失. 单独一趟画, 免得多取渲染类型打断幽灵那一批几何
        for (int _i = 0; _i < _n; _i++) {
            BlockState _st = _v.state.get(_i);
            if (_st.getRenderShape() != RenderShape.ENTITYBLOCK_ANIMATED) continue;
            BlockPos _lp = _v.pos.get(_i);
            _pose.pushPose();
            _pose.translate(_v.x + (double) _lp.getX() - _camera.x, _v.y + (double) _lp.getY() - _camera.y,
                    _v.z + (double) _lp.getZ() - _camera.z);
            try {
                _mc.getBlockRenderer().renderSingleBlock(_st, _pose, _buffers,
                        _i < _pvLight.length ? _pvLight[_i] : 15728880, OverlayTexture.NO_OVERLAY);
            } catch (Exception _ex) {
            }
            _pose.popPose();
        }
        _buffers.endBatch(RenderType.translucent());
    }

// ===== HX_SYNC: 本工具类的渲染同步重放注册(只在客户端加载时执行一次) =====
static {
	RegPacketProcedure.hxRegister("preview.show", _d -> { net.minecraft.resources.ResourceLocation _rl = net.minecraft.resources.ResourceLocation.tryParse(RegPacketProcedure.hxS(_d, "s0")); if (_rl != null) show(_rl, RegPacketProcedure.hxN(_d, "a0"), RegPacketProcedure.hxN(_d, "a1"), RegPacketProcedure.hxN(_d, "a2"), RegPacketProcedure.hxI(_d, "a3"), RegPacketProcedure.hxI(_d, "a4")); });
	RegPacketProcedure.hxRegister("preview.hide", _d -> hide());
	RegPacketProcedure.hxRegister("preview.style", _d -> setStyle(RegPacketProcedure.hxI(_d, "a0"), RegPacketProcedure.hxB(_d, "a1")));
}
