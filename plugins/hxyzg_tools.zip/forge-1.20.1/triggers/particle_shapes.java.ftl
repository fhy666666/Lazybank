<#include "procedures.java.ftl">
public class ${name}Procedure {

    private static void _p(LevelAccessor _a, ParticleOptions _particle, double _x, double _y, double _z) {
        if (_a instanceof Level _level) _level.addParticle(_particle, _x, _y, _z, 0.0, 0.0, 0.0);
    }
    public static void shape(LevelAccessor _a, String _shape, double _x, double _y, double _z, double _radius,
            ParticleOptions _particle, int _count) {
        if (_particle == null || _count <= 0) return;
        double _r = _radius <= 0.0 ? 0.5 : _radius;
        int _n = _count > 1500 ? 1500 : _count;
        for (int _i = 0; _i < _n; _i++) {
            double _t = _n <= 1 ? 0.0 : (double) _i / (double) (_n - 1);
            double _px = _x, _py = _y, _pz = _z;
            if ("SHELL".equals(_shape)) {
                double _phi = Math.acos(1.0 - 2.0 * _t);
                double _theta = Math.PI * (1.0 + Math.sqrt(5.0)) * (double) _i;
                _px += Math.cos(_theta) * Math.sin(_phi) * _r;
                _py += Math.cos(_phi) * _r;
                _pz += Math.sin(_theta) * Math.sin(_phi) * _r;
            } else if ("FILLED".equals(_shape)) {
                double _phi = Math.acos(1.0 - 2.0 * _t);
                double _theta = Math.PI * (1.0 + Math.sqrt(5.0)) * (double) _i;
                double _rr = _r * Math.cbrt(Math.random());
                _px += Math.cos(_theta) * Math.sin(_phi) * _rr;
                _py += Math.cos(_phi) * _rr;
                _pz += Math.sin(_theta) * Math.sin(_phi) * _rr;
            } else if ("RING".equals(_shape)) {
                double _ang = _t * Math.PI * 2.0;
                _px += Math.cos(_ang) * _r;
                _pz += Math.sin(_ang) * _r;
            } else if ("DISC".equals(_shape)) {
                double _ang = _t * Math.PI * 2.0;
                double _rr = _r * Math.sqrt(_t);
                _px += Math.cos(_ang) * _rr;
                _pz += Math.sin(_ang) * _rr;
            } else if ("SPIRAL".equals(_shape)) {
                double _ang = _t * Math.PI * 6.0;
                _px += Math.cos(_ang) * _r * _t;
                _pz += Math.sin(_ang) * _r * _t;
            } else if ("HELIX".equals(_shape)) {
                double _ang = _t * Math.PI * 6.0;
                _px += Math.cos(_ang) * _r;
                _pz += Math.sin(_ang) * _r;
                _py += _t * _r * 2.0;
            } else if ("CONE".equals(_shape)) {
                double _ang = _t * Math.PI * 8.0;
                double _rr = _r * _t;
                _px += Math.cos(_ang) * _rr;
                _pz += Math.sin(_ang) * _rr;
                _py += _t * _r * 2.0;
            } else if ("CUBE".equals(_shape)) {
                int _perEdge = Math.max(1, _n / 12);
                int _edge = Math.min(11, _i / _perEdge);
                double _f = (double) (_i % _perEdge) / (double) _perEdge;
                double _a1 = _r, _b1 = -_r, _d1 = 2.0 * _r * _f;
                switch (_edge) {
                    case 0: _px += _b1 + _d1; _py += _b1; _pz += _b1; break;
                    case 1: _px += _a1; _py += _b1; _pz += _b1 + _d1; break;
                    case 2: _px += _a1 - _d1; _py += _b1; _pz += _a1; break;
                    case 3: _px += _b1; _py += _b1; _pz += _a1 - _d1; break;
                    case 4: _px += _b1 + _d1; _py += _a1; _pz += _b1; break;
                    case 5: _px += _a1; _py += _a1; _pz += _b1 + _d1; break;
                    case 6: _px += _a1 - _d1; _py += _a1; _pz += _a1; break;
                    case 7: _px += _b1; _py += _a1; _pz += _a1 - _d1; break;
                    case 8: _px += _b1; _py += _b1 + _d1; _pz += _b1; break;
                    case 9: _px += _a1; _py += _b1 + _d1; _pz += _b1; break;
                    case 10: _px += _a1; _py += _b1 + _d1; _pz += _a1; break;
                    default: _px += _b1; _py += _b1 + _d1; _pz += _a1; break;
                }
            } else {
                double _phi = Math.acos(1.0 - 2.0 * _t);
                double _theta = Math.PI * (1.0 + Math.sqrt(5.0)) * (double) _i;
                _px += Math.cos(_theta) * Math.sin(_phi) * _r;
                _py += Math.cos(_phi) * _r;
                _pz += Math.sin(_theta) * Math.sin(_phi) * _r;
            }
            _p(_a, _particle, _px, _py, _pz);
        }
    }
    public static void line(LevelAccessor _a, double _x1, double _y1, double _z1, double _x2, double _y2, double _z2,
            ParticleOptions _particle, int _count) {
        if (_particle == null || _count <= 0) return;
        int _n = _count > 1500 ? 1500 : _count;
        for (int _i = 0; _i < _n; _i++) {
            double _t = _n <= 1 ? 0.0 : (double) _i / (double) (_n - 1);
            _p(_a, _particle, _x1 + (_x2 - _x1) * _t, _y1 + (_y2 - _y1) * _t, _z1 + (_z2 - _z1) * _t);
        }
    }
    public static void cone(LevelAccessor _a, double _x, double _y, double _z, double _dx, double _dy, double _dz,
            double _length, double _angleDegrees, ParticleOptions _particle, int _count) {
        if (_particle == null || _count <= 0) return;
        double _len = Math.sqrt(_dx * _dx + _dy * _dy + _dz * _dz);
        if (_len < 1.0E-6) return;
        _dx /= _len; _dy /= _len; _dz /= _len;
        double _cosLimit = Math.cos(Math.toRadians(_angleDegrees < 0.0 ? 0.0 : (_angleDegrees > 180.0 ? 180.0 : _angleDegrees)));
        int _n = _count > 1500 ? 1500 : _count;
        for (int _i = 0; _i < _n; _i++) {
            double _u = Math.random() * 2.0 - 1.0;
            double _theta = Math.random() * Math.PI * 2.0;
            double _s = Math.sqrt(1.0 - _u * _u);
            double _rx = _s * Math.cos(_theta), _ry = _s * Math.sin(_theta), _rz = _u;
            double _dot = _rx * _dx + _ry * _dy + _rz * _dz;
            if (_dot < _cosLimit) continue;
            double _dist = _length * Math.cbrt(Math.random());
            _p(_a, _particle, _x + _rx * _dist, _y + _ry * _dist, _z + _rz * _dist);
        }
    }
