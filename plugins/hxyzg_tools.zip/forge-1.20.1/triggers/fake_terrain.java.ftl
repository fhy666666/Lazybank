<#include "procedures.java.ftl">
@Mod.EventBusSubscriber(Dist.CLIENT) public class ${name}Procedure {
    /** 渲染条目: 0 翘起弧度, 1/2 翘起轴, 3 所属组, 4 显示 Y 偏移, 5 是否盖了屏障 */
    private static final java.util.ArrayList<double[]> _ftE = new java.util.ArrayList<>();
    /** 条目命中的方块坐标(与 _ftE 一一对应): 位置只认这一份, Y 偏移只用于渲染, 永远不参与隐藏/还原 */
    private static final java.util.ArrayList<BlockPos> _ftP = new java.util.ArrayList<>();
    /** 条目的渲染状态(与 _ftE 一一对应) */
    private static final java.util.ArrayList<BlockState> _ftS = new java.util.ArrayList<>();
    /** 每组: 0 寿命(刻), 1 起始刻, 2 是否隐藏原方块 */
    private static final java.util.ArrayList<double[]> _ftG = new java.util.ArrayList<>();
    /** 被盖住的方块位置 -> 真正的原方块(同一个位置只记一次, 多个组共用同一条记录) */
    private static final java.util.HashMap<BlockPos, BlockState> _ftH = new java.util.HashMap<>();
    /** 被盖住的方块位置 -> 原方块实体数据(告示牌文字/旗帜图案/箱子内容等) */
    private static final java.util.HashMap<BlockPos, CompoundTag> _ftN = new java.util.HashMap<>();
    /** 被盖住的方块位置 -> 还盖着它的组数(引用计数, 减到 0 才把原方块放回去) */
    private static final java.util.HashMap<BlockPos, int[]> _ftC = new java.util.HashMap<>();
    /** 这些记录属于哪个客户端世界: 换维度/重进世界后旧记录一律作废, 绝不再往新世界写方块 */
    private static Level _ftL;
    /** 保险丝: 最多同时留这么多条碎块记录, 超了先把最早的一组立刻还原 */
    private static final int _FT_MAX = 30000;

    /** 只清记录, 不碰世界(换世界 / 离开世界 / 记录已作废时用) */
    private static void _ftClear() {
        _ftE.clear();
        _ftP.clear();
        _ftS.clear();
        _ftG.clear();
        _ftH.clear();
        _ftN.clear();
        _ftC.clear();
        _ftL = null;
    }

    /** 把记录绑到当前客户端世界; 换了世界就把旧记录整份丢掉(旧世界的客户端区块已经没了, 不能往新世界写方块) */
    private static void _ftBind(Level _level) {
        if (_ftL == _level) return;
        _ftClear();
        _ftL = _level;
    }

    /** 开一个新组; 记录太多时先把最早的一组立刻还原, 免得反复调用越积越多 */
    private static int _ftNewGroup(Level _level, int _ticks, boolean _hide) {
        while (_ftE.size() >= _FT_MAX) {
            int _old = -1;
            for (int _i = 0; _i < _ftG.size(); _i++)
                if (_ftG.get(_i)[0] > 0.0) { _old = _i; break; }
            if (_old < 0) break;
            _restoreGroup(_level, _old);
        }
        int _g = _ftG.size();
        _ftG.add(new double[] { (double) Math.max(1, _ticks), (double) _level.getGameTime(), _hide ? 1.0 : 0.0 });
        return _g;
    }

    /** 命中一个方块: 记一条渲染条目, 需要隐藏时把世界里的方块换成屏障(原方块只记第一次见到的那个) */
    private static void _ftAdd(Level _level, BlockPos _p, double _tilt, double _ax, double _az, int _g,
            double _offsetY, boolean _hide) {
        BlockState _st = _ftH.get(_p);
        if (_st == null) _st = _level.getBlockState(_p);
        _ftE.add(new double[] { _tilt, _ax, _az, (double) _g, _offsetY, _hide ? 1.0 : 0.0 });
        _ftP.add(_p);
        _ftS.add(_st);
        if (!_hide) return;
        int[] _c = _ftC.get(_p);
        if (_c == null) {
            // 第一次盖住这个位置: 记下真正的原方块(状态 + 方块实体数据), 再把世界换成屏障
            _ftH.put(_p, _st);
            if (_st.hasBlockEntity()) {
                BlockEntity _be = _level.getBlockEntity(_p);
                if (_be != null) {
                    CompoundTag _tag = _ftBeSave(_level, _be);
                    if (_tag != null) _ftN.put(_p, _tag);
                }
            }
            _ftC.put(_p, new int[] { 1 });
            if (_st.getBlock() != Blocks.BARRIER) _level.setBlock(_p, Blocks.BARRIER.defaultBlockState(), 3);
        } else {
            // 已经被别的组(或上一次调用)盖住了: 只加计数, 绝不把屏障当成"原方块"记下来
            _c[0]++;
            if (_level.getBlockState(_p).getBlock() != Blocks.BARRIER)
                _level.setBlock(_p, Blocks.BARRIER.defaultBlockState(), 3);
        }
    }

    /** 把一个位置真正放回原方块(只在没有任何组还盖着它的时候调用) */
    private static void _ftRestore(Level _level, BlockPos _p) {
        BlockState _st = _ftH.remove(_p);
        _ftC.remove(_p);
        CompoundTag _tag = _ftN.remove(_p);
        if (_st == null) return;
        // 区块已经卸载: 本地那次替换早就随区块一起没了, 这里不要再触发区块加载
        if (!_level.hasChunkAt(_p.getX() >> 4, _p.getZ() >> 4)) return;
        // 已经被别的东西覆盖(服务端把真方块推回来了 / 世界真的变了): 以世界为准, 不抢写
        if (_level.getBlockState(_p).getBlock() != Blocks.BARRIER) return;
        _level.setBlock(_p, _st, 3);
        if (_tag != null) {
            BlockEntity _be = _level.getBlockEntity(_p);
            if (_be != null) _ftBeLoad(_level, _be, _tag);
        }
    }

    /** 结束一组: 先退隐藏计数(减到 0 才放回原方块), 再把这组的渲染条目删掉 */
    private static void _restoreGroup(Level _level, int _g) {
        if (_g < 0 || _g >= _ftG.size()) return;
        double[] _gm = _ftG.get(_g);
        if (_gm[0] <= 0.0) return;
        _gm[0] = 0.0;
        for (int _i = _ftE.size() - 1; _i >= 0; _i--) {
            double[] _e = _ftE.get(_i);
            if ((int) _e[3] != _g) continue;
            if (_e[5] > 0.0) {
                BlockPos _p = _ftP.get(_i);
                int[] _c = _ftC.get(_p);
                if (_c != null && --_c[0] <= 0) _ftRestore(_level, _p);
            }
            _ftE.remove(_i);
            _ftP.remove(_i);
            _ftS.remove(_i);
        }
    }

    /** 死掉的分组只留一个空壳: 攒够 64 个就压紧一次, 免得反复调用越积越多 */
    private static void _ftCompact() {
        int _dead = 0;
        for (int _i = 0; _i < _ftG.size(); _i++)
            if (_ftG.get(_i)[0] <= 0.0) _dead++;
        if (_dead < 64) return;
        int[] _map = new int[_ftG.size()];
        java.util.ArrayList<double[]> _live = new java.util.ArrayList<>();
        for (int _i = 0; _i < _ftG.size(); _i++) {
            if (_ftG.get(_i)[0] <= 0.0) { _map[_i] = -1; continue; }
            _map[_i] = _live.size();
            _live.add(_ftG.get(_i));
        }
        for (int _i = 0; _i < _ftE.size(); _i++) {
            double[] _e = _ftE.get(_i);
            int _g = (int) _e[3];
            _e[3] = _g >= 0 && _g < _map.length ? (double) _map[_g] : -1.0;
        }
        _ftG.clear();
        _ftG.addAll(_live);
    }

    /** 取出方块实体数据(告示牌文字/旗帜图案/箱子内容等), 隐藏前存一份, 还原时写回去 */
    private static CompoundTag _ftBeSave(Level _level, BlockEntity _be) {
        try {
            return _be.saveWithFullMetadata();
        } catch (Exception _ex) {
            return null;
        }
    }

    /** 把方块实体数据写回刚恢复的方块; 写不回去也不该拖垮还原流程(方块状态已经还原了) */
    private static void _ftBeLoad(Level _level, BlockEntity _be, CompoundTag _tag) {
        try {
            _be.load(_tag);
        } catch (Exception _ex) {
        }
    }

    /** _profile: 1 = 中间翘得高、向外递减, 2 = 中间翘得低、向外递增; _offsetY = 特效显示相对原方块的 Y 偏移(只影响渲染) */
    public static void crack(LevelAccessor _accessor, double _x, double _y, double _z, double _radius, int _ticks,
            double _angle, boolean _hide, int _profile, double _offsetY) {
        if (!(_accessor instanceof Level _level)) return;
        Minecraft _mc = Minecraft.getInstance();
        if (_mc.level == null || _mc.level != _level) return;
        _ftBind(_level);
        double _r = _radius < 1.0 ? 1.0 : (_radius > 32.0 ? 32.0 : _radius);
        int _g = _ftNewGroup(_level, _ticks, _hide);
        double _max = Math.toRadians(_angle < 0.0 ? 0.0 : (_angle > 90.0 ? 90.0 : _angle));
        BlockPos _c = BlockPos.containing(_x, _y, _z);
        int _ir = (int) Math.ceil(_r);
        // 平面圆盘(只取中心那一层 Y), 不是球体。
        // 判定用"真实圆心 -> 方块中心"的距离(而不是整格偏移), 这样圆心不会被吸附到方块上、
        // 圆盘也更圆, 并且和下面倾斜用的距离归一化是同一套算法。
        for (int _ox = -_ir; _ox <= _ir; _ox++) {
            for (int _oz = -_ir; _oz <= _ir; _oz++) {
                BlockPos _p = _c.offset(_ox, 0, _oz);
                double _dx = (double) _p.getX() + 0.5 - _x;
                double _dz = (double) _p.getZ() + 0.5 - _z;
                double _dh = Math.sqrt(_dx * _dx + _dz * _dz);
                if (_dh > _r) continue;
                if (_level.getBlockState(_p).isAir()) continue;
                double _tilt = 0.0, _ax = 0.0, _az = 0.0;
                if (_dh > 0.1) {
                    // 外翘的轴 = 水平切向; 绕它转正角 => 外侧抬起来, 中间不动(绕方块中心转)
                    _ax = -_dz / _dh;
                    _az = _dx / _dh;
                    double _n = Math.min(1.0, _dh / _r);
                    _tilt = _max * (_profile == 2 ? _n : (1.0 - _n));
                }
                _ftAdd(_level, _p, _tilt, _ax, _az, _g, _offsetY, _hide);
                // 隐藏档的说明: 本地替换成"不可见的屏障方块" —— 看不见, 但碰撞还在, 所以玩家脚下的方块
                // 也能一起改变而人不会掉下去(若换成空气, 客户端会把玩家漏下去, 服务端再拉回来 = 抖动)
            }
        }
    }

    /**
     * 定向砸击: 从 (x1,y1,z1) 冲向 (x2,y2,z2), 让沿途方块朝目标翘起来。
     * _shape: 0 = 直条(宽度恒定), 1 = 锥形(顶点在起点, 到终点张开成宽度 _width 的三角形)
     */
    public static void smash(LevelAccessor _accessor, double _x1, double _y1, double _z1, double _x2, double _y2,
            double _z2, double _width, int _ticks, double _angle, int _shape, boolean _hide, double _offsetY) {
        if (!(_accessor instanceof Level _level)) return;
        Minecraft _mc = Minecraft.getInstance();
        if (_mc.level == null || _mc.level != _level) return;
        _ftBind(_level);
        double _half = Math.max(0.5, Math.min(16.0, _width * 0.5));
        double _vx = _x2 - _x1, _vz = _z2 - _z1;
        double _vl = Math.sqrt(_vx * _vx + _vz * _vz);
        if (_vl > 64.0) {                       // 距离过远时只生成到 64 格处(防止方块数与循环量失控)
            _vx = _vx / _vl * 64.0;
            _vz = _vz / _vl * 64.0;
            _vl = 64.0;
        }
        double _v2 = _vx * _vx + _vz * _vz;
        double _ux = _vl < 1.0E-4 ? 1.0 : _vx / _vl;
        double _uz = _vl < 1.0E-4 ? 0.0 : _vz / _vl;
        double _px = -_uz, _pz = _ux;           // 水平侧向单位向量
        int _g = _ftNewGroup(_level, _ticks, _hide);
        double _max = Math.toRadians(_angle < 0.0 ? 0.0 : (_angle > 90.0 ? 90.0 : _angle));
        int _cap = _ftE.size() + 800;
        int _minX = (int) Math.floor(Math.min(_x1, _x1 + _vx) - _half - 1.0);
        int _maxX = (int) Math.floor(Math.max(_x1, _x1 + _vx) + _half + 1.0);
        int _minZ = (int) Math.floor(Math.min(_z1, _z1 + _vz) - _half - 1.0);
        int _maxZ = (int) Math.floor(Math.max(_z1, _z1 + _vz) + _half + 1.0);
        int _minY = (int) Math.floor(Math.min(_y1, _y2) - 1.0);
        int _maxY = (int) Math.floor(Math.max(_y1, _y2) + 1.0);
        for (int _ix = _minX; _ix <= _maxX; _ix++) {
            for (int _iz = _minZ; _iz <= _maxZ; _iz++) {
                double _bx = (double) _ix + 0.5 - _x1;
                double _bz = (double) _iz + 0.5 - _z1;
                double _t = _v2 < 1.0E-6 ? 0.0 : (_bx * _vx + _bz * _vz) / _v2;
                if (_t < 0.0 || _t > 1.0) continue;
                double _lx = _x1 + _vx * _t;
                double _lz = _z1 + _vz * _t;
                double _ox = (double) _ix + 0.5 - _lx;
                double _oz = (double) _iz + 0.5 - _lz;
                double _dist = Math.sqrt(_ox * _ox + _oz * _oz);
                // 锥形的张开曲线: 线性与 smoothstep 混合(纯 smoothstep 会让尖端太空), 轮廓更顺
                double _flare = _shape == 1 ? (0.45 * _t + 0.55 * _t * _t * (3.0 - 2.0 * _t)) : 1.0;
                double _halfAt = _half * _flare;
                if (_dist > _halfAt) continue;
                double _ly = _y1 + (_y2 - _y1) * _t;      // 条带跟着这条线的高度走
                // 两种形状都做"侧向扇形": 中轴上的方块朝目标翘, 越靠边越往左右偏(往外扩张);
                // 直条用固定半宽, 锥形用随距离张开的半宽
                double _rx = _ux, _rz = _uz, _tilt = _max;
                if (_halfAt > 0.3) {
                    double _u2 = Math.max(-1.0, Math.min(1.0, (_ox * _px + _oz * _pz) / _halfAt));
                    double _au = Math.abs(_u2);
                    // 方向: 缓入缓出地往侧向偏(最多 45 度), 不会有折角
                    double _sm = _au * _au * (3.0 - 2.0 * _au);
                    double _ease = _u2 < 0.0 ? -_sm : _sm;
                    _rx = _ux + _px * _ease;
                    _rz = _uz + _pz * _ease;
                    double _rl = Math.sqrt(_rx * _rx + _rz * _rz);
                    if (_rl > 1.0E-4) { _rx /= _rl; _rz /= _rl; }
                    // 幅度: 中轴最翘, 往两侧边缘平滑收到 0 => 边界没有硬台阶
                    // (锥形额外沿长度衰减: 越靠近目标越弱)
                    _tilt = _max * (1.0 - _au * _au) * (_shape == 1 ? (1.0 - 0.45 * _t) : 1.0);
                }
                double _ax = -_rz, _az = _rx;             // 水平切向: 绕它转正角 => 朝目标那一侧抬起来
                for (int _iy = _minY; _iy <= _maxY; _iy++) {
                    if (Math.abs((double) _iy + 0.5 - _ly) > 0.5) continue;
                    BlockPos _p = new BlockPos(_ix, _iy, _iz);
                    if (_level.getBlockState(_p).isAir()) continue;
                    _ftAdd(_level, _p, _tilt, _ax, _az, _g, _offsetY, _hide);
                    if (_ftE.size() >= _cap) return;
                }
            }
        }
    }

    public static boolean isActive() {
        return !_ftE.isEmpty();
    }

    /** 立即结束特效并恢复原方块显示(在旧世界/换维度里调用时只清记录, 一个方块都不写) */
    public static void restore(LevelAccessor _accessor) {
        if (!(_accessor instanceof Level _level) || _ftL == null || _ftL != _level) {
            _ftClear();
            return;
        }
        for (int _g = 0; _g < _ftG.size(); _g++) _restoreGroup(_level, _g);
        // 兜底: 万一还有没退干净的隐藏记录, 一并放回去(否则会留下看不见、撞得到的屏障)
        if (!_ftH.isEmpty()) {
            java.util.ArrayList<BlockPos> _ps = new java.util.ArrayList<>(_ftH.keySet());
            for (int _i = 0; _i < _ps.size(); _i++) _ftRestore(_level, _ps.get(_i));
        }
        _ftClear();
    }

    @SubscribeEvent public static void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        Minecraft _mc = Minecraft.getInstance();
        Level _level = _mc.level;
        if (_level == null) {
            _ftClear();
            return;
        }
        // 换维度/换世界: 旧记录属于旧世界的客户端区块, 直接丢掉, 不往新世界写方块
        if (_ftL != null && _ftL != _level) _ftClear();
        double _now = (double) _level.getGameTime();
        for (int _g = 0; _g < _ftG.size(); _g++) {
            double[] _gm = _ftG.get(_g);
            if (_gm[0] <= 0.0) continue;
            if (_now - _gm[1] > _gm[0]) _restoreGroup(_level, _g);
        }
        if (_ftE.isEmpty()) {
            _ftCompact();
            return;
        }
        Vec3 _camera = event.getCamera().getPosition();
        PoseStack _pose = event.getPoseStack();
        MultiBufferSource _buffers = _mc.renderBuffers().bufferSource();
        for (int _i = 0; _i < _ftE.size(); _i++) {
            double[] _e = _ftE.get(_i);
            int _g = (int) _e[3];
            if (_g < 0 || _g >= _ftG.size() || _ftG.get(_g)[0] <= 0.0) continue;
            BlockPos _p = _ftP.get(_i);
            // 本地隐藏被服务端数据顶回来时自动补上(平时这一步只做一次方块判断, 不产生开销)
            if (_e[5] > 0.0 && _level.getBlockState(_p).getBlock() != Blocks.BARRIER)
                _level.setBlock(_p, Blocks.BARRIER.defaultBlockState(), 3);
            // 无重力: 碎块不下坠也不下沉; 角度直接就是目标角度, 不做"从 0 慢慢翘起来"的过渡
            // 位置只认 _ftP 里的方块坐标; _e[4] 只是"显示用的 Y 偏移", 只加在这一行平移上
            _pose.pushPose();
            _pose.translate(_p.getX() - _camera.x, _p.getY() + _e[4] - _camera.y, _p.getZ() - _camera.z);
            // 绕方块自身中心转(而不是绕角): 中间不动, 四边往外翘
            _pose.translate(0.5, 0.5, 0.5);
            if (_e[0] != 0.0)
                _pose.mulPose(new org.joml.Quaternionf().rotationAxis((float) _e[0], (float) _e[1], 0.0F,
                        (float) _e[2]));
            _pose.translate(-0.5, -0.5, -0.5);
            BlockState _st = _ftS.get(_i);
            int _light = LevelRenderer.getLightColor(_level, _st, _p);
            if (_st.getRenderShape() != RenderShape.INVISIBLE) {
                if (_st.getRenderShape() == RenderShape.ENTITYBLOCK_ANIMATED) {
                    // 箱子/潜影盒这类要由方块实体渲染器画
                    _mc.getBlockRenderer().renderSingleBlock(_st, _pose, _buffers, _light, OverlayTexture.NO_OVERLAY);
                } else {
                    // 不用 renderSingleBlock: 它取方块颜色时 level/pos 传的是 null, 所以草方块/树叶/水
                    // 这些"按生物群系染色"的方块会变成默认色。这里用真实 level/pos 取色, 色调与原方块一致。
                    int _tint = _mc.getBlockColors().getColor(_st, _mc.level, _p, 0);
                    _mc.getBlockRenderer().getModelRenderer().renderModel(_pose.last(),
                            _buffers.getBuffer(ItemBlockRenderTypes.getChunkRenderType(_st)), _st,
                            _mc.getBlockRenderer().getBlockModel(_st), (float) (_tint >> 16 & 255) / 255.0F,
                            (float) (_tint >> 8 & 255) / 255.0F, (float) (_tint & 255) / 255.0F, _light,
                            OverlayTexture.NO_OVERLAY);
                }
            }
            _pose.popPose();
        }
        _ftCompact();
    }

// ===== HX_SYNC: 本工具类的渲染同步重放注册(只在客户端加载时执行一次) =====
static {
	RegPacketProcedure.hxRegister("terrain.crack", _d -> crack(Minecraft.getInstance().level, RegPacketProcedure.hxN(_d, "a0"), RegPacketProcedure.hxN(_d, "a1"), RegPacketProcedure.hxN(_d, "a2"), RegPacketProcedure.hxN(_d, "a3"), RegPacketProcedure.hxI(_d, "a4"), RegPacketProcedure.hxN(_d, "a5"), RegPacketProcedure.hxB(_d, "a6"), RegPacketProcedure.hxI(_d, "a7"), RegPacketProcedure.hxN(_d, "a8")));
	RegPacketProcedure.hxRegister("terrain.restore", _d -> restore(Minecraft.getInstance().level));
	RegPacketProcedure.hxRegister("terrain.smash", _d -> smash(Minecraft.getInstance().level, RegPacketProcedure.hxN(_d, "a0"), RegPacketProcedure.hxN(_d, "a1"), RegPacketProcedure.hxN(_d, "a2"), RegPacketProcedure.hxN(_d, "a3"), RegPacketProcedure.hxN(_d, "a4"), RegPacketProcedure.hxN(_d, "a5"), RegPacketProcedure.hxN(_d, "a6"), RegPacketProcedure.hxI(_d, "a7"), RegPacketProcedure.hxN(_d, "a8"), RegPacketProcedure.hxI(_d, "a9"), RegPacketProcedure.hxB(_d, "a10"), RegPacketProcedure.hxN(_d, "a11")));
}
