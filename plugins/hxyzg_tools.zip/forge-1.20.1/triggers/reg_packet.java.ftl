<#include "procedures.java.ftl">
@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD) public class ${name}Procedure {
public static final String PROTOCOL_VERSION = "1";
public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
		new ResourceLocation("${modid}", "main"),
		() -> PROTOCOL_VERSION,
		PROTOCOL_VERSION::equals,
		PROTOCOL_VERSION::equals
	);

public static final SimpleChannel CHANNELB = NetworkRegistry.newSimpleChannel(
		new ResourceLocation("${modid}", "msg"),
		() -> PROTOCOL_VERSION,
		PROTOCOL_VERSION::equals,
		PROTOCOL_VERSION::equals
	);

public static final SimpleChannel CHANNELC = NetworkRegistry.newSimpleChannel(
		new ResourceLocation("${modid}", "msgp"),
		() -> PROTOCOL_VERSION,
		PROTOCOL_VERSION::equals,
		PROTOCOL_VERSION::equals
	);

public static class ${name}Comm {
    private final CompoundTag nbt;

    public ${name}Comm(CompoundTag nbt) {
        this.nbt = nbt;
    }

    public static void encode(${name}Comm packet, FriendlyByteBuf buffer) {
        buffer.writeNbt(packet.nbt);
    }

    public ${name}Comm(FriendlyByteBuf buffer) {
        this.nbt = buffer.readNbt();
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            LocalPlayer player = Minecraft.getInstance().player;
            if (player != null) {
                player.getPersistentData().merge(this.nbt);
            }
        });
        ctx.get().setPacketHandled(true);
    }

    public CompoundTag getNbt() {
	return this.nbt;
    }
}

public static class ${name}CommB {
    private final String text;

    public ${name}CommB(String text) {
        this.text = text;
    }

    public static void encode(${name}CommB packet, FriendlyByteBuf buffer) {
        buffer.writeUtf(packet.text);
    }

    public ${name}CommB(FriendlyByteBuf buffer) {
        this.text = buffer.readUtf();
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) {
                player.getPersistentData().putString("hxyzg_msg", this.text);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}

public static class ${name}CommC {
    private final UUID uuid;
    private final String text;

    public ${name}CommC(UUID uuid, String text) {
        this.uuid = uuid;
        this.text = text;
    }

    public static void encode(${name}CommC packet, FriendlyByteBuf buffer) {
        buffer.writeUUID(packet.uuid);
        buffer.writeUtf(packet.text);
    }

    public ${name}CommC(FriendlyByteBuf buffer) {
        this.uuid = buffer.readUUID();
        this.text = buffer.readUtf();
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null && player.server != null) {
                for (ServerLevel _level : player.server.getAllLevels()) {
                    Entity _ent = _level.getEntity(this.uuid);
                    if (_ent != null) {
                        _ent.getPersistentData().putString("hxyzg_msg", this.text);
                        break;
                    }
                }
            }
        });
        ctx.get().setPacketHandled(true);
    }
}

public static void sendToTracking(Entity entity, CompoundTag nbt) {
	if (!entity.level().isClientSide()) {
		CHANNEL.send(PacketDistributor.TRACKING_ENTITY.with(() -> entity), new ${name}Comm(nbt));
	}
}

public static void sendToTrackingAndSelf(Entity entity, CompoundTag nbt) {
	if (!entity.level().isClientSide()) {
		CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> entity), new ${name}Comm(nbt));
	}
}

public static void sendToTrackingChunk(LevelChunk chunk, CompoundTag nbt) {
	if (!chunk.getLevel().isClientSide()) {
		CHANNEL.send(PacketDistributor.TRACKING_CHUNK.with(() -> chunk), new ${name}Comm(nbt));
	}
}

public static void sendToNearby(Level level, double x, double y, double z, double range, CompoundTag nbt) {
	if (!level.isClientSide()) {
		CHANNEL.send(
			PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(x, y, z, range, level.dimension())), 
			new ${name}Comm(nbt)
		);
	}
}

public static void sendToPlayer(ServerPlayer player, CompoundTag nbt) {
	CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new ${name}Comm(nbt));
}

public static void sendToAll(CompoundTag nbt) {
	CHANNEL.send(PacketDistributor.ALL.noArg(), new ${name}Comm(nbt));
}

public static void sendToDimension(Level level, CompoundTag nbt) {
	if (!level.isClientSide()) {
		CHANNEL.send(PacketDistributor.DIMENSION.with(() -> level.dimension()), new ${name}Comm(nbt));
	}
}

public static void send(CompoundTag nbt) {
	CHANNEL.sendToServer(new ${name}Comm(nbt));
}

// ===== HX_SYNC: render sync (client -> server -> nearby other players) =====
public static final SimpleChannel HXCH = NetworkRegistry.newSimpleChannel(
		new ResourceLocation("${modid}", "hxsync"),
		() -> PROTOCOL_VERSION,
		PROTOCOL_VERSION::equals,
		PROTOCOL_VERSION::equals);

public static class HxSync {
	private final String feature;
	private final CompoundTag data;

	public HxSync(String feature, CompoundTag data) {
		this.feature = feature;
		this.data = data;
	}

	public static void encode(HxSync packet, FriendlyByteBuf buffer) {
		buffer.writeUtf(packet.feature);
		buffer.writeNbt(packet.data);
	}

	public HxSync(FriendlyByteBuf buffer) {
		this.feature = buffer.readUtf();
		this.data = buffer.readNbt();
	}

	public void handle(Supplier<NetworkEvent.Context> ctx) {
		NetworkEvent.Context context = ctx.get();
		context.enqueueWork(() -> {
			if (context.getDirection().getReceptionSide().isServer()) {
				ServerPlayer sender = context.getSender();
				if (sender == null) return;
				CompoundTag d = this.data;
				double x = d.getDouble("hx_x"), y = d.getDouble("hx_y"), z = d.getDouble("hx_z");
				double range = d.contains("hx_range") ? d.getDouble("hx_range") : 128.0;
				d.putString("hx_from", sender.getStringUUID());
				d.putString("hx_src", "c");   // c=客户端请求转发 / s=服务端广播, 用来认出"同一动作走了两条同步路"
				for (ServerPlayer _p : sender.serverLevel().players()) {   // 逐个发, 发起者自己不发(否则本地+回放=两把)
					if (_p == sender) continue;
					if (d.contains("hx_x") && _p.distanceToSqr(x, y, z) > range * range) continue;   // 没坐标(屏幕类积木)就不筛
					HXCH.send(PacketDistributor.PLAYER.with(() -> _p), new HxSync(this.feature, d));
				}
			} else {
				hxApply(this.feature, this.data);
			}
		});
		context.setPacketHandled(true);
	}
}

/** client side: ask the server to relay this render to other players nearby */
public static void hxRequest(String feature, CompoundTag data) {
	HXCH.sendToServer(new HxSync(feature, data));
}

/** server side: broadcast to nearby players (used when the block runs on the server) */
public static void hxBroadcastServe(Level level, String feature, CompoundTag data) {
	double range = data.contains("hx_range") ? data.getDouble("hx_range") : 128.0;
	data.putString("hx_src", "s");
	if (!data.contains("hx_x")) {   // 没坐标(屏幕类积木): 同维度全发, 不按距离筛
		HXCH.send(PacketDistributor.DIMENSION.with(() -> level.dimension()), new HxSync(feature, data));
		return;
	}
	double x = data.getDouble("hx_x"), y = data.getDouble("hx_y"), z = data.getDouble("hx_z");
	HXCH.send(PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(x, y, z, range, level.dimension())),
			new HxSync(feature, data));
}

/** 每个工具类在客户端加载时自己注册重放函数 —— RegPacket 不需要认识它们, 你只建用到的工具类即可 */
public static final java.util.HashMap<String, java.util.function.Consumer<CompoundTag>> HX_HANDLERS = new java.util.HashMap<>();

public static void hxRegister(String feature, java.util.function.Consumer<CompoundTag> handler) {
	if (feature != null && handler != null) HX_HANDLERS.put(feature, handler);
}

// ---- 去重: 同一个动作有时会走两条同步路(物品右键这种: 客户端跑一遍, 服务端又跑一遍), ----
// 别的玩家就会收到两份 → 记下每个动作指纹最近是从哪条路来的(c=客户端请求转发 / s=服务端广播),
// 400ms 内另一条路送来的同一份直接丢掉; 本地已经自己画过的那份, 服务端的广播回声也不再回放。
public static final java.util.HashMap<String, String> HX_SRC = new java.util.HashMap<>();
public static final java.util.HashMap<String, Long> HX_T = new java.util.HashMap<>();
public static final java.util.HashMap<String, Long> HX_LOCAL = new java.util.HashMap<>();
public static final long HX_WIN = 400L;

/** 动作指纹: 功能名 + 参数(不含 hx_from/hx_src, 两条路算出来必须一样) */
public static String hxKey(String feature, CompoundTag d) {
	StringBuilder sb = new StringBuilder(feature);
	for (int _i = 0; d.contains("a" + _i); _i++) sb.append('|').append(d.getDouble("a" + _i));
	sb.append('|');
	for (int _i = 0; d.contains("s" + _i); _i++) sb.append('|').append(d.getString("s" + _i));
	if (d.contains("hx_e")) sb.append("|e").append(d.getInt("hx_e"));
	if (d.contains("hx_item")) {
		CompoundTag _it = d.getCompound("hx_item");
		sb.append("|i").append(_it.getString("id")).append(':').append(_it.getInt("count") + _it.getInt("Count"));
	}
	return sb.toString();
}

private static void hxPurge(long now) {
	if (HX_SRC.size() > 512) {
		java.util.Iterator<java.util.Map.Entry<String, Long>> _it = HX_T.entrySet().iterator();
		while (_it.hasNext()) {
			java.util.Map.Entry<String, Long> _e = _it.next();
			if (now - _e.getValue() > HX_WIN) { HX_SRC.remove(_e.getKey()); _it.remove(); }
		}
	}
	if (HX_LOCAL.size() > 512) {
		java.util.Iterator<java.util.Map.Entry<String, Long>> _it = HX_LOCAL.entrySet().iterator();
		while (_it.hasNext()) { if (now - _it.next().getValue() > HX_WIN) _it.remove(); }
	}
}

/** 客户端本地已经自己画了一份: 记下来, 免得服务端的广播回声又画一遍 */
public static void hxMarkLocal(String feature, CompoundTag d) {
	try { HX_LOCAL.put(hxKey(feature, d), System.currentTimeMillis()); } catch (Throwable _ex) {}
}

/** true = 这一份是同一动作的重复, 别再回放 */
public static boolean hxDup(String feature, String src, CompoundTag d) {
	long _now = System.currentTimeMillis();
	hxPurge(_now);
	String _k = hxKey(feature, d);
	Long _lt = HX_LOCAL.get(_k);
	if ("s".equals(src) && _lt != null && _now - _lt < HX_WIN) return true;
	String _ps = HX_SRC.get(_k);
	Long _pt = HX_T.get(_k);
	if (_ps != null && _pt != null && _now - _pt < HX_WIN) {
		if (_ps.equals(src)) { HX_T.put(_k, _now); return false; }
		return true;
	}
	HX_SRC.put(_k, src);
	HX_T.put(_k, _now);
	return false;
}

/** received on a client: skip our own echo, then replay through the registered handler */
public static void hxApply(String feature, CompoundTag d) {
	LocalPlayer me = Minecraft.getInstance().player;
	if (me != null && d.contains("hx_from") && d.getString("hx_from").equals(me.getStringUUID())) return;
	String _src = d.contains("hx_src") ? d.getString("hx_src") : "s";
	if (hxDup(feature, _src, d)) return;
	java.util.function.Consumer<CompoundTag> h = HX_HANDLERS.get(feature);
	if (h == null) {
		System.out.println("[hxyzg] 渲染同步: 没有注册 " + feature + " 的重放函数(对应工具类没建?)");
		return;
	}
	try {
		h.accept(d);
	} catch (Throwable _ex) {
	}
}

public static double hxN(CompoundTag d, String k) { return d.getDouble(k); }
public static int hxI(CompoundTag d, String k) { return d.getInt(k); }
public static String hxS(CompoundTag d, String k) { return d.getString(k); }
public static boolean hxB(CompoundTag d, String k) { return d.getBoolean(k); }
public static net.minecraft.world.entity.Entity hxEnt(CompoundTag d) {
	try {
		if (!d.contains("hx_e")) return null;
		return Minecraft.getInstance().level == null ? null : Minecraft.getInstance().level.getEntity(d.getInt("hx_e"));
	} catch (Throwable _ex) {
		return null;
	}
}
public static net.minecraft.world.item.ItemStack hxItem(CompoundTag d) {
	try {
		CompoundTag t = d.getCompound("hx_item");
		if (t.isEmpty()) return net.minecraft.world.item.ItemStack.EMPTY;
		return net.minecraft.world.item.ItemStack.of(t);
	} catch (Throwable _ex) {
		return net.minecraft.world.item.ItemStack.EMPTY;
	}
}
/** pack the args by runtime type and (client) ask the server to relay / (server) broadcast near */
public static void hxSend(LevelAccessor level, String feature, Object... args) {
	CompoundTag t = new CompoundTag();
	int _n = 0, _s = 0;
	for (Object a : args) {
		if (a instanceof Number) t.putDouble("a" + (_n++), ((Number) a).doubleValue());
		else if (a instanceof Boolean) t.putBoolean("a" + (_n++), ((Boolean) a).booleanValue());
		else if (a instanceof CharSequence) t.putString("s" + (_s++), a.toString());
		else if (a instanceof ResourceLocation) t.putString("s" + (_s++), a.toString());
	}
	for (Object a : args) {
		if (a instanceof net.minecraft.world.entity.Entity) {
			net.minecraft.world.entity.Entity _oe = (net.minecraft.world.entity.Entity) a;
			t.putInt("hx_e", _oe.getId());
			// 同步范围的原点就用这个实体。以前 hx_x/hx_y/hx_z 从来没打包过, 判定中心一直是世界原点,
			// 于是离原点 128 格以外的玩家什么都收不到 —— 哪怕效果就发生在他旁边。
			t.putDouble("hx_x", _oe.getX());
			t.putDouble("hx_y", _oe.getY() + (double) _oe.getBbHeight() * 0.5);
			t.putDouble("hx_z", _oe.getZ());
		}
	}
	for (Object a : args) {
		if (a instanceof net.minecraft.world.item.ItemStack) t.put("hx_item", ((net.minecraft.world.item.ItemStack) a).save(new CompoundTag()));;
	}
	if (level instanceof ServerLevel) hxBroadcastServe((Level) level, feature, t);
	else { hxMarkLocal(feature, t); hxRequest(feature, t); }
}

/** trail start: 粒子按注册名传输, 客户端再映射回 SimpleParticleType */
public static void hxTrailStart(LevelAccessor level, net.minecraft.world.entity.Entity entity,
		net.minecraft.core.particles.ParticleOptions particle, int width) {
	CompoundTag t = new CompoundTag();
	t.putInt("hx_e", entity.getId());
	t.putInt("a0", width);
	try {
		t.putString("s0", String.valueOf(BuiltInRegistries.PARTICLE_TYPE.getKey(particle.getType())));
	} catch (Throwable _ex) {
	}
	if (level instanceof ServerLevel) hxBroadcastServe((Level) level, "trail.start", t);
	else { hxMarkLocal("trail.start", t); hxRequest("trail.start", t); }
}
// ===== HX_SYNC end =====

@SubscribeEvent public static void init(FMLCommonSetupEvent event) {
	event.enqueueWork(() -> {
			CHANNEL.registerMessage(0, ${name}Comm.class,
			${name}Comm::encode,
			${name}Comm::new,
			${name}Comm::handle);
			CHANNELB.registerMessage(0, ${name}CommB.class,
			${name}CommB::encode,
			${name}CommB::new,
			${name}CommB::handle);
			CHANNELC.registerMessage(0, ${name}CommC.class,
			${name}CommC::encode,
			${name}CommC::new,
			${name}CommC::handle);
			HXCH.registerMessage(0, HxSync.class,
			HxSync::encode,
			HxSync::new,
			HxSync::handle);
		});
	<#assign dependenciesCode><#compress>
		<@procedureDependenciesCode dependencies, {
			"event": "event"
		}/>
	</#compress></#assign>
	execute(event<#if dependenciesCode?has_content>,</#if>${dependenciesCode});
}
