<#include "procedures.java.ftl">
@Mod.EventBusSubscriber(Dist.CLIENT) public class ${name}Procedure {
    private static final java.util.List<_Dc> _dcs = java.util.Collections.synchronizedList(new java.util.ArrayList<>());
    private static long _dcTime = -1L;

    private static final class _Dc {
        final double x, y, z, size, rot;
        final String face, texture;
        final int ticks;
        int age;

        _Dc(double _x, double _y, double _z, String _face, String _texture, double _size, double _rot, int _ticks) {
            this.x = _x;
            this.y = _y;
            this.z = _z;
            this.face = _face;
            this.texture = _texture;
            this.size = _size;
            this.rot = _rot;
            this.ticks = _ticks;
        }
    }

    /** 显示一张贴图面片: face = UP/DOWN/WEST/EAST/NORTH/SOUTH; ticks<=0 表示永久(用 clear 清掉) */
    public static void show(double _x, double _y, double _z, String _face, String _texture, double _size, double _rot, int _ticks) {
        if (_texture == null || _texture.trim().isEmpty()) return;
        String _f = _face == null ? "UP" : _face.toUpperCase(java.util.Locale.ROOT);
        double _s = _size <= 0.0 ? 1.0 : (_size > 64.0 ? 64.0 : _size);
        synchronized (_dcs) {
            if (_dcs.size() >= 256) _dcs.remove(0);
            _dcs.add(new _Dc(_x, _y, _z, _f, _texture.trim(), _s, _rot, _ticks));
        }
    }

    /** 清掉全部贴图面片 */
    public static void clear() {
        synchronized (_dcs) {
            _dcs.clear();
        }
    }

    /** 当前贴图面片数量 */
    public static int count() {
        synchronized (_dcs) {
            return _dcs.size();
        }
    }

    private static ResourceLocation _dcRl(String _path) {
        try {
            String _p = _path.replace('\\', '/').trim();
            if (!_p.contains(":")) _p = "${modid}:" + _p;
            if (!_p.endsWith(".png")) _p = _p + ".png";
            return ResourceLocation.tryParse(_p);
        } catch (Exception _ex) {
            return null;
        }
    }

    private static void _dcQuad(MultiBufferSource.BufferSource _buffers, PoseStack _pose, _Dc _d, ResourceLocation _rl) {
        double _e = 0.004;
        double _cx = 0.5, _cy = 0.5, _cz = 0.5;
        double _ux = 0.0, _uy = 0.0, _uz = 0.0, _vx = 0.0, _vy = 0.0, _vz = 0.0;
        float _nx = 0.0F, _ny = 0.0F, _nz = 0.0F;
        switch (_d.face) {
            case "DOWN": _cy = -_e; _ux = 1.0; _vz = 1.0; _ny = -1.0F; break;
            case "WEST": _cx = -_e; _uz = -1.0; _vy = 1.0; _nx = -1.0F; break;
            case "EAST": _cx = 1.0 + _e; _uz = 1.0; _vy = 1.0; _nx = 1.0F; break;
            case "NORTH": _cz = -_e; _ux = 1.0; _vy = 1.0; _nz = -1.0F; break;
            case "SOUTH": _cz = 1.0 + _e; _ux = -1.0; _vy = 1.0; _nz = 1.0F; break;
            case "UP":
            default: _cy = 1.0 + _e; _ux = 1.0; _vz = -1.0; _ny = 1.0F; break;
        }
        double _a = Math.toRadians(_d.rot);
        double _ca = Math.cos(_a), _sa = Math.sin(_a);
        double _u2x = _ux * _ca + _vx * _sa, _u2y = _uy * _ca + _vy * _sa, _u2z = _uz * _ca + _vz * _sa;
        double _v2x = _vx * _ca - _ux * _sa, _v2y = _vy * _ca - _uy * _sa, _v2z = _vz * _ca - _uz * _sa;
        double _h = _d.size * 0.5;
        float[] _xs = new float[] { (float) (_cx - _u2x * _h + _v2x * _h), (float) (_cx + _u2x * _h + _v2x * _h), (float) (_cx + _u2x * _h - _v2x * _h), (float) (_cx - _u2x * _h - _v2x * _h) };
        float[] _ys = new float[] { (float) (_cy - _u2y * _h + _v2y * _h), (float) (_cy + _u2y * _h + _v2y * _h), (float) (_cy + _u2y * _h - _v2y * _h), (float) (_cy - _u2y * _h - _v2y * _h) };
        float[] _zs = new float[] { (float) (_cz - _u2z * _h + _v2z * _h), (float) (_cz + _u2z * _h + _v2z * _h), (float) (_cz + _u2z * _h - _v2z * _h), (float) (_cz - _u2z * _h - _v2z * _h) };
        float[] _us = new float[] { 0.0F, 1.0F, 1.0F, 0.0F };
        float[] _vs = new float[] { 0.0F, 0.0F, 1.0F, 1.0F };
        _emitQuad(_buffers, _pose, _xs, _ys, _zs, _us, _vs, _nx, _ny, _nz, RenderType.entityTranslucent(_rl));
    }

    @SubscribeEvent public static void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        Minecraft _mc = Minecraft.getInstance();
        if (_mc.level == null) return;
        java.util.List<_Dc> _list;
        synchronized (_dcs) {
            if (_dcs.isEmpty()) return;
            // 用游戏刻推进年龄(不是帧数), 这样"持续 N 刻"跟帧率无关
            long _now = _mc.level.getGameTime();
            if (_dcTime < 0L) _dcTime = _now;
            int _dt = (int) Math.max(0L, Math.min(40L, _now - _dcTime));
            _dcTime = _now;
            if (_dt > 0) {
                java.util.Iterator<_Dc> _it = _dcs.iterator();
                while (_it.hasNext()) {
                    _Dc _d = _it.next();
                    _d.age += _dt;
                    if (_d.ticks > 0 && _d.age >= _d.ticks) _it.remove();
                }
            }
            if (_dcs.isEmpty()) return;
            _list = new java.util.ArrayList<>(_dcs);
        }
        PoseStack _pose = event.getPoseStack();
        Vec3 _camera = event.getCamera().getPosition();
        MultiBufferSource.BufferSource _buffers = _mc.renderBuffers().bufferSource();
        for (_Dc _d : _list) {
            ResourceLocation _rl = _dcRl(_d.texture);
            if (_rl == null) continue;
            _pose.pushPose();
            _pose.translate(Math.floor(_d.x) - _camera.x, Math.floor(_d.y) - _camera.y, Math.floor(_d.z) - _camera.z);
            _dcQuad(_buffers, _pose, _d, _rl);
            _pose.popPose();
        }
    }
    private static void _emitQuad(MultiBufferSource.BufferSource _buffers, PoseStack _pose, float[] _xs, float[] _ys,
            float[] _zs, float[] _us, float[] _vs, float _nx, float _ny, float _nz, RenderType _type) {
        VertexConsumer _vc = _buffers.getBuffer(_type);
        org.joml.Matrix4f _m = _pose.last().pose();
        for (int _i = 0; _i < 4; _i++) {
            _vc.vertex(_m, _xs[_i], _ys[_i], _zs[_i]).color(255, 255, 255, 255).uv(_us[_i], _vs[_i])
                    .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(15728880).normal(_nx, _ny, _nz).endVertex();
        }
        // 自己取的渲染类型自己收尾: 1.20.1 的 BufferSource 对非 fixed 类型是共享 builder
        _buffers.endBatch(_type);
    }

// ===== HX_SYNC: 本工具类的渲染同步重放注册(只在客户端加载时执行一次) =====
static {
	RegPacketProcedure.hxRegister("decal.show", _d -> show(RegPacketProcedure.hxN(_d, "a0"), RegPacketProcedure.hxN(_d, "a1"), RegPacketProcedure.hxN(_d, "a2"), RegPacketProcedure.hxS(_d, "s0"), RegPacketProcedure.hxS(_d, "s1"), RegPacketProcedure.hxN(_d, "a3"), RegPacketProcedure.hxN(_d, "a4"), RegPacketProcedure.hxI(_d, "a5")));
	RegPacketProcedure.hxRegister("decal.clear", _d -> clear());
}
