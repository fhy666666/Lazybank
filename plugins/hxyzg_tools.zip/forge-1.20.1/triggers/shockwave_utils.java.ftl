<#include "procedures.java.ftl">
@Mod.EventBusSubscriber public class ${name}Procedure {
    // 一个冲击波: 中心 + 最大半径 + 寿命 + 力度 + 形状. 半径只跟"过了多少刻"有关, 所以和帧率无关.
    private static final class _Wave {
        final LevelAccessor level;
        final double x, y, z, maxRadius, force;
        final int life;
        final boolean sphere;
        final ParticleOptions particle;
        final boolean hide;      // true = 完全不发粒子, 只保留推力(可以不给粒子)
        java.util.UUID skipId;   // skip this entity (UUID), null = push all
        int age;
        long lastTick = -1L;   // 同一刻只推进一次(等级 tick 和玩家 tick 两个来源都接着)
        _Wave(LevelAccessor _level, double _x, double _y, double _z, double _maxRadius, int _life,
                ParticleOptions _particle, boolean _hide, double _force, boolean _sphere) {
            this.level = _level;
            this.x = _x;
            this.y = _y;
            this.z = _z;
            this.maxRadius = _maxRadius;
            this.life = _life;
            this.particle = _particle;
            this.hide = _hide;
            this.force = _force;
            this.sphere = _sphere;
        }
    }
    private static final java.util.ArrayList<_Wave> _waves = new java.util.ArrayList<>();

    // 平面冲击波: 一圈空心圆环, 从中心向外扩散; force>0 时把波前扫过的实体水平推开; hide=true 时不发粒子(只推)
    public static void ring(LevelAccessor _a, double _x, double _y, double _z, double _maxRadius, int _ticks,
            ParticleOptions _particle, boolean _hide, double _force, Entity _skip) {
        _add(_a, _x, _y, _z, _maxRadius, _ticks, _particle, _hide, _force, false, _skip);
    }
    // 球形冲击波: 一层空心球壳, 从中心向外扩散; force>0 时把波前扫过的实体沿半径方向推开(含上下); hide=true 时不发粒子(只推)
    public static void sphere(LevelAccessor _a, double _x, double _y, double _z, double _maxRadius, int _ticks,
            ParticleOptions _particle, boolean _hide, double _force, Entity _skip) {
        _add(_a, _x, _y, _z, _maxRadius, _ticks, _particle, _hide, _force, true, _skip);
    }
    private static void _add(LevelAccessor _a, double _x, double _y, double _z, double _maxRadius, int _ticks,
            ParticleOptions _particle, boolean _hide, double _force, boolean _sphere, Entity _skip) {
        if (_a == null) return;
        if (!_hide && _particle == null) return;   // 纯推力那一档不需要粒子, 所以只在会画粒子时才要
        _Wave _w = new _Wave(_a, _x, _y, _z, _maxRadius < 0.1 ? 0.1 : _maxRadius, Math.max(1, _ticks), _particle,
                _hide, _force, _sphere);
        _w.skipId = _skip == null ? null : _skip.getUUID();
        synchronized (_waves) {
            _waves.add(_w);
        }
    }
    public static void clear() {
        synchronized (_waves) {
            _waves.clear();
        }
    }

    @SubscribeEvent public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        _step(event.level);
    }
    // 客户端世界的 LevelTickEvent 不一定触发, 而玩家 tick 两侧都会调 -> 两个来源都接上
    // _step 里有"同一刻只推进一次"的判定, 所以不会被推进两遍.
    @SubscribeEvent public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        _step(event.player.level());
    }

    private static void _step(Level _level) {
        if (_level == null) return;
        java.util.ArrayList<_Wave> _snapshot;
        synchronized (_waves) {
            if (_waves.isEmpty()) return;
            _snapshot = new java.util.ArrayList<>(_waves);
        }
        long _now = _level.getGameTime();
        for (_Wave _w : _snapshot) {
            if (_w.level != _level) continue;                 // 只推进属于这一侧/这个维度的波
            if (_w.lastTick == _now) continue;                // 这一刻已经推进过(两个 tick 来源)
            _w.lastTick = _now;
            if (_w.age > _w.life) {
                synchronized (_waves) {
                    _waves.remove(_w);
                }
                continue;
            }
            double _r = _w.maxRadius * ((double) _w.age / (double) _w.life);
            _draw(_w, _level, _r);
            if (_w.force > 0.0 && _level instanceof ServerLevel _sl) _push(_sl, _w, _r);
            _w.age++;
        }
    }
    // 把实体推开. 只有服务端能推: 客户端拿不到别的实体的权威位置.
    private static void _push(ServerLevel _sl, _Wave _w, double _r) {
        double _band = Math.max(0.6, _w.maxRadius * 0.12);   // 波前厚度: 落在这一层里的才被推
        double _rr = _r + _band + 1.0;
        java.util.List<Entity> _hits = _sl.getEntities((Entity) null,
                new AABB(_w.x - _rr, _w.y - _rr, _w.z - _rr, _w.x + _rr, _w.y + _rr, _w.z + _rr));
        for (Entity _e : _hits) {
            if (_w.skipId != null && _w.skipId.equals(_e.getUUID())) continue;
            if (_e == null || !_e.isAlive()) continue;
            double _dx = _e.getX() - _w.x;
            double _dy = _e.getY() + _e.getBbHeight() * 0.5 - _w.y;
            double _dz = _e.getZ() - _w.z;
            double _d = _w.sphere ? Math.sqrt(_dx * _dx + _dy * _dy + _dz * _dz) : Math.sqrt(_dx * _dx + _dz * _dz);
            if (_d < 1.0E-4 || Math.abs(_d - _r) > _band) continue;
            if (!_w.sphere && (_dy < -1.5 || _dy > 2.5)) continue;   // 平面波只推贴着地面那一层
            double _k = _w.force / _d;
            if (_w.sphere) {
                _e.push(_dx * _k, _dy * _k, _dz * _k);       // 球形: 沿半径方向(含上下)
            } else {
                _e.push(_dx * _k, 0.0, _dz * _k);            // 平面: 只推水平方向
            }
            _e.hurtMarked = true;                            // 玩家不标这个, 客户端不会同步这份速度
        }
    }
    // 空心的一圈/一层采样点: 角度等分 + 半径完全一致, 所以扩到多大都还是正圆/正球(不是随机的椭圆)
    private static java.util.ArrayList<double[]> _points(_Wave _w, double _r) {
        java.util.ArrayList<double[]> _out = new java.util.ArrayList<>();
        if (_w.sphere) {
            double _gap = Math.max(0.6, _r / 6.0);
            int _lat = (int) Math.max(4.0, Math.min(14.0, Math.PI * _r / _gap));
            for (int _i = 0; _i <= _lat; _i++) {
                double _phi = Math.PI * (double) _i / (double) _lat;
                double _ring = Math.sin(_phi) * _r;
                int _n = _ring < 0.05 ? 1 : (int) Math.max(6.0, Math.min(28.0, 6.283185 * _ring / _gap));
                for (int _j = 0; _j < _n; _j++) {
                    double _ang = 6.283185 * (double) _j / (double) _n;
                    _out.add(new double[] { _w.x + Math.cos(_ang) * _ring, _w.y + Math.cos(_phi) * _r,
                            _w.z + Math.sin(_ang) * _ring });
                }
            }
        } else {
            int _n = (int) Math.max(32.0, Math.min(96.0, 6.283185 * _r / 0.5));
            for (int _j = 0; _j < _n; _j++) {
                double _ang = 6.283185 * (double) _j / (double) _n;
                _out.add(new double[] { _w.x + Math.cos(_ang) * _r, _w.y, _w.z + Math.sin(_ang) * _r });
            }
        }
        if (_out.size() > 140) {   // 半径很大时按步长抽稀, 免得一批发几百个粒子
            java.util.ArrayList<double[]> _cut = new java.util.ArrayList<>();
            int _stride = _out.size() / 140 + 1;
            for (int _i = 0; _i < _out.size(); _i += _stride) _cut.add(_out.get(_i));
            return _cut;
        }
        return _out;
    }
    // 每 2 刻发一批粒子(省包). 服务端发的话附近玩家都能看到(联机也成立);
    // 客户端侧建的波只有画面, 推不动实体.
    // hide=true 时整个跳过: 一个采样点都不算, 一个包都不发(纯推力).
    private static void _draw(_Wave _w, Level _level, double _r) {
        if (_w.hide) return;
        if (_w.age % 2 != 0 || _r < 0.02) return;
        java.util.ArrayList<double[]> _pts = _points(_w, _r);
        if (_level instanceof ServerLevel _sl) {
            for (double[] _p : _pts) _sl.sendParticles(_w.particle, _p[0], _p[1], _p[2], 1, 0.0, 0.0, 0.0, 0.0);
        } else {
            for (double[] _p : _pts) _level.addParticle(_w.particle, _p[0], _p[1], _p[2], 0.0, 0.0, 0.0);
        }
    }
