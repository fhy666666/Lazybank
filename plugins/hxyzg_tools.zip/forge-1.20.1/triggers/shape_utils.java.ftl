<#include "procedures.java.ftl">
public class ${name}Procedure {
    public static void fillSphere(LevelAccessor _accessor, double _x, double _y, double _z, double _radius, BlockState _state) {
        if (!(_accessor instanceof Level _level)) return;
        double _r = _radius < 0.0 ? 0.0 : _radius;
        int _ir = (int) Math.ceil(_r);
        BlockPos _center = BlockPos.containing(_x, _y, _z);
        for (BlockPos _pos : BlockPos.betweenClosed(_center.offset(-_ir, -_ir, -_ir), _center.offset(_ir, _ir, _ir))) {
            double _dx = (double) _pos.getX() + 0.5 - _x;
            double _dy = (double) _pos.getY() + 0.5 - _y;
            double _dz = (double) _pos.getZ() + 0.5 - _z;
            if (_dx * _dx + _dy * _dy + _dz * _dz <= _r * _r) _level.setBlock(_pos, _state, 3);
        }
    }
    public static void fillBox(LevelAccessor _accessor, double _x1, double _y1, double _z1, double _x2, double _y2,
            double _z2, BlockState _state) {
        if (!(_accessor instanceof Level _level)) return;
        for (BlockPos _pos : BlockPos.betweenClosed(BlockPos.containing(_x1, _y1, _z1), BlockPos.containing(_x2, _y2, _z2))) {
            _level.setBlock(_pos, _state, 3);
        }
    }
    public static void breakSphere(LevelAccessor _accessor, double _x, double _y, double _z, double _radius, boolean _drop) {
        if (!(_accessor instanceof Level _level)) return;
        double _r = _radius < 0.0 ? 0.0 : _radius;
        int _ir = (int) Math.ceil(_r);
        BlockPos _center = BlockPos.containing(_x, _y, _z);
        for (BlockPos _pos : BlockPos.betweenClosed(_center.offset(-_ir, -_ir, -_ir), _center.offset(_ir, _ir, _ir))) {
            double _dx = (double) _pos.getX() + 0.5 - _x;
            double _dy = (double) _pos.getY() + 0.5 - _y;
            double _dz = (double) _pos.getZ() + 0.5 - _z;
            if (_dx * _dx + _dy * _dy + _dz * _dz > _r * _r) continue;
            BlockState _old = _level.getBlockState(_pos);
            if (_old.isAir()) continue;
            if (_drop) Block.dropResources(_old, _level, _pos, null);
            _level.destroyBlock(_pos, false);
        }
    }
    public static void replaceBox(LevelAccessor _accessor, double _x1, double _y1, double _z1, double _x2, double _y2,
            double _z2, BlockState _from, BlockState _to) {
        if (!(_accessor instanceof Level _level)) return;
        for (BlockPos _pos : BlockPos.betweenClosed(BlockPos.containing(_x1, _y1, _z1), BlockPos.containing(_x2, _y2, _z2))) {
            if (_level.getBlockState(_pos).is(_from.getBlock())) _level.setBlock(_pos, _to, 3);
        }
    }
    public static double countEntities(LevelAccessor _accessor, double _x1, double _y1, double _z1, double _x2,
            double _y2, double _z2) {
        if (!(_accessor instanceof Level _level)) return 0.0;
        return (double) _level.getEntitiesOfClass(Entity.class, new AABB(_x1, _y1, _z1, _x2, _y2, _z2), _e -> true).size();
    }
