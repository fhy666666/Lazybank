<#include "procedures.java.ftl">
@Mod.EventBusSubscriber public class ${name}Procedure {
    private static final net.minecraft.ChatFormatting[] _GLOW = {
            net.minecraft.ChatFormatting.BLACK, net.minecraft.ChatFormatting.DARK_BLUE,
            net.minecraft.ChatFormatting.DARK_GREEN, net.minecraft.ChatFormatting.DARK_AQUA,
            net.minecraft.ChatFormatting.DARK_RED, net.minecraft.ChatFormatting.DARK_PURPLE,
            net.minecraft.ChatFormatting.GOLD, net.minecraft.ChatFormatting.GRAY,
            net.minecraft.ChatFormatting.DARK_GRAY, net.minecraft.ChatFormatting.BLUE,
            net.minecraft.ChatFormatting.GREEN, net.minecraft.ChatFormatting.AQUA,
            net.minecraft.ChatFormatting.RED, net.minecraft.ChatFormatting.LIGHT_PURPLE,
            net.minecraft.ChatFormatting.YELLOW, net.minecraft.ChatFormatting.WHITE };
    private static final int _GLOW_FLAG = 6;   // Entity.FLAG_GLOWING, 同步标志字节里的第 6 位
    // 记下"仅本机可见"的实体: 这一位会被服务端重发的整字节覆盖, 需要每刻补回来
    private static final java.util.concurrent.ConcurrentHashMap<Entity, Boolean> _local = new java.util.concurrent.ConcurrentHashMap<>();

    // 只在本机点亮发光: 客户端判断发光读的是"同步标志位"本身(getSharedFlag(6)),
    // 而 setGlowingTag() 在客户端会把这一位又写成 isCurrentlyGlowing()(还是那一位, 等于没开),
    // 所以只能直接写这一位 —— 它是 protected, 只能反射调用. 写的是本地副本,
    // 客户端不会把实体数据发回服务端, 所以别的玩家看不见.
    // 1.20.1 的 setSharedFlag 是 protected, 而且它的名字会随运行环境变: 开发环境是官方名 setSharedFlag,
    // 导出后的生产环境是 SRG 名(m_20115_) —— 只按官方名反射, 就会"测试端能亮、导出后不亮".
    // 所以先按已知名字找, 再按签名 (int, boolean) -> void 兜底, 并且真写一次读回来验证过才算数.
    private static java.lang.reflect.Method _FLAG_M;
    private static boolean _FLAG_TRIED;
    private static java.lang.reflect.Method _flagMethod(Entity _probe) {
        if (_FLAG_TRIED) return _FLAG_M;
        _FLAG_TRIED = true;
        for (String _n : new String[] { "setSharedFlag", "m_20115_", "func_20115_a" }) {
            try {
                java.lang.reflect.Method _m = Entity.class.getDeclaredMethod(_n, int.class, boolean.class);
                _m.setAccessible(true);
                _FLAG_M = _m;
                return _FLAG_M;
            } catch (Throwable _t) {
            }
        }
        boolean _cs = _probe.level() != null && _probe.level().isClientSide();
        try {
            for (java.lang.reflect.Method _m : Entity.class.getDeclaredMethods()) {
                Class<?>[] _p = _m.getParameterTypes();
                if (_p.length != 2 || _p[0] != int.class || _p[1] != boolean.class || _m.getReturnType() != void.class) continue;
                if (!_cs) {
                    _m.setAccessible(true);
                    _FLAG_M = _m;
                    return _FLAG_M;
                }
                try {
                    _m.setAccessible(true);
                    boolean _was = _probe.isCurrentlyGlowing();
                    _m.invoke(_probe, _GLOW_FLAG, !_was);
                    boolean _now = _probe.isCurrentlyGlowing();
                    _m.invoke(_probe, _GLOW_FLAG, _was);
                    if (_now != _was) {
                        _FLAG_M = _m;
                        return _FLAG_M;
                    }
                } catch (Throwable _t) {
                }
            }
        } catch (Throwable _t) {
        }
        return null;
    }

    private static void _writeLocalFlag(Entity _entity, boolean _glowing) {
        try {
            java.lang.reflect.Method _m = _flagMethod(_entity);
            _m.setAccessible(true);
            _m.invoke(_entity, _GLOW_FLAG, _glowing);
        } catch (Throwable _t) {
            // 换版本后方法改名/改签名就静默失效, 但不会崩
        }
    }
    private static void _localGlow(Entity _entity, boolean _glowing) {
        if (_entity == null) return;
        _writeLocalFlag(_entity, _glowing);
        if (_glowing) {
            _local.put(_entity, Boolean.TRUE);
        } else {
            _local.remove(_entity);
        }
    }
    // 发光位和"着火/潜行/疾跑/游泳/隐身/滑翔"挤在同一个同步字节里:
    // 只要服务端动了其中一个(比如开始/停止疾跑), 就会把这个字节整份重发给客户端,
    // 我们写在本机的那一位随之被抹掉 —— 这正是"一疾跑高光就没了"的原因.
    // 客户端每刻检查一遍, 掉了就补上(最坏情况是 1 刻的闪烁, 而不是一直消失).
    private static void _refreshLocal() {
        if (_local.isEmpty()) return;
        java.util.Iterator<java.util.Map.Entry<Entity, Boolean>> _it = _local.entrySet().iterator();
        while (_it.hasNext()) {
            java.util.Map.Entry<Entity, Boolean> _e = _it.next();
            Entity _entity = _e.getKey();
            if (_entity == null || !_entity.isAlive() || _entity.level() == null) {
                _it.remove();
                continue;
            }
            if (!_entity.isCurrentlyGlowing()) _writeLocalFlag(_entity, true);
        }
    }

    @SubscribeEvent public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (event.player.level().isClientSide()) _refreshLocal();
    }

    // 普通发光轮廓: 任何实体都能用; _local=true 时只在本机可见(不同步给别人)
    public static void setGlowing(Entity _entity, boolean _glowing, boolean _localMode) {
        if (_entity == null) return;
        if (_localMode) {
            if (!_entity.level().isClientSide()) return;   // 仅本机: 绝不碰服务端那份, 也就不会被同步
            _localGlow(_entity, _glowing);
            return;
        }
        _entity.setGlowingTag(_glowing);
        _local.remove(_entity);
    }
    public static boolean isGlowing(Entity _entity) {
        return _entity != null && _entity.isCurrentlyGlowing();
    }
    // 彩色描边: 走原版队伍颜色机制. 队伍条目必须用 Entity.getScoreboardName() ——
    // 玩家返回游戏名, 其它实体返回 UUID, 这正是原版渲染描边时查队伍用的那个键.
    // _localMode=true 时队伍写在本机记分板副本上 + 本机点灯 => 只有自己看得见.
    public static void setOutline(LevelAccessor _accessor, Entity _entity, int _colorIndex, boolean _localMode) {
        if (!(_accessor instanceof Level _level) || _entity == null) return;
        if (_localMode && !_level.isClientSide()) return;
        net.minecraft.world.scores.Scoreboard _scoreboard = _level.getScoreboard();
        int _idx = _colorIndex < 0 ? 0 : (_colorIndex >= _GLOW.length ? 0 : _colorIndex);
        String _teamName = "hxyzg_glow_" + _idx;
        net.minecraft.world.scores.PlayerTeam _team = _scoreboard.getPlayerTeam(_teamName);
        if (_team == null) _team = _scoreboard.addPlayerTeam(_teamName);
        _team.setColor(_GLOW[_idx]);
        String _entry = _entity.getScoreboardName();
        net.minecraft.world.scores.PlayerTeam _old = _scoreboard.getPlayersTeam(_entry);
        if (_old != null && _old != _team) _scoreboard.removePlayerFromTeam(_entry, _old);
        _scoreboard.addPlayerToTeam(_entry, _team);
        if (_localMode) {
            _localGlow(_entity, true);
        } else {
            _entity.setGlowingTag(true);
            _local.remove(_entity);
        }
    }
    // 清除描边: 在哪一侧调用就清哪一侧 —— 客户端调用连"仅本机可见"的那份一起清掉
    public static void clearOutline(LevelAccessor _accessor, Entity _entity) {
        if (!(_accessor instanceof Level _level) || _entity == null) return;
        net.minecraft.world.scores.Scoreboard _scoreboard = _level.getScoreboard();
        String _entry = _entity.getScoreboardName();
        net.minecraft.world.scores.PlayerTeam _old = _scoreboard.getPlayersTeam(_entry);
        if (_old != null) _scoreboard.removePlayerFromTeam(_entry, _old);
        if (_level.isClientSide()) {
            _localGlow(_entity, false);
        } else {
            _entity.setGlowingTag(false);
            _local.remove(_entity);
        }
    }
