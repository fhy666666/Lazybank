<#include "procedures.java.ftl">
public class ${name}Procedure {
    private static final java.util.HashMap<String, StructureTemplate> BLUEPRINTS = new java.util.HashMap<>();
    public static void copy(LevelAccessor _accessor, String _name, double _x1, double _y1, double _z1, double _x2,
            double _y2, double _z2, boolean _withEntities) {
        if (!(_accessor instanceof Level _level)) return;
        BlockPos _a = BlockPos.containing(_x1, _y1, _z1);
        BlockPos _b = BlockPos.containing(_x2, _y2, _z2);
        BlockPos _min = new BlockPos(Math.min(_a.getX(), _b.getX()), Math.min(_a.getY(), _b.getY()),
                Math.min(_a.getZ(), _b.getZ()));
        Vec3i _size = new Vec3i(Math.abs(_a.getX() - _b.getX()) + 1, Math.abs(_a.getY() - _b.getY()) + 1,
                Math.abs(_a.getZ() - _b.getZ()) + 1);
        StructureTemplate _template = new StructureTemplate();
        _template.fillFromWorld(_level, _min, _size, _withEntities, Blocks.STRUCTURE_VOID);
        BLUEPRINTS.put(_name, _template);
    }
    public static boolean paste(LevelAccessor _accessor, String _name, double _x, double _y, double _z, int _rotation,
            int _mirror, boolean _withEntities) {
        if (!(_accessor instanceof ServerLevel _level)) return false;
        StructureTemplate _template = BLUEPRINTS.get(_name);
        if (_template == null) return false;
        BlockPos _pos = BlockPos.containing(_x, _y, _z);
        Rotation _rot;
        switch (_rotation) {
            case 1: _rot = Rotation.CLOCKWISE_90; break;
            case 2: _rot = Rotation.CLOCKWISE_180; break;
            case 3: _rot = Rotation.COUNTERCLOCKWISE_90; break;
            default: _rot = Rotation.NONE;
        }
        Mirror _mir;
        switch (_mirror) {
            case 1: _mir = Mirror.LEFT_RIGHT; break;
            case 2: _mir = Mirror.FRONT_BACK; break;
            default: _mir = Mirror.NONE;
        }
        StructurePlaceSettings _settings = new StructurePlaceSettings().setRotation(_rot).setMirror(_mir)
                .setIgnoreEntities(!_withEntities);
        return _template.placeInWorld(_level, _pos, _pos, _settings, _level.getRandom(), 3);
    }
    public static boolean exists(String _name) {
        return BLUEPRINTS.containsKey(_name);
    }
    public static void remove(String _name) {
        BLUEPRINTS.remove(_name);
    }
    private static int _size(String _name, int _axis) {
        StructureTemplate _template = BLUEPRINTS.get(_name);
        if (_template == null) return 0;
        Vec3i _size = _template.getSize();
        if (_axis == 1) return _size.getY();
        if (_axis == 2) return _size.getZ();
        return _size.getX();
    }
    public static double sizeX(String _name) { return (double) _size(_name, 0); }
    public static double sizeY(String _name) { return (double) _size(_name, 1); }
    public static double sizeZ(String _name) { return (double) _size(_name, 2); }
