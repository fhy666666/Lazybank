<#include "procedures.java.ftl">
@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD) public class ${name}Procedure {
public static void BallParticle(Level level, Vec3 center, double radius, ParticleOptions particleType, int particleCount) {
	    double phi = Math.PI * (3.0 - Math.sqrt(5.0));
	    
	    for (int i = 0; i < particleCount; i++) {
	        double y = 1 - (i / (double)(particleCount - 1)) * 2;
	        double radiusAtY = Math.sqrt(1 - y * y);
	        
	        double theta = phi * i;
	        
	        double x = Math.cos(theta) * radiusAtY;
	        double z = Math.sin(theta) * radiusAtY;
	        
	        x = x * radius + center.x;
	        y = y * radius + center.y;
	        z = z * radius + center.z;
	        
	        level.addParticle(particleType, x, y, z, 0, 0, 0);
	    }
	}