<#include "procedures.java.ftl">
@Mod.EventBusSubscriber(Dist.CLIENT) public class ${name}Procedure {
    // ===== 光柱 LightBeam: 像信标那样的一根竖光柱 =====
    // 由本工具类自己在 RenderLevelStageEvent 里画几何, 渲染类型用 entityTranslucentEmissive:
    //   自发光(不吃世界光照, 夜里/洞里一样亮) + 没有雾(远处不糊) + 双面可见 + 支持半透明.
    // 每根光柱 = 底面中心 + 高 + 宽 + (方形/圆形) + 左右转角(可向左/向右自转) + 颜色/不透明度 + 亮度 + 贴图 + 寿命.
    // 渐入/渐出是每根光柱自己的开关(放置/显示积木里的勾选框 + 刻数): 渐入 = 出现后从透明慢慢变清;
    // 渐出 = 寿命到期、或用「清除光柱」清掉时先淡出再消失; 两个都不勾就是原来那样(立刻出现 / 立刻消失).
    // 颜色与贴图是分开的两项: 贴图留空 -> 只显示颜色(底下垫一张纯白贴图, 顶点色就是颜色);
    //                          写了贴图 -> 原样显示贴图(颜色不参与, 只有不透明度/亮度还作用在它上面).
    // 同 id(id 留空时用同坐标)再调一次 show 就是原地覆盖 -> 每刻改角度/颜色也不会闪、不会越堆越多.
    private static final int _ROUND_SEGS = 24;                 // 圆形光柱的分段数(够圆又不费)
    private static final double _SQRT2 = 1.4142135623730951D;  // 方形: 边长 = 宽 -> 外接半径 = 宽/2 * 根号2
    private static final int _MAX_BEAMS = 256;                 // 上限, 超了挤掉最旧的一根
    private static final int _LIGHT = 15728880;                // 满亮度(0xF000F0), 自发光用不上, 给顶点补上
    private static final String _WHITE = "minecraft:textures/misc/white.png";   // 没贴图时垫的纯白贴图
    private static final ResourceLocation _WHITE_RL = ResourceLocation.tryParse(_WHITE);
    private static final double _SPIN_SPEED = 45.0;            // 「向左/向右自转」的转速(度/秒), 8 秒一圈
    private static final int _FADE_DEF = 10;                   // 勾了渐入/渐出但时长没填时按 10 刻(0.5 秒)
    private static final int _FADE_MAX = 200;                  // 渐入/渐出最长 200 刻(10 秒)
    // 颜色积木给的就是 #RRGGBB; 自定义 Java 代码里还能按这些写法给 color(): 名字 / r,g,b(0~255)
    private static final String[] _NAMED = { "红,red,FF0000", "橙,orange,FF8000", "黄,yellow,FFFF00", "绿,green,00FF00",
            "青,cyan,00FFFF", "蓝,blue,0000FF", "紫,purple,8000FF", "粉,pink,FF80C0", "白,white,FFFFFF",
            "黑,black,000000", "金,gold,FFD700", "灰,gray,808080" };

    private static final class _Beam {
        final String id;             // 空 = 拿坐标当身份
        final double x, y, z;        // 底面中心
        final double born;           // 建立时的游戏刻(自转从这一刻起算)
        double height, width;        // 高(格) / 宽(格): 圆形=直径, 方形=边长
        double rotate, spin;         // 左右转角(度) / 自转速度(度每秒, 可负)
        boolean round, tile;         // 圆形? / 贴图每格重复?
        float br, bg, bb;            // 颜色(0~1): 只有"没贴图"时画它
        float alpha;                 // 不透明度(0~1)
        float bright;                // 亮度倍数(乘在颜色/贴图上, 小于 1 时也把不透明度压下去)
        String texture;              // 贴图文本(空 = 没贴图 -> 只显示颜色)
        ResourceLocation tex;        // 解析缓存(改了贴图就置空重解)
        boolean flat;                // 这次解析出来是"没贴图/贴图不认" -> 走纯色
        int ticks;                   // <=0 = 永久(用清除积木收)
        int fin;                     // 渐入刻数(0 = 不渐入)
        int fout;                    // 渐出刻数(0 = 不渐出: 到点/清除就是立刻消失)
        int foutAge = -1;            // 渐出已经走了多少刻(-1 = 还没开始渐出)
        int age;
        _Beam(String _id, double _x, double _y, double _z, double _h, double _w, boolean _round, boolean _tile,
                double _rot, double _spin, float[] _c, float _alpha, float _bright, String _tex, int _ticks,
                int _fin, int _fout, double _born) {
            this.id = _id == null ? "" : _id;
            this.x = _x;
            this.y = _y;
            this.z = _z;
            this.height = _h;
            this.width = _w;
            this.round = _round;
            this.tile = _tile;
            this.rotate = _rot;
            this.spin = _spin;
            this.br = _c[0];
            this.bg = _c[1];
            this.bb = _c[2];
            this.alpha = _alpha;
            this.bright = _bright;
            this.texture = _tex == null ? "" : _tex;
            this.ticks = _ticks;
            this.fin = _fin;
            this.fout = _fout;
            this.born = _born;
        }
    }

    private static final java.util.ArrayList<_Beam> _beams = new java.util.ArrayList<>();
    private static long _beamTick = -1L;   // 上次推进年龄的游戏刻
    private static Object _beamLevel;      // 换维度/换存档时把上一份世界的柱子清掉

    private static float _c01(double _v) {
        return _v < 0.0 ? 0.0F : (_v > 1.0 ? 1.0F : (float) _v);
    }

    private static float[] _rgb(int _r, int _g, int _b) {
        return new float[] { _c01(_r / 255.0), _c01(_g / 255.0), _c01(_b / 255.0) };
    }

    // 颜色文本 -> 颜色(0~1): #RRGGBB / #AARRGGBB / r,g,b[,a] / 名字; 认不出来就是白色.
    // 透明度不看这里: 颜色积木只给颜色, 透明用「不透明度」那一项(0~100).
    private static float[] _colorOf(String _text) {
        if (_text != null) {
            String _s = _text.trim();
            if (!_s.isEmpty()) {
                String _low = _s.toLowerCase(java.util.Locale.ROOT);
                for (String _entry : _NAMED) {
                    String[] _part = _entry.split(",");
                    for (int _i = 0; _i + 1 < _part.length; _i++) {
                        if (_part[_i].equals(_low)) {
                            long _v = Long.parseLong(_part[_part.length - 1], 16);
                            return _rgb((int) (_v >> 16 & 255L), (int) (_v >> 8 & 255L), (int) (_v & 255L));
                        }
                    }
                }
                if (_s.indexOf(',') >= 0) {
                    String[] _part = _s.split(",");
                    float[] _out = new float[] { 1.0F, 1.0F, 1.0F };
                    for (int _i = 0; _i < 3 && _i < _part.length; _i++) {
                        try {
                            _out[_i] = _c01(Double.parseDouble(_part[_i].trim()) / 255.0);
                        } catch (Exception _ex) {
                        }
                    }
                    return _out;
                }
                String _hex = _low.startsWith("#") ? _low.substring(1) : _low;
                try {
                    if (_hex.matches("[0-9a-f]{6}")) {
                        long _v = Long.parseLong(_hex, 16);
                        return _rgb((int) (_v >> 16 & 255L), (int) (_v >> 8 & 255L), (int) (_v & 255L));
                    }
                    if (_hex.matches("[0-9a-f]{8}")) {   // AARRGGBB, 前两位透明度这里不要(用不透明度那一项)
                        long _v = Long.parseLong(_hex, 16);
                        return _rgb((int) (_v >> 16 & 255L), (int) (_v >> 8 & 255L), (int) (_v & 255L));
                    }
                } catch (Exception _ex) {
                }
            }
        }
        return new float[] { 1.0F, 1.0F, 1.0F };
    }

    // 不透明度(%): 0 = 完全透明, 100 = 不透明, 超过 100 按 100 算
    private static float _alphaOf(double _percent) {
        return _c01(_percent / 100.0);
    }

    // 渐入/渐出刻数: 勾选框是开关; 勾上了但时长没填(<=0)按 10 刻, 最长 200 刻(10 秒), 不勾 = 0
    private static int _fadeOf(boolean _on, double _ticks) {
        if (!_on) return 0;
        int _t = (int) Math.round(_ticks);
        if (_t < 1) _t = _FADE_DEF;
        if (_t > _FADE_MAX) _t = _FADE_MAX;
        return _t;
    }

    /** 积木里的自转选择(NONE / LEFT / RIGHT) -> 自转速度(度/秒): 向左 = +, 向右 = - */
    public static double spinOf(String _dir) {
        String _d = _dir == null ? "" : _dir.trim().toUpperCase(java.util.Locale.ROOT);
        if (_d.equals("LEFT")) return _SPIN_SPEED;
        if (_d.equals("RIGHT")) return -_SPIN_SPEED;
        return 0.0;
    }

    // 贴图文本 -> ResourceLocation: 不写命名空间就用本模组的, .png 可省;
    // 留空 / 路径认不出来 -> null = 没贴图 -> 只画颜色
    private static ResourceLocation _texOf(String _path) {
        String _p = _path == null ? "" : _path.replace('\\', '/').trim();
        if (_p.isEmpty()) return null;
        if (!_p.contains(":")) _p = "${modid}:" + _p;
        if (!_p.endsWith(".png")) _p = _p + ".png";
        try {
            return ResourceLocation.tryParse(_p);
        } catch (Exception _ex) {
            return null;
        }
    }

    private static long _now() {
        Minecraft _mc = Minecraft.getInstance();
        return _mc.level == null ? 0L : _mc.level.getGameTime();
    }

    // 找同一根: id 非空按 id 认, id 留空按坐标认(同一个点再 show 一次就是更新它)
    private static _Beam _find(String _id, double _x, double _y, double _z) {
        boolean _byId = _id != null && !_id.trim().isEmpty();
        for (_Beam _b : _beams) {
            if (_byId) {
                if (_id.trim().equals(_b.id)) return _b;
            } else if (_b.id.isEmpty() && Math.abs(_b.x - _x) < 1.0E-3 && Math.abs(_b.y - _y) < 1.0E-3
                    && Math.abs(_b.z - _z) < 1.0E-3) {
                return _b;
            }
        }
        return null;
    }

    // 选中要改的柱子: id 非空按 id 认, 留空 = 全部(调用方必须已经 synchronized(_beams))
    private static java.util.ArrayList<_Beam> _each(String _id) {
        java.util.ArrayList<_Beam> _out = new java.util.ArrayList<>();
        boolean _byId = _id != null && !_id.trim().isEmpty();
        for (_Beam _b : _beams) {
            if (!_byId || _id.trim().equals(_b.id)) _out.add(_b);
        }
        return _out;
    }

    /** 显示/刷新一根光柱(同 id/id留空时同坐标 = 原地覆盖). 只在本机画, 联机由积木自己发包同步给别人.
        渐入/渐出刻数 0 = 不生效; 刷新一根正在渐出的光柱会把它救回来(取消渐出), 渐入不会因为刷新而重来 */
    public static void show(String _id, double _x, double _y, double _z, double _height, double _width, boolean _round,
            boolean _tile, double _rotate, double _spin, String _color, double _brightness, String _texture, int _ticks,
            double _alpha, boolean _fadeIn, double _fadeInTicks, boolean _fadeOut, double _fadeOutTicks) {
        float[] _c = _colorOf(_color);
        float _a01 = _alphaOf(_alpha);
        double _h = _height < 0.05 ? 0.05 : (_height > 4096.0 ? 4096.0 : _height);
        double _w = _width < 0.01 ? 0.01 : (_width > 64.0 ? 64.0 : _width);
        float _br = _brightness <= 0.0 ? 0.0F : (float) (_brightness > 8.0 ? 8.0 : _brightness);
        String _tex = _texture == null ? "" : _texture;
        int _life = _ticks <= 0 ? 0 : _ticks;
        int _fin = _fadeOf(_fadeIn, _fadeInTicks);
        int _fout = _fadeOf(_fadeOut, _fadeOutTicks);
        synchronized (_beams) {
            _Beam _old = _find(_id, _x, _y, _z);
            if (_old != null) {
                _old.height = _h;
                _old.width = _w;
                _old.round = _round;
                _old.tile = _tile;
                _old.rotate = _rotate;
                _old.spin = _spin;
                _old.br = _c[0];
                _old.bg = _c[1];
                _old.bb = _c[2];
                _old.alpha = _a01;
                _old.bright = _br;
                _old.texture = _tex;
                _old.tex = null;
                _old.ticks = _life;
                _old.fin = _fin;
                _old.fout = _fout;
                _old.foutAge = -1;     // 又被刷新了一次 -> 取消正在进行的渐出
                _old.age = 0;
                return;
            }
            if (_beams.size() >= _MAX_BEAMS) _beams.remove(0);
            _beams.add(new _Beam(_id, _x, _y, _z, _h, _w, _round, _tile, _rotate, _spin, _c, _a01, _br, _tex, _life,
                    _fin, _fout, _now()));
        }
    }

    /** 放置一根光柱(精简版: 只给 id/坐标/高/宽/颜色 + 渐入渐出). 没有这根就新建, 已经有了就原地刷新.
        新建时外观全用默认值(方形 / 贴图整根拉伸 / 左右转角 0 / 不自转 / 亮度 1 / 没贴图=纯色 / 永久 / 不透明);
        已经有了就只刷新位置、高、宽、颜色与渐入渐出 —— 用别的积木改过的形状/贴图/亮度/转角不会被覆盖. */
    public static void place(String _id, double _x, double _y, double _z, double _height, double _width, String _color,
            boolean _fadeIn, double _fadeInTicks, boolean _fadeOut, double _fadeOutTicks) {
        float[] _c = _colorOf(_color);
        double _h = _height < 0.05 ? 0.05 : (_height > 4096.0 ? 4096.0 : _height);
        double _w = _width < 0.01 ? 0.01 : (_width > 64.0 ? 64.0 : _width);
        int _fin = _fadeOf(_fadeIn, _fadeInTicks);
        int _fout = _fadeOf(_fadeOut, _fadeOutTicks);
        synchronized (_beams) {
            _Beam _old = _find(_id, _x, _y, _z);
            if (_old == null) {
                if (_beams.size() >= _MAX_BEAMS) _beams.remove(0);
                _beams.add(new _Beam(_id, _x, _y, _z, _h, _w, false, false, 0.0, 0.0, _c, 1.0F, 1.0F, "", 0, _fin,
                        _fout, _now()));
                return;
            }
            _old.height = _h;
            _old.width = _w;
            _old.br = _c[0];
            _old.bg = _c[1];
            _old.bb = _c[2];
            _old.fin = _fin;
            _old.fout = _fout;
            _old.foutAge = -1;         // 又放了一次 -> 取消正在进行的渐出
        }
    }

    /** 只改左右转角(度)与自转(度每秒, 负数 = 向右); id 留空 = 所有光柱 */
    public static void rotate(String _id, double _rot, double _spin) {
        synchronized (_beams) {
            for (_Beam _b : _each(_id)) {
                _b.rotate = _rot;
                _b.spin = _spin;
            }
        }
    }

    /** 只改颜色(没贴图时才看得见; 有贴图时贴图优先, 颜色不影响它); id 留空 = 所有光柱 */
    public static void color(String _id, String _color) {
        float[] _c = _colorOf(_color);
        synchronized (_beams) {
            for (_Beam _b : _each(_id)) {
                _b.br = _c[0];
                _b.bg = _c[1];
                _b.bb = _c[2];
            }
        }
    }

    /** 只改不透明度(0~100: 0 = 完全透明, 100 = 不透明); id 留空 = 所有光柱 */
    public static void alpha(String _id, double _alpha) {
        float _a01 = _alphaOf(_alpha);
        synchronized (_beams) {
            for (_Beam _b : _each(_id)) {
                _b.alpha = _a01;
            }
        }
    }

    /** 只改亮度倍数(1 = 原样); id 留空 = 所有光柱 */
    public static void brightness(String _id, double _brightness) {
        float _br = _brightness <= 0.0 ? 0.0F : (float) (_brightness > 8.0 ? 8.0 : _brightness);
        synchronized (_beams) {
            for (_Beam _b : _each(_id)) {
                _b.bright = _br;
            }
        }
    }

    /** 只换贴图(空 = 没贴图 -> 只显示颜色, 可顺带换成每格重复); id 留空 = 所有光柱 */
    public static void texture(String _id, String _texture, boolean _tile) {
        String _tex = _texture == null ? "" : _texture;
        synchronized (_beams) {
            for (_Beam _b : _each(_id)) {
                _b.texture = _tex;
                _b.tile = _tile;
                _b.tex = null;
            }
        }
    }

    /** 只改方形/圆形; id 留空 = 所有光柱 */
    public static void shape(String _id, boolean _round) {
        synchronized (_beams) {
            for (_Beam _b : _each(_id)) {
                _b.round = _round;
            }
        }
    }

    /** 清掉全部光柱(勾了「渐出」的会先淡出再消失, 没勾的立刻消失) */
    public static void clear() {
        synchronized (_beams) {
            _eachDie(null);
        }
    }

    /** 清掉指定 id 的光柱(id 留空 = 全部; 勾了「渐出」的会先淡出再消失) */
    public static void clearId(String _id) {
        synchronized (_beams) {
            _eachDie(_id);
        }
    }

    // 让一批柱子开始渐出; 没勾渐出(渐出刻数 <= 0)的直接收掉. 调用方必须已经 synchronized(_beams)
    private static void _eachDie(String _id) {
        boolean _byId = _id != null && !_id.trim().isEmpty();
        java.util.Iterator<_Beam> _it = _beams.iterator();
        while (_it.hasNext()) {
            _Beam _b = _it.next();
            if (_byId && !_id.trim().equals(_b.id)) continue;
            if (_b.fout > 0) {
                if (_b.foutAge < 0) _b.foutAge = 0;   // 从现在开始淡出
            } else {
                _it.remove();
            }
        }
    }

    /** 当前光柱数量(只算本机; 服务端流程里永远是 0) */
    public static int count() {
        synchronized (_beams) {
            return _beams.size();
        }
    }

    @SubscribeEvent public static void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        Minecraft _mc = Minecraft.getInstance();
        if (_mc.level == null) return;
        java.util.ArrayList<_Beam> _list;
        synchronized (_beams) {
            if (_beamLevel != _mc.level) {   // 换维度/换存档: 别把上一份世界的柱子带过来
                _beamLevel = _mc.level;
                _beams.clear();
            }
            if (_beams.isEmpty()) return;
            // 用游戏刻推进年龄(不是帧数), 所以"持续 N 刻"跟帧率无关
            long _nowTick = _mc.level.getGameTime();
            if (_beamTick < 0L) _beamTick = _nowTick;
            int _dt = (int) Math.max(0L, Math.min(40L, _nowTick - _beamTick));
            _beamTick = _nowTick;
            if (_dt > 0) {
                java.util.Iterator<_Beam> _it = _beams.iterator();
                while (_it.hasNext()) {
                    _Beam _b = _it.next();
                    _b.age += _dt;
                    if (_b.foutAge >= 0) {                        // 正在渐出
                        _b.foutAge += _dt;
                        if (_b.foutAge >= _b.fout) _it.remove();   // 淡完了才真的收掉
                    } else if (_b.ticks > 0 && _b.age >= _b.ticks) {
                        if (_b.fout > 0) {                        // 寿命到点了: 先渐出, 淡完再收
                            _b.foutAge = 0;
                        } else {
                            _it.remove();
                        }
                    }
                }
            }
            if (_beams.isEmpty()) return;
            _list = new java.util.ArrayList<>(_beams);
        }
        MultiBufferSource.BufferSource _buffers = _mc.renderBuffers().bufferSource();
        PoseStack _pose = event.getPoseStack();
        Vec3 _cam = event.getCamera().getPosition();
        float _pt = event.getPartialTick();
        long _game = _mc.level.getGameTime();
        for (_Beam _b : _list) {
            _draw(_buffers, _pose, _b, _cam, _pt, _game);
        }
    }

    // 一根柱子: 侧面一圈四边形. 每面都把整张贴图横向铺一遍(u 0->1), 纵向 0->v1(整根拉伸 = 1, 每格重复 = 高).
    // 方形 = 4 面(边长按"宽"), 圆形 = 24 面(直径按"宽"); 转角把整圈顶点一起转(左右转动).
    // 贴图留空 -> 垫纯白贴图 + 顶点色 = 颜色 => 画出来就是一整根纯色柱子.
    private static void _draw(MultiBufferSource.BufferSource _buffers, PoseStack _pose, _Beam _b, Vec3 _cam,
            float _pt, long _game) {
        if (_b.tex == null) {
            _b.tex = _texOf(_b.texture);
            _b.flat = _b.tex == null;          // 没贴图(或路径不认) -> 只显示颜色
            if (_b.flat) _b.tex = _WHITE_RL;
        }
        if (_b.tex == null) return;
        double _ang = Math.toRadians(_b.rotate + _b.spin * ((double) _game + (double) _pt - _b.born) / 20.0);
        double _r = _b.width * 0.5;
        double _base = 0.0;
        if (!_b.round) {   // 方形: 让四个面正对世界轴 -> 顶点从 45 度起, 外接半径放大根号2
            _r *= _SQRT2;
            _base = Math.PI * 0.25;
        }
        int _n = _b.round ? _ROUND_SEGS : 4;
        float _h = (float) _b.height;
        float _v1 = _b.tile ? _h : 1.0F;
        // 有贴图: 贴图原样(顶点色留白, 只让亮度作用在它上面); 没贴图: 顶点色 = 颜色
        float _cr = _c01((_b.flat ? _b.br : 1.0F) * _b.bright);
        float _cg = _c01((_b.flat ? _b.bg : 1.0F) * _b.bright);
        float _cb = _c01((_b.flat ? _b.bb : 1.0F) * _b.bright);
        // 渐入/渐出: 渐入从建立那一刻(_b.born)算起 -> 每刻刷新也不会把渐入卡在开头;
        // 渐出从 _b.foutAge 算起(0 -> 渐出刻数 = 1 -> 0), 两个都乘在顶点 alpha 上
        float _fade = 1.0F;
        if (_b.fin > 0) {
            double _fl = (double) _game + (double) _pt - _b.born;
            _fade = (float) (_fl <= 0.0 ? 0.0 : (_fl >= (double) _b.fin ? 1.0 : _fl / (double) _b.fin));
        }
        if (_b.fout > 0 && _b.foutAge >= 0) {
            double _fd = 1.0 - (double) _b.foutAge / (double) _b.fout;
            if (_fd < 0.0) _fd = 0.0;
            if ((float) _fd < _fade) _fade = (float) _fd;
        }
        float _ca = _c01(_b.alpha * Math.min(1.0F, _b.bright) * _fade);
        RenderType _type = RenderType.entityTranslucentEmissive(_b.tex);
        VertexConsumer _vc = _buffers.getBuffer(_type);
        _pose.pushPose();
        _pose.translate(_b.x - _cam.x, _b.y - _cam.y, _b.z - _cam.z);
        org.joml.Matrix4f _mat = _pose.last().pose();
        for (int _i = 0; _i < _n; _i++) {
            double _a1 = _base + _ang + 6.283185307179586D * (double) _i / (double) _n;
            double _a2 = _base + _ang + 6.283185307179586D * (double) (_i + 1) / (double) _n;
            double _am = (_a1 + _a2) * 0.5;
            float _x1 = (float) (Math.cos(_a1) * _r);
            float _z1 = (float) (Math.sin(_a1) * _r);
            float _x2 = (float) (Math.cos(_a2) * _r);
            float _z2 = (float) (Math.sin(_a2) * _r);
            float _nx = (float) Math.cos(_am);
            float _nz = (float) Math.sin(_am);
            _vert(_vc, _mat, _x1, 0.0F, _z1, _cr, _cg, _cb, _ca, 0.0F, 0.0F, _nx, 0.0F, _nz);
            _vert(_vc, _mat, _x2, 0.0F, _z2, _cr, _cg, _cb, _ca, 1.0F, 0.0F, _nx, 0.0F, _nz);
            _vert(_vc, _mat, _x2, _h, _z2, _cr, _cg, _cb, _ca, 1.0F, _v1, _nx, 0.0F, _nz);
            _vert(_vc, _mat, _x1, _h, _z1, _cr, _cg, _cb, _ca, 0.0F, _v1, _nx, 0.0F, _nz);
        }
        _pose.popPose();
        // 自己取的渲染类型自己收尾(1.20.1 的 BufferSource 对非 fixed 类型是共享 builder)
        _buffers.endBatch(_type);
    }

    private static void _vert(VertexConsumer _vc, org.joml.Matrix4f _mat, float _x, float _y, float _z, float _r,
            float _g, float _b, float _a, float _u, float _v, float _nx, float _ny, float _nz) {
        _vc.vertex(_mat, _x, _y, _z).color((int) (_r * 255.0F), (int) (_g * 255.0F), (int) (_b * 255.0F),
                (int) (_a * 255.0F)).uv(_u, _v).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(_LIGHT)
                .normal(_nx, _ny, _nz).endVertex();
    }

// ===== HX_SYNC: 本工具类的渲染同步重放注册(只在客户端加载时执行一次) =====
static {
	RegPacketProcedure.hxRegister("lightbeam.show", _d -> show(RegPacketProcedure.hxS(_d, "s0"), RegPacketProcedure.hxN(_d, "a0"), RegPacketProcedure.hxN(_d, "a1"), RegPacketProcedure.hxN(_d, "a2"), RegPacketProcedure.hxN(_d, "a3"), RegPacketProcedure.hxN(_d, "a4"), RegPacketProcedure.hxB(_d, "a5"), RegPacketProcedure.hxB(_d, "a6"), RegPacketProcedure.hxN(_d, "a7"), RegPacketProcedure.hxN(_d, "a8"), RegPacketProcedure.hxS(_d, "s1"), RegPacketProcedure.hxN(_d, "a9"), RegPacketProcedure.hxS(_d, "s2"), RegPacketProcedure.hxI(_d, "a10"), RegPacketProcedure.hxN(_d, "a11"), RegPacketProcedure.hxB(_d, "a12"), RegPacketProcedure.hxN(_d, "a13"), RegPacketProcedure.hxB(_d, "a14"), RegPacketProcedure.hxN(_d, "a15")));
	RegPacketProcedure.hxRegister("lightbeam.place", _d -> place(RegPacketProcedure.hxS(_d, "s0"), RegPacketProcedure.hxN(_d, "a0"), RegPacketProcedure.hxN(_d, "a1"), RegPacketProcedure.hxN(_d, "a2"), RegPacketProcedure.hxN(_d, "a3"), RegPacketProcedure.hxN(_d, "a4"), RegPacketProcedure.hxS(_d, "s1"), RegPacketProcedure.hxB(_d, "a5"), RegPacketProcedure.hxN(_d, "a6"), RegPacketProcedure.hxB(_d, "a7"), RegPacketProcedure.hxN(_d, "a8")));
	RegPacketProcedure.hxRegister("lightbeam.rotate", _d -> rotate(RegPacketProcedure.hxS(_d, "s0"), RegPacketProcedure.hxN(_d, "a0"), RegPacketProcedure.hxN(_d, "a1")));
	RegPacketProcedure.hxRegister("lightbeam.color", _d -> color(RegPacketProcedure.hxS(_d, "s0"), RegPacketProcedure.hxS(_d, "s1")));
	RegPacketProcedure.hxRegister("lightbeam.alpha", _d -> alpha(RegPacketProcedure.hxS(_d, "s0"), RegPacketProcedure.hxN(_d, "a0")));
	RegPacketProcedure.hxRegister("lightbeam.brightness", _d -> brightness(RegPacketProcedure.hxS(_d, "s0"), RegPacketProcedure.hxN(_d, "a0")));
	RegPacketProcedure.hxRegister("lightbeam.texture", _d -> texture(RegPacketProcedure.hxS(_d, "s0"), RegPacketProcedure.hxS(_d, "s1"), RegPacketProcedure.hxB(_d, "a0")));
	RegPacketProcedure.hxRegister("lightbeam.shape", _d -> shape(RegPacketProcedure.hxS(_d, "s0"), RegPacketProcedure.hxB(_d, "a0")));
	RegPacketProcedure.hxRegister("lightbeam.clear", _d -> clear());
	RegPacketProcedure.hxRegister("lightbeam.clearid", _d -> clearId(RegPacketProcedure.hxS(_d, "s0")));
}
