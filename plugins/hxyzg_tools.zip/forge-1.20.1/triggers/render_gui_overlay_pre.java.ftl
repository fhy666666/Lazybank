<#include "procedures.java.ftl">
@Mod.EventBusSubscriber(value={Dist.CLIENT}) public class ${name}Procedure {
	@SubscribeEvent public static void onRenderGuiOverlayPre(RenderGuiOverlayEvent.Pre event) {
		<#assign dependenciesCode><#compress>
			<@procedureDependenciesCode dependencies, {
				"entity": "Minecraft.getInstance().player",
				"world": "Minecraft.getInstance().level",
				"event": "event"
				}/>
		</#compress></#assign>
		execute(event<#if dependenciesCode?has_content>,</#if>${dependenciesCode});
	}
