<#include "procedures.java.ftl">
@Mod.EventBusSubscriber(Dist.CLIENT) public class ${name}Procedure {
    // 一具残影: 出生位置(世界坐标) + 出生时朝向 + 年龄(游戏刻)
    private static final class _Ghost {
        final double x, y, z;
        final float yaw;
        int age;
        _Ghost(double _x, double _y, double _z, float _yaw) {
            this.x = _x;
            this.y = _y;
            this.z = _z;
            this.yaw = _yaw;
        }
    }
    // 每个实体一份状态: 已生成的残影 + 上次生成点(间距按"走过的距离"算, 与帧率/速度无关)
    private static final class _Ai {
        final java.util.concurrent.ConcurrentLinkedDeque<_Ghost> ghosts = new java.util.concurrent.ConcurrentLinkedDeque<>();
        int max = 5;
        int duration = 0;
        double spacing = 0.0;
        double lastX, lastY, lastZ;
        long lastSlot = -1L;
        long lastTime = -1L;
    }
    // start()/stop() 可能来自服务端线程, 渲染钩子在渲染线程 -> 用并发容器, 别让渲染线程炸掉
    private static final java.util.concurrent.ConcurrentHashMap<Entity, _Ai> _ai = new java.util.concurrent.ConcurrentHashMap<>();
    private static final int _MAX_GHOSTS = 64;   // 持续=0(永久)时的上限, 防止无限堆积

    // _max      最多同时画几个(1~16)
    // _spacing  每走多少格留一个残影; 小于等于 0 表示不限, 每 2 刻留一个
    // _duration 每个残影活多少刻; 小于等于 0 表示永久(直到 stop)
    public static void start(Entity _entity, int _max, double _spacing, int _duration) {
        if (_entity == null) return;
        _Ai _a = new _Ai();
        _a.max = _max < 1 ? 1 : (_max > 16 ? 16 : _max);
        _a.spacing = _spacing;
        _a.duration = _duration;
        _a.lastX = _entity.getX();
        _a.lastY = _entity.getY();
        _a.lastZ = _entity.getZ();
        _ai.put(_entity, _a);
    }
    public static void stop(Entity _entity) {
        if (_entity != null) _ai.remove(_entity);
    }
    public static boolean isActive(Entity _entity) {
        return _entity != null && _ai.containsKey(_entity);
    }
    public static void clearAll() {
        _ai.clear();
    }
    private static void _add(_Ai _a, double _x, double _y, double _z, float _yaw) {
        _a.ghosts.addFirst(new _Ghost(_x, _y, _z, _yaw));
        while (_a.ghosts.size() > _MAX_GHOSTS) _a.ghosts.removeLast();
    }
    private static void _record(Minecraft _mc) {
        if (_ai.isEmpty() || _mc.level == null) return;
        long _now = _mc.level.getGameTime();
        for (java.util.Map.Entry<Entity, _Ai> _e : _ai.entrySet()) {
            Entity _entity = _e.getKey();
            _Ai _a = _e.getValue();
            if (_entity == null || !_entity.isAlive() || _entity.level() != _mc.level) {
                _ai.remove(_entity);
                continue;
            }
            // 老化按游戏刻推进(与帧率无关), 到点删掉
            int _dt = _a.lastTime < 0L ? 0 : (int) Math.max(0L, Math.min(40L, _now - _a.lastTime));
            _a.lastTime = _now;
            if (_dt > 0) {
                java.util.Iterator<_Ghost> _it = _a.ghosts.iterator();
                while (_it.hasNext()) {
                    _Ghost _g = _it.next();
                    _g.age += _dt;
                    if (_a.duration > 0 && _g.age >= _a.duration) _it.remove();
                }
            }
            double _cx = _entity.getX(), _cy = _entity.getY(), _cz = _entity.getZ();
            float _yaw = _entity.getYRot();
            if (_a.spacing > 0.0) {
                // 沿着"上次生成点 -> 当前位置"这条直线每 spacing 格插一个: 走得快间距也不会被拉开
                int _guard = 0;
                while (_guard++ < 8) {
                    double _dx = _cx - _a.lastX, _dy = _cy - _a.lastY, _dz = _cz - _a.lastZ;
                    double _d = Math.sqrt(_dx * _dx + _dy * _dy + _dz * _dz);
                    if (_d < _a.spacing) break;
                    double _f = _a.spacing / _d;
                    _a.lastX += _dx * _f;
                    _a.lastY += _dy * _f;
                    _a.lastZ += _dz * _f;
                    _add(_a, _a.lastX, _a.lastY, _a.lastZ, _yaw);
                }
            } else {
                // 间距不限: 每 2 个游戏刻留一个(用时间槽而不是帧数, 高帧率下不会刷爆)
                long _slot = _now / 2L;
                if (_a.lastSlot < 0L) _a.lastSlot = _slot;
                if (_slot != _a.lastSlot) {
                    _a.lastSlot = _slot;
                    _add(_a, _cx, _cy, _cz, _yaw);
                }
            }
        }
    }
    @SubscribeEvent public static void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        Minecraft _mc = Minecraft.getInstance();
        if (_mc.level == null) return;
        _record(_mc);
        if (_ai.isEmpty()) return;
        PoseStack _pose = event.getPoseStack();
        Vec3 _camera = event.getCamera().getPosition();
        MultiBufferSource _buffers = _mc.renderBuffers().bufferSource();
        // 第一人称下自己的残影一律不画: 相机就包在自己模型里, 画出来就是自己的脸糊满屏幕,
        // 判定用 UUID(不是对象相等): 单人存档里客户端/服务端两份玩家对象都认得出. 记录照旧, 切第三人称正常显示.
        Entity _camEntity = _mc.player != null ? _mc.player : _mc.getCameraEntity();
        boolean _firstPerson = _mc.options.getCameraType().isFirstPerson();
        for (java.util.Map.Entry<Entity, _Ai> _e : _ai.entrySet()) {
            Entity _entity = _e.getKey();
            if (_entity == null || !_entity.isAlive()) continue;
            if (_firstPerson && (_entity == _camEntity || (_camEntity != null && _entity.getUUID().equals(_camEntity.getUUID())))) continue;
            _Ai _a = _e.getValue();
            int _drawn = 0;
            for (_Ghost _g : _a.ghosts) {
                if (_drawn >= _a.max) break;
                if (_insideGhost(_entity, _g.x, _g.y, _g.z, _camera)) continue;   // 相机已经陷进这一具里
                if (_onBody(_entity, _g.x, _g.y, _g.z)) continue;                // 这一具就叠在本体身上
                float _fade;
                if (_a.duration > 0) {
                    _fade = 0.8f * (1.0f - (float) _g.age / (float) _a.duration); // 按年龄线性淡出
                } else {
                    _fade = 0.8f - 0.06f * _drawn;                                // 永久残影: 越旧越淡
                }
                if (_fade < 0.2f) _fade = 0.2f;
                if (_fade > 0.85f) _fade = 0.85f;
                RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, _fade);
                _ghost(_mc, _entity, _g, _camera, _pose, _buffers);
                _drawn++;
            }
        }
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);   // 复位, 别影响后面的渲染
    }
    // 相机是否已经陷进这具残影的身体里(横向在身体半径内, 纵向在身体高度内).
    // 这种残影画出来就是一张皮肤贴图糊在眼前, 所以这一具直接跳过.
    private static boolean _insideGhost(Entity _entity, double _x, double _y, double _z, Vec3 _camera) {
        double _dx = _x - _camera.x;
        double _dz = _z - _camera.z;
        double _r = Math.max(0.45, (double) _entity.getBbWidth() * 0.5 + 0.05);
        if (_dx * _dx + _dz * _dz > _r * _r) return false;
        double _dy = _camera.y - _y;
        return _dy > -0.4 && _dy < (double) _entity.getBbHeight() + 0.4;
    }
    // 这一具是不是落在本体自己身上(横向在身体范围内, 纵向在身高范围内):
    // 潜行/站立时残影几乎和当前坐标重合, 画出来就是几层皮肤贴图叠在自己身上、糊在脚下.
    // 潜行时模型前倾、视觉占位更大, 判定半径再放大 0.5 格.
    private static boolean _onBody(Entity _entity, double _x, double _y, double _z) {
        double _dx = _x - _entity.getX();
        double _dz = _z - _entity.getZ();
        double _r = Math.max(0.9, (double) _entity.getBbWidth() * 1.5);
        if (_entity.isCrouching()) _r += 0.5;
        if (_dx * _dx + _dz * _dz > _r * _r) return false;
        double _dy = _y - _entity.getY();
        return _dy > -0.6 && _dy < (double) _entity.getBbHeight() + 0.6;
    }
    // 只把"本体皮肤"的渲染类型换成半透明剔除版(不让体内表面透出来); 手持物品/盔甲/披风等层原样返回,
    // 否则它们会被套上皮肤贴图 —— 武器/披风本身就是薄片, 画出来正好就是一块平面的皮肤贴图.
    private static RenderType _ghostType(RenderType _type, ResourceLocation _skin) {
        if (_type == null
                || _type == RenderType.entityCutoutNoCull(_skin) || _type == RenderType.entityCutout(_skin)
                || _type == RenderType.entitySolid(_skin) || _type == RenderType.entityTranslucent(_skin)
                || _type == RenderType.entityTranslucentCull(_skin) || _type == RenderType.entityTranslucentEmissive(_skin)
                || _type == RenderType.itemEntityTranslucentCull(_skin) || _type == RenderType.outline(_skin))
            return RenderType.entityTranslucentCull(_skin);
        return _type;
    }
    @SuppressWarnings("unchecked")
    private static void _ghost(Minecraft _mc, Entity _entity, _Ghost _g, Vec3 _camera, PoseStack _pose,
            MultiBufferSource _buffers) {
        net.minecraft.client.renderer.entity.EntityRenderDispatcher _dispatcher = _mc.getEntityRenderDispatcher();
        net.minecraft.client.renderer.entity.EntityRenderer<Entity> _renderer =
                (net.minecraft.client.renderer.entity.EntityRenderer<Entity>) _dispatcher.getRenderer(_entity);
        ResourceLocation _texture = _renderer.getTextureLocation(_entity);
        MultiBufferSource _ghostBuffers = _type -> _buffers.getBuffer(_ghostType(_type, _texture));
        _pose.pushPose();
        _pose.translate(_g.x - _camera.x, _g.y - _camera.y, _g.z - _camera.z);
        _dispatcher.render(_entity, 0.0, 0.0, 0.0, _g.yaw, 1.0f, _pose, _ghostBuffers,
                LevelRenderer.getLightColor(_mc.level, BlockPos.containing(_g.x, _g.y, _g.z)));
        _pose.popPose();
    }

// ===== HX_SYNC: 本工具类的渲染同步重放注册(只在客户端加载时执行一次) =====
static {
	RegPacketProcedure.hxRegister("afterimage.start", _d -> { net.minecraft.world.entity.Entity _e = RegPacketProcedure.hxEnt(_d); if (_e != null) start(_e, RegPacketProcedure.hxI(_d, "a0"), RegPacketProcedure.hxN(_d, "a1"), RegPacketProcedure.hxI(_d, "a2")); });
	RegPacketProcedure.hxRegister("afterimage.stop", _d -> { net.minecraft.world.entity.Entity _e = RegPacketProcedure.hxEnt(_d); if (_e != null) stop(_e); });
}
