<#include "procedures.java.ftl">
public class ${name}Procedure {
    public static HitResult trace(Entity _entity, double _range, boolean _throughBlocks, boolean _throughLiquid) {
        Vec3 _from = _entity.getEyePosition(1f);
        Vec3 _to = _from.add(_entity.getViewVector(1f).scale(_range));
        BlockHitResult _blockHit = _entity.level().clip(new ClipContext(_from, _to,
                _throughBlocks ? ClipContext.Block.COLLIDER : ClipContext.Block.OUTLINE,
                _throughLiquid ? ClipContext.Fluid.NONE : ClipContext.Fluid.ANY, _entity));
        Entity _entityHit = findEntity(_entity, _from, _to, null);
        if (_entityHit == null) return _blockHit;
        if (!_throughBlocks && _blockHit != null && _blockHit.getType() != HitResult.Type.MISS
                && _from.distanceToSqr(_blockHit.getLocation()) <= _from.distanceToSqr(_entityHit.position()))
            return _blockHit;
        return new EntityHitResult(_entityHit);
    }
    public static Entity findEntity(Entity _entity, Vec3 _from, Vec3 _to, Entity _exclude) {
        AABB _search = _entity.getBoundingBox().expandTowards(_to.subtract(_from)).inflate(1.0);
        Entity _best = null;
        double _bestDistance = Double.MAX_VALUE;
        for (Entity _candidate : _entity.level().getEntitiesOfClass(Entity.class, _search,
                _e -> _e != _entity && _e != _exclude && _e.isAlive())) {
            java.util.Optional<Vec3> _hit = _candidate.getBoundingBox().inflate(0.3).clip(_from, _to);
            if (_hit.isPresent()) {
                double _distance = _from.distanceToSqr(_hit.get());
                if (_distance < _bestDistance) {
                    _bestDistance = _distance;
                    _best = _candidate;
                }
            }
        }
        return _best;
    }
    public static Entity traceEntity(Entity _entity, double _range, boolean _throughBlocks, boolean _throughLiquid) {
        HitResult _result = trace(_entity, _range, _throughBlocks, _throughLiquid);
        return _result instanceof EntityHitResult _entityHit ? _entityHit.getEntity() : null;
    }
    public static Entity traceEntityExcluding(Entity _entity, double _range, boolean _throughBlocks,
            boolean _throughLiquid, Entity _exclude) {
        Vec3 _from = _entity.getEyePosition(1f);
        Vec3 _to = _from.add(_entity.getViewVector(1f).scale(_range));
        Entity _hit = findEntity(_entity, _from, _to, _exclude);
        if (_hit == null) return null;
        if (!_throughBlocks) {
            BlockHitResult _blockHit = _entity.level().clip(new ClipContext(_from, _to, ClipContext.Block.OUTLINE,
                    _throughLiquid ? ClipContext.Fluid.NONE : ClipContext.Fluid.ANY, _entity));
            if (_blockHit != null && _blockHit.getType() != HitResult.Type.MISS
                    && _from.distanceToSqr(_blockHit.getLocation()) <= _from.distanceToSqr(_hit.position()))
                return null;
        }
        return _hit;
    }
    public static double hitX(Entity _entity, double _range, boolean _throughBlocks, boolean _throughLiquid) {
        Vec3 _location = trace(_entity, _range, _throughBlocks, _throughLiquid).getLocation();
        return _location.x;
    }
    public static double hitY(Entity _entity, double _range, boolean _throughBlocks, boolean _throughLiquid) {
        Vec3 _location = trace(_entity, _range, _throughBlocks, _throughLiquid).getLocation();
        return _location.y;
    }
    public static double hitZ(Entity _entity, double _range, boolean _throughBlocks, boolean _throughLiquid) {
        Vec3 _location = trace(_entity, _range, _throughBlocks, _throughLiquid).getLocation();
        return _location.z;
    }
    public static boolean hasHit(Entity _entity, double _range, boolean _throughBlocks, boolean _throughLiquid) {
        return trace(_entity, _range, _throughBlocks, _throughLiquid).getType() != HitResult.Type.MISS;
    }
    public static boolean hitIsEntity(Entity _entity, double _range, boolean _throughBlocks, boolean _throughLiquid) {
        return trace(_entity, _range, _throughBlocks, _throughLiquid) instanceof EntityHitResult;
    }
    public static HitResult traceFrom(LevelAccessor _accessor, double _x, double _y, double _z, double _dx, double _dy,
            double _dz, double _range, boolean _throughBlocks, boolean _throughLiquid) {
        if (!(_accessor instanceof Level _level)) return null;
        double _len = Math.sqrt(_dx * _dx + _dy * _dy + _dz * _dz);
        if (_len < 1.0E-6) return null;
        Vec3 _from = new Vec3(_x, _y, _z);
        Vec3 _to = _from.add(_dx / _len * _range, _dy / _len * _range, _dz / _len * _range);
        BlockHitResult _blockHit = _level.clip(new ClipContext(_from, _to,
                _throughBlocks ? ClipContext.Block.COLLIDER : ClipContext.Block.OUTLINE,
                _throughLiquid ? ClipContext.Fluid.NONE : ClipContext.Fluid.ANY, (Entity) null));
        Entity _entityHit = findEntityAt(_level, _from, _to, null);
        if (_entityHit == null) return _blockHit;
        if (!_throughBlocks && _blockHit != null && _blockHit.getType() != HitResult.Type.MISS
                && _from.distanceToSqr(_blockHit.getLocation()) <= _from.distanceToSqr(_entityHit.position()))
            return _blockHit;
        return new EntityHitResult(_entityHit);
    }
    public static Entity findEntityAt(Level _level, Vec3 _from, Vec3 _to, Entity _exclude) {
        AABB _search = new AABB(_from, _to).inflate(1.0);
        Entity _best = null;
        double _bestDistance = Double.MAX_VALUE;
        for (Entity _candidate : _level.getEntitiesOfClass(Entity.class, _search, _e -> _e != _exclude && _e.isAlive())) {
            java.util.Optional<Vec3> _hit = _candidate.getBoundingBox().inflate(0.3).clip(_from, _to);
            if (_hit.isPresent()) {
                double _distance = _from.distanceToSqr(_hit.get());
                if (_distance < _bestDistance) {
                    _bestDistance = _distance;
                    _best = _candidate;
                }
            }
        }
        return _best;
    }
    private static java.util.List<EntityHitResult> _allHits(Entity _caster, Vec3 _from, Vec3 _to) {
        java.util.List<EntityHitResult> _list = new java.util.ArrayList<>();
        AABB _search = _caster.getBoundingBox().expandTowards(_to.subtract(_from)).inflate(1.0);
        for (Entity _candidate : _caster.level().getEntitiesOfClass(Entity.class, _search, _e -> _e != _caster && _e.isAlive())) {
            java.util.Optional<Vec3> _hit = _candidate.getBoundingBox().inflate(0.3).clip(_from, _to);
            if (_hit.isPresent()) _list.add(new EntityHitResult(_candidate, _hit.get()));
        }
        final Vec3 _origin = _from;
        _list.sort(java.util.Comparator.comparingDouble(_h -> _origin.distanceToSqr(_h.getLocation())));
        return _list;
    }
    private static Entity _traceDirection(Entity _entity, Vec3 _from, Vec3 _dir, double _range, boolean _throughBlocks,
            boolean _throughLiquid) {
        double _len = Math.sqrt(_dir.x * _dir.x + _dir.y * _dir.y + _dir.z * _dir.z);
        if (_len < 1.0E-6) return null;
        Vec3 _to = _from.add(_dir.x / _len * _range, _dir.y / _len * _range, _dir.z / _len * _range);
        BlockHitResult _blockHit = _entity.level().clip(new ClipContext(_from, _to,
                _throughBlocks ? ClipContext.Block.COLLIDER : ClipContext.Block.OUTLINE,
                _throughLiquid ? ClipContext.Fluid.NONE : ClipContext.Fluid.ANY, _entity));
        Entity _hit = findEntityAt(_entity.level(), _from, _to, _entity);
        if (_hit == null) return null;
        if (!_throughBlocks && _blockHit != null && _blockHit.getType() != HitResult.Type.MISS
                && _from.distanceToSqr(_blockHit.getLocation()) <= _from.distanceToSqr(_hit.position()))
            return null;
        return _hit;
    }
    public static Entity entityFrom(LevelAccessor _accessor, double _x, double _y, double _z, double _dx, double _dy,
            double _dz, double _range, boolean _throughBlocks, boolean _throughLiquid) {
        HitResult _result = traceFrom(_accessor, _x, _y, _z, _dx, _dy, _dz, _range, _throughBlocks, _throughLiquid);
        return _result instanceof EntityHitResult ? ((EntityHitResult) _result).getEntity() : null;
    }
    public static Entity towards(Entity _entity, double _x, double _y, double _z, double _range, boolean _throughBlocks,
            boolean _throughLiquid) {
        if (_entity == null) return null;
        Vec3 _from = _entity.getEyePosition(1f);
        return _traceDirection(_entity, _from, new Vec3(_x, _y, _z).subtract(_from), _range, _throughBlocks,
                _throughLiquid);
    }
    public static Entity towardsEntity(Entity _entity, Entity _target, double _range, boolean _throughBlocks,
            boolean _throughLiquid) {
        if (_entity == null || _target == null) return null;
        Vec3 _from = _entity.getEyePosition(1f);
        Vec3 _aim = _target.position().add(0.0, (double) _target.getBbHeight() * 0.5, 0.0);
        return _traceDirection(_entity, _from, _aim.subtract(_from), _range, _throughBlocks, _throughLiquid);
    }
    public static Entity nthEntity(Entity _entity, double _range, int _index, boolean _throughLiquid) {
        if (_entity == null) return null;
        Vec3 _from = _entity.getEyePosition(1f);
        Vec3 _to = _from.add(_entity.getViewVector(1f).scale(_range));
        java.util.List<EntityHitResult> _hits = _allHits(_entity, _from, _to);
        if (_index < 0 || _index >= _hits.size()) return null;
        return _hits.get(_index).getEntity();
    }
    public static double countEntities(Entity _entity, double _range, boolean _throughLiquid) {
        if (_entity == null) return 0.0;
        Vec3 _from = _entity.getEyePosition(1f);
        Vec3 _to = _from.add(_entity.getViewVector(1f).scale(_range));
        return (double) _allHits(_entity, _from, _to).size();
    }
    public static Entity spread(Entity _entity, double _range, double _spreadDegrees, boolean _throughBlocks,
            boolean _throughLiquid) {
        if (_entity == null) return null;
        Vec3 _from = _entity.getEyePosition(1f);
        Vec3 _look = _entity.getViewVector(1f);
        double _spread = _spreadDegrees < 0.0 ? 0.0 : (_spreadDegrees > 180.0 ? 180.0 : _spreadDegrees);
        double _u = Math.random() * 2.0 - 1.0;
        double _theta = Math.random() * Math.PI * 2.0;
        double _s = Math.sqrt(1.0 - _u * _u);
        Vec3 _random = new Vec3(_s * Math.cos(_theta), _s * Math.sin(_theta), _u);
        Vec3 _dir = _look.add(_random.scale(Math.tan(Math.toRadians(_spread))));
        return _traceDirection(_entity, _from, _dir, _range, _throughBlocks, _throughLiquid);
    }
    public static double hitDistance(Entity _entity, double _range, boolean _throughBlocks, boolean _throughLiquid) {
        HitResult _result = trace(_entity, _range, _throughBlocks, _throughLiquid);
        if (_result == null || _result.getType() == HitResult.Type.MISS) return -1.0;
        return _entity.getEyePosition(1f).distanceTo(_result.getLocation());
    }
    public static Direction hitFace(Entity _entity, double _range, boolean _throughBlocks, boolean _throughLiquid) {
        HitResult _result = trace(_entity, _range, _throughBlocks, _throughLiquid);
        if (_result instanceof BlockHitResult && ((BlockHitResult) _result).getType() != HitResult.Type.MISS)
            return ((BlockHitResult) _result).getDirection();
        return null;
    }
    public static boolean visibleBetween(LevelAccessor _accessor, double _x1, double _y1, double _z1, double _x2, double _y2,
            double _z2) {
        if (!(_accessor instanceof Level _level)) return false;
        BlockHitResult _hit = _level.clip(new ClipContext(new Vec3(_x1, _y1, _z1), new Vec3(_x2, _y2, _z2),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, (Entity) null));
        return _hit.getType() == HitResult.Type.MISS;
    }
    public static Entity entityOfClass(Entity _entity, double _range, Class<? extends Entity> _type,
            boolean _throughBlocks, boolean _throughLiquid) {
        if (_entity == null || _type == null) return null;
        Vec3 _from = _entity.getEyePosition(1f);
        Vec3 _to = _from.add(_entity.getViewVector(1f).scale(_range));
        BlockHitResult _blockHit = _entity.level().clip(new ClipContext(_from, _to,
                _throughBlocks ? ClipContext.Block.COLLIDER : ClipContext.Block.OUTLINE,
                _throughLiquid ? ClipContext.Fluid.NONE : ClipContext.Fluid.ANY, _entity));
        AABB _search = _entity.getBoundingBox().expandTowards(_to.subtract(_from)).inflate(1.0);
        Entity _best = null;
        double _bestDistance = Double.MAX_VALUE;
        for (Entity _candidate : _entity.level().getEntitiesOfClass(Entity.class, _search,
                _e -> _e != _entity && _e.isAlive() && _type.isInstance(_e))) {
            java.util.Optional<Vec3> _hit = _candidate.getBoundingBox().inflate(0.3).clip(_from, _to);
            if (_hit.isPresent()) {
                double _distance = _from.distanceToSqr(_hit.get());
                if (_distance < _bestDistance) {
                    _bestDistance = _distance;
                    _best = _candidate;
                }
            }
        }
        if (_best == null) return null;
        if (!_throughBlocks && _blockHit != null && _blockHit.getType() != HitResult.Type.MISS
                && _from.distanceToSqr(_blockHit.getLocation()) <= _from.distanceToSqr(_best.position()))
            return null;
        return _best;
    }
