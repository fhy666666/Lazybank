<#include "procedures.java.ftl">
@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD) public class ${name}Procedure {
private void fixAttributes() {
	Attribute[] attributesToFix = new Attribute[]{
		Attributes.MAX_HEALTH,
		Attributes.FOLLOW_RANGE,
		Attributes.KNOCKBACK_RESISTANCE,
		Attributes.MOVEMENT_SPEED,
		Attributes.FLYING_SPEED,
		Attributes.ATTACK_DAMAGE,
		Attributes.ATTACK_SPEED,
		Attributes.ARMOR,
		Attributes.ARMOR_TOUGHNESS,
		Attributes.LUCK
	};

	try {
	    Class<?> rangedClass = RangedAttribute.class;
	    Field maxField = null;

	    String[] possibleNames = {
		    "f_22308_",
		    "maxValue"
	    };

	    for (String name : possibleNames) {
		try {
		    maxField = rangedClass.getDeclaredField(name);
		    break;
		} catch (NoSuchFieldException ignored) {
		}
	    }

	    if (maxField == null) {
		throw new RuntimeException("AttributeFix: 无法获取最大值的字段 (No Get maximumValue)");
	    }

	    maxField.setAccessible(true);
	    double newMax = Double.MAX_VALUE;

	    for (Attribute attribute : attributesToFix) {
		if (rangedClass.isInstance(attribute)) {
		    maxField.setDouble(attribute, newMax);
		}
	    }

	} catch (Exception e) {
	    throw new RuntimeException("AttributeFix Max No Break", e);
	}
}

@SubscribeEvent
public static void init(FMLCommonSetupEvent event) {
	event.enqueueWork(() -> {
	    new ${name}Procedure().fixAttributes();
	});
}
