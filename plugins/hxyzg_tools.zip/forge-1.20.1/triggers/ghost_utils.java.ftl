<#include "procedures.java.ftl">
<#--
  「虚影」工具类(客户端渲染). 用法: 在工作区里建一个代码名为 GhostUtils 的「全局触发器」流程,
  触发器选「注册虚影工具类」, 此流程内不要放积木; 7 个虚影积木生成的代码就会调用下面的方法.

  虚影 = 把本体再画一遍: 同一个实体对象、同一个渲染器、同一帧的姿势, 所以动作 / 皮肤 / 装备 / 手里的东西
  全都与本体一模一样; 画之前先平移到「背后 / 头顶」的落点、按倍率缩放、把渲染类型换成半透明并乘上不透明度.
  只做客户端: 状态存在客户端表里, 靠 RegPacketProcedure 的 HX_SYNC 同步给附近玩家.
  注意: 类体故意不闭合 —— 生成器会在后面追加 execute 方法再补最后的 }.
-->
@Mod.EventBusSubscriber(Dist.CLIENT) public class ${name}Procedure {
	// ===== 一具虚影的状态 =====
	private static final class _G {
		double sw;		// 宽度倍率
		double sh;		// 高度倍率
		double alpha;	// 不透明度 0..1
		int place;		// 0 = 背后, 1 = 头顶
		double dist;	// 离本体的距离(格)
		double offsetY;	// Y 轴偏移(格, 正数往上、负数往下; 两档位置都生效)
		int life;		// 持续刻数, 0 = 一直显示
		long born;		// 出生时的游戏刻(算寿命用)
	}

	// 每个实体一具虚影(同一实体再 start 一次 = 原地换参数, 不会叠出两具).
	// start()/setXxx() 可能来自服务端线程(积木在服务端跑), 渲染钩子在渲染线程 -> 用并发容器.
	// 换维度 / 退出重进: 旧实体的 level() 不再是当前客户端世界, 循环里会把它们逐个摘掉.
	private static final java.util.concurrent.ConcurrentHashMap<Entity, _G> _gs = new java.util.concurrent.ConcurrentHashMap<>();
	private static final int _LIFE_MAX = 36000;		// 最长 30 分钟(20 刻 = 1 秒)
	private static final double _SIZE_MIN = 0.05D;	// 最小倍率
	private static final double _SIZE_MAX = 10.0D;	// 最大倍率
	private static final double _DIST_MAX = 16.0D;	// 距离上下限(格)

	// ===== 积木接口 =====
	// 让实体出现虚影: place = behind(背后) / above(头顶); size = 大小倍率; alphaPct = 不透明度 0~100;
	// dist = 离本体的距离(格); life = 持续刻数(0 = 一直显示, 直到「关闭虚影」).
	public static void start(Entity _e, String _place, double _size, double _alphaPct, double _dist, int _life) {
		if (_e == null || _e.level() == null || !_e.level().isClientSide())
			return;	// 服务端不画: 只让客户端自己那份记下来
		_G _g = new _G();
		_g.sw = _size(_size);
		_g.sh = _g.sw;
		_g.alpha = _alpha(_alphaPct);
		_g.place = _placeOf(_place);
		_g.dist = _dist(_dist);
		_g.life = _life(_life);
		_g.born = _e.level().getGameTime();
		_gs.put(_e, _g);
	}

	/** 关掉某实体的虚影(没有也不报错) */
	public static void stop(Entity _e) {
		if (_e == null)
			return;
		_gs.remove(_e);
		${package}.ghost.HxgGhostPose.clear(_e);	// 部位冻结的记录一起清掉, 下次 start 是全新的
		_viewOff(_e);	// 镜头还在这具虚影身上的话一起收回 + 撤掉服务端那段放宽
	}

	/** 这个实体现在有没有虚影 */
	public static boolean isActive(Entity _e) {
		return _e != null && _gs.containsKey(_e);
	}

	/** 只改大小(宽高一起改, 保持等比) */
	public static void setSize(Entity _e, double _size) {
		_G _g = _e == null ? null : _gs.get(_e);
		if (_g == null)
			return;
		_g.sw = _size(_size);
		_g.sh = _g.sw;
	}

	/** 只改大小(宽、高分开, 与缩放的「按宽高分别缩放」同一口径) */
	public static void setSizeAxis(Entity _e, double _w, double _h) {
		_G _g = _e == null ? null : _gs.get(_e);
		if (_g == null)
			return;
		_g.sw = _size(_w);
		_g.sh = _size(_h);
	}

	/** 只改不透明度(0 = 完全看不见, 100 = 完全不透明) */
	public static void setAlpha(Entity _e, double _alphaPct) {
		_G _g = _e == null ? null : _gs.get(_e);
		if (_g == null)
			return;
		_g.alpha = _alpha(_alphaPct);
	}

	/** 只改位置档位与距离 */
	public static void setPlace(Entity _e, String _place, double _dist) {
		_G _g = _e == null ? null : _gs.get(_e);
		if (_g == null)
			return;
		_g.place = _placeOf(_place);
		_g.dist = _dist(_dist);
	}

	/** 只改 Y 轴偏移(格, 正数往上、负数往下; 背后与头顶两档都生效, 与距离互不影响) */
	public static void setOffsetY(Entity _e, double _offsetY) {
		_G _g = _e == null ? null : _gs.get(_e);
		if (_g == null)
			return;
		_g.offsetY = _yoff(_offsetY);
	}

	/** 四个开关 -> 部位掩码(纯函数; 0 = 全部跟着动, 1 = 头, 2 = 手, 4 = 腿, 8 = 潜行不动, 可以相加) */
	public static int freezeMask(boolean _head, boolean _arms, boolean _legs, boolean _sneak) {
		return ${package}.ghost.HxgGhostPose.mask(_head, _arms, _legs, _sneak);
	}

	/** 老签名(没有潜行这一档)的兼容重载 */
	public static int freezeMask(boolean _head, boolean _arms, boolean _legs) {
		return freezeMask(_head, _arms, _legs, false);
	}

	/** 让虚影的某些部位「不动」: 勾上的部位记住当前姿势并一直保持, 其余部位照常跟本体动(只支持人形模型) */
	public static void setFreeze(Entity _e, int _mask) {
		if (_e == null || _gs.get(_e) == null)
			return;
		${package}.ghost.HxgGhostPose.setFreeze(_e, _mask);
	}

	/** 把镜头挪到某具虚影的眼睛上(只在「那具虚影就是你自己」的那台客户端生效; 操作/瞄准仍是本体) */
	public static void setView(Entity _e, boolean _on) {
		Minecraft _mc = Minecraft.getInstance();
		if (_e == null || _mc.player == null || _e != _mc.player)
			return;	// 别人的虚影不该改你这台机器的镜头
		if (_on && _gs.get(_e) == null)
			return;	// 没有虚影就没有「虚影视角」
		${package}.ghost.HxgGhostView.setView(_e, _on);
		if (!_on) {
			_syncReach(0.0D);	// 关掉: 服务端那段放宽的够到距离立刻撤掉
			_reachLocal(_mc.player, 0.0D);	// 本机那一段也一起撤
		}
	}

	// ===== 数值约定(纯函数: 不碰任何 MC 对象, 方便离线核对) =====
	static double _clamp(double _v, double _lo, double _hi) {
		return _v < _lo ? _lo : (_v > _hi ? _hi : _v);
	}

	/** 大小倍率: 0.05 ~ 10 倍(与缩放工具类的倍率口径一致) */
	static double _size(double _v) {
		return _clamp(_v, _SIZE_MIN, _SIZE_MAX);
	}

	/** 不透明度: 0~100 换算成 0~1 */
	static double _alpha(double _pct) {
		return _clamp(_pct, 0.0D, 100.0D) / 100.0D;
	}

	/** 距离: -16 ~ 16 格(负数 = 往本体朝向那边挪) */
	static double _dist(double _v) {
		return _clamp(_v, -_DIST_MAX, _DIST_MAX);
	}

	/** Y 轴偏移: ±16 格(正数往上、负数往下; 与「距离」共用一个上限) */
	static double _yoff(double _v) {
		return _clamp(_v, -_DIST_MAX, _DIST_MAX);
	}

	/** 两份打包好的光照(sky << 20 | block << 4)逐通道取较亮的那个: 虚影在暗处时用本体那边的光 */
	static int _maxLight(int _a, int _b) {
		int _sa = (_a >> 20) & 0xFFFF, _sb = (_b >> 20) & 0xFFFF;
		int _ba = (_a >> 4) & 0xFFFF, _bb = (_b >> 4) & 0xFFFF;
		return Math.max(_sa, _sb) << 20 | Math.max(_ba, _bb) << 4;
	}

	/** 持续刻数: 0(一直显示) ~ 36000 */
	static int _life(int _v) {
		return _v < 0 ? 0 : (_v > _LIFE_MAX ? _LIFE_MAX : _v);
	}

	/** 位置档位: "above" / "head" = 头顶, 其它(含 null) = 背后 */
	static int _placeOf(String _s) {
		return _s != null && ("above".equalsIgnoreCase(_s) || "head".equalsIgnoreCase(_s)) ? 1 : 0;
	}

	/** 帧间插值(位置/朝向按这个平滑, 与原版渲染同一口径) */
	static double _lerp(double _a, double _b, float _t) {
		return _a + (_b - _a) * (double) _t;
	}

	/** 寿命到了没有(life 小于等于 0 = 永不超时) */
	static boolean _expired(long _now, long _born, int _life) {
		return _life > 0 && _now - _born >= (long) _life;
	}

	/** 落点: 背后 = 本体朝向的反方向(水平); 头顶 = 脚底往上「身高 + 距离」; 两档都再叠一个 Y 轴偏移 */
	static double[] anchor(double _x, double _y, double _z, float _yaw, double _bbH, int _place, double _dist, double _offsetY) {
		if (_place == 1)
			return new double[] { _x, _y + _bbH + _dist + _offsetY, _z };
		double _r = Math.toRadians((double) _yaw);
		return new double[] { _x + Math.sin(_r) * _dist, _y + _offsetY, _z - Math.cos(_r) * _dist };
	}

	/** 相机是否已经钻进这具虚影里(钻进去就整具跳过, 免得一张皮肤糊满屏幕) */
	static boolean _inside(double[] _a, double _sw, double _sh, double _bbW, double _bbH, double _cx, double _cy, double _cz) {
		double _dx = _a[0] - _cx, _dz = _a[2] - _cz;
		double _r = Math.max(0.45D, _bbW * 0.5D * _sw + 0.05D);
		if (_dx * _dx + _dz * _dz > _r * _r)
			return false;
		double _dy = _cy - _a[1];
		return _dy > -0.4D && _dy < _bbH * _sh + 0.4D;
	}

	/** 两个点之间的距离(纯函数; 虚影眼睛是 double[3], 本体眼睛是 Vec3 的三个分量) */
	static double _dist3(double[] _a, double _x, double _y, double _z) {
		if (_a == null || _a.length < 3)
			return 0.0D;
		double _dx = _a[0] - _x, _dy = _a[1] - _y, _dz = _a[2] - _z;
		return Math.sqrt(_dx * _dx + _dy * _dy + _dz * _dz);
	}

	/** 上一次发给服务端的「放宽量」与时间; 只在变化够大、或离上次超过 1 秒时才重发(每帧发会把网络塞满) */
	static double _reachSent = 0.0D;
	static long _reachStamp = 0L;

	/**
	 * 把「本体眼睛到虚影眼睛的距离」告诉服务端(ghost/HxgGhostNet): 服务端据此把够到距离临时加上这一段,
	 * 于是从虚影那边看到/够到的方块与实体, 服务端也判得过. 关掉视角 / 虚影没了 / 退出世界时传 0 = 撤掉.
	 * 变化小于 0.05 格就不重发.
	 */
	static void _syncReach(double _v) {
		double _d = _clamp(_v, 0.0D, 64.0D);
		long _now = System.currentTimeMillis();
		// 每 1 秒补发一次: 玩家死亡重生 / 换维度之后服务端那个修饰符跟着旧实体没了, 只在「变化时发」会漏掉
		if (Math.abs(_d - _reachSent) < 0.05D && _now - _reachStamp < 1000L)
			return;
		try {
			${package}.ghost.HxgGhostNet.send(_d);
			_reachSent = _d;
			_reachStamp = _now;
		} catch (Throwable _t) {
			// 发不出去(还没连上 / 服务端没装)就算了: 画面不受影响, 下一帧还会再试
		}
	}

	/** 镜头收回(关掉 / 虚影到期 / 死亡 / 换维度): 记录清掉, 本机与服务端那两段放宽一起撤掉 */
	static void _viewOff(Entity _e) {
		if (_e == null)
			return;
		boolean _was = ${package}.ghost.HxgGhostView.isView(_e);
		${package}.ghost.HxgGhostView.clear(_e);
		if (_was) {
			_syncReach(0.0D);
			_reachLocal(Minecraft.getInstance().player, 0.0D);
		}
	}

	// ===== 本机这一份「够到距离」=====
	// 玩家自己的实体不在自己的 tracking 列表里(ChunkMap.TrackedEntity.updatePlayer 里那句
	// p_140498_ != this.entity), 所以原版从来不把玩家自己的属性包发给他自己 —— 服务端那段放宽
	// 客户端是看不到的. 想让「从虚影那边能挖/能打 = 本体距离 + 本体到虚影这一段」在本机画面上真的
	// 生效(准星选中、方块选中框), 就得在客户端自己身上再加同一段: 拾取长度与「太远就丢掉」那道闸
	// 全都读这两条触及距离属性, 加一段等于三处一起加长.
	// 用 transient 修饰符(不落存档), 退出世界 / 关视角立刻撤掉; 与缩放工具类、服务端那两个 id 都错开.
	private static final java.util.UUID _U_CLIENT_BLOCK = java.util.UUID.fromString("6f2a5c1e-2b7d-4f0a-9d3c-1a8e5b7c9d07");
	private static final java.util.UUID _U_CLIENT_ENTITY = java.util.UUID.fromString("6f2a5c1e-2b7d-4f0a-9d3c-1a8e5b7c9d08");
	private static double _clientReach = 0.0D;
	// 修饰符加在哪个实体上: 换维度 / 死亡重生之后客户端会换一个新的 LocalPlayer, 旧实体上的修饰符跟着没了
	private static net.minecraft.world.entity.Entity _reachOwner;

	/** 把这一段加/撤到本机玩家的方块与实体触及距离上(=0 撤掉; 只在本机生效, 不发任何包) */
	static void _reachLocal(net.minecraft.client.player.LocalPlayer _p, double _v) {
		double _d = _clamp(_v, 0.0D, 64.0D);
		if (_p == null) {
			_reachOwner = null;
			_clientReach = 0.0D;
			return;
		}
		if (_p != _reachOwner) {
			_reachOwner = _p;
			_clientReach = -1.0D;	// 新实体身上还没有这个修饰符: 逼下面重新加一次
		}
		if (Math.abs(_d - _clientReach) < 0.02D)
			return;	// 没变就不碰(每帧都会调)
		_clientReach = _d;
		_hxgReachAttr(_p, net.minecraftforge.common.ForgeMod.BLOCK_REACH.get(), _U_CLIENT_BLOCK, _d);
		_hxgReachAttr(_p, net.minecraftforge.common.ForgeMod.ENTITY_REACH.get(), _U_CLIENT_ENTITY, _d);
	}

	static void _hxgReachAttr(net.minecraft.world.entity.player.Player _p, net.minecraft.world.entity.ai.attributes.Attribute _a,
			java.util.UUID _id, double _amount) {
		if (_a == null)
			return;
		net.minecraft.world.entity.ai.attributes.AttributeInstance _ins;
		try {
			_ins = _p.getAttribute(_a);
		} catch (Throwable _t) {
			return;
		}
		if (_ins == null)
			return;
		net.minecraft.world.entity.ai.attributes.AttributeModifier _old = _ins.getModifier(_id);
		if (Math.abs(_amount) < 1.0E-4D) {
			if (_old != null)
				_ins.removeModifier(_id);
			return;
		}
		if (_old != null
				&& _old.getOperation() == net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.ADDITION
				&& Math.abs(_old.getAmount() - _amount) < 1.0E-4D)
			return;
		if (_old != null)
			_ins.removeModifier(_id);
		_ins.addTransientModifier(new net.minecraft.world.entity.ai.attributes.AttributeModifier(_id, "hxg_ghost_reach_local",
				_amount, net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.ADDITION));
	}

	// ===== 渲染 =====
	@SubscribeEvent public static void onRender(RenderLevelStageEvent event) {
		if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS)
			return;
		Minecraft _mc = Minecraft.getInstance();
		if (_mc.level == null) {	// 退出世界: 记录整份作废(下次进来重新 start)
			_gs.clear();
			${package}.ghost.HxgGhostPose.clearAll();
			${package}.ghost.HxgGhostView.clearAll();
			_reachSent = 0.0D;	// 服务端那个玩家实体已经没了, 放宽的修饰符跟着一起消失, 不用再发包
			_clientReach = 0.0D;	// 本机那个玩家实体也换了, 修饰符跟着没了
			return;
		}
		if (_gs.isEmpty()) {
			_syncReach(0.0D);	// 最后一具虚影没了: 万一镜头还挂在它身上, 把服务端那段放宽撤掉
			_reachLocal(_mc.player, 0.0D);	// 本机那一段也一起撤
			return;
		}
		float _pt = event.getPartialTick();
		long _now = _mc.level.getGameTime();
		Vec3 _camera = event.getCamera().getPosition();
		PoseStack _pose = event.getPoseStack();
		MultiBufferSource.BufferSource _buffers = _mc.renderBuffers().bufferSource();
		java.util.Iterator<java.util.Map.Entry<Entity, _G>> _it = _gs.entrySet().iterator();
		while (_it.hasNext()) {
			java.util.Map.Entry<Entity, _G> _en = _it.next();
			Entity _e = _en.getKey();
			_G _g = _en.getValue();
			if (_e == null || !_e.isAlive() || _e.level() != _mc.level) {
				${package}.ghost.HxgGhostPose.clear(_e);
				_viewOff(_e);
				_it.remove();
				continue;
			}
			if (_expired(_now, _g.born, _g.life)) {
				${package}.ghost.HxgGhostPose.clear(_e);
				_viewOff(_e);
				_it.remove();
				continue;
			}
			try {
				double _x = _lerp(_e.xOld, _e.getX(), _pt);
				double _y = _lerp(_e.yOld, _e.getY(), _pt);
				double _z = _lerp(_e.zOld, _e.getZ(), _pt);
				float _yaw = (float) _lerp((double) _e.yRotO, (double) _e.getYRot(), _pt);
				double[] _a = anchor(_x, _y, _z, _yaw, (double) _e.getBbHeight(), _g.place, _g.dist, _g.offsetY);
				boolean _view = ${package}.ghost.HxgGhostView.isView(_e);
				if (_view) {
					// 相机这一帧要用的点: 先算好(下一帧 Camera.setup 会取), 跳过绘制也要算
					double[] _eye = ${package}.ghost.HxgGhostView.eyeOf(_a, (double) _e.getEyeHeight(), _g.sh);
					// 「本体眼睛 -> 虚影眼睛」这一段: 客户端射线长度按它加长(见 gpick mixin), 服务端也按它放宽
					Vec3 _be = _e.getEyePosition(_pt);
					double _ex = _dist3(_eye, _be.x, _be.y, _be.z);
					${package}.ghost.HxgGhostView.update(_e, _eye[0], _eye[1], _eye[2], _ex);
					_syncReach(_ex);	// 服务端: 校验放宽两倍这一段
					_reachLocal(_mc.player, _ex);	// 本机: 射线长度也加上这一段
				}
				boolean _insideNow = _inside(_a, _g.sw, _g.sh, (double) _e.getBbWidth(), (double) _e.getBbHeight(), _camera.x, _camera.y, _camera.z);
				if (_insideNow && !_view)
					continue;	// 相机钻进去了, 又不是「正在当摄像机的那具」: 整具跳过(不然一张皮肤糊满屏幕)
				// 反过来, 正在当摄像机的那具就算相机在它头里也照画 —— 但要把「头」藏掉, 只留身体
				// (第一人称: 看到的是自己的躯干/手臂/腿, 而不是糊满屏幕的头皮)
				RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, (float) _g.alpha);
				_draw(_mc, _e, _a, _g, _yaw, _pt, _camera, _pose, _buffers, _x, _y, _z, _insideNow && _view);
				_buffers.endBatch();	// 立刻出队(不透明度是绘制时生效的, 不出队就会变成最后设的那个值)
				RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);	// 复位, 别影响后面的渲染
			} catch (Throwable _t) {
				// 一具虚影画不出来不能把整帧拖崩
			}
		}
		RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
	}

	// 把本体在落点再画一遍: 同一个实体对象 -> 动作/皮肤/装备全都与本体一致; 只换位置、缩放与渲染类型.
	@SuppressWarnings("unchecked")
	static void _draw(Minecraft _mc, Entity _e, double[] _a, _G _g, float _yaw, float _pt, Vec3 _camera, PoseStack _pose,
			MultiBufferSource _buffers, double _bx, double _by, double _bz, boolean _hideHead) {
		net.minecraft.client.renderer.entity.EntityRenderer<Entity> _r =
				(net.minecraft.client.renderer.entity.EntityRenderer<Entity>) _mc.getEntityRenderDispatcher().getRenderer(_e);
		if (_r == null)
			return;
		ResourceLocation _tex = _r.getTextureLocation(_e);
		MultiBufferSource _gb = _type -> _buffers.getBuffer(_ghostType(_type, _tex));
		_pose.pushPose();
		_pose.translate(_a[0] - _camera.x, _a[1] - _camera.y, _a[2] - _camera.z);
		_pose.scale((float) _g.sw, (float) _g.sh, (float) _g.sw);
		Vec3 _off = _r.getRenderOffset(_e, _pt);
		_pose.translate(_off.x, _off.y, _off.z);
		// 采光: 落点 + 本体各采一次取较亮的(虚影钻进地里/墙里时落点那一格是黑的, 只按落点采会把整具画成黑块)
		int _light = _maxLight(
				net.minecraft.client.renderer.LevelRenderer.getLightColor(_mc.level,
						net.minecraft.core.BlockPos.containing(_a[0], _a[1] + 0.5D, _a[2])),
				net.minecraft.client.renderer.LevelRenderer.getLightColor(_mc.level,
						net.minecraft.core.BlockPos.containing(_bx, _by + (double) _e.getBbHeight() * 0.5D, _bz)));
		${package}.ghost.HxgGhostPose.begin(_e, _hideHead);	// 这一下画的是虚影: 部位冻结只作用在它身上, 必要时把头藏掉
		try {
			_r.render(_e, _yaw, _pt, _pose, _gb, _light);
		} finally {
			${package}.ghost.HxgGhostPose.end();
		}
		_pose.popPose();
	}

	// 只把「本体皮肤」那几种渲染类型换成半透明剔除版; 护甲/手持物/披风等层原样返回(它们有自己的贴图与渲染类型,
	// 换成皮肤贴图就变成一块平面的皮肤). 不透明度由 setShaderColor 统一乘上去, 所有层都能透.
	static RenderType _ghostType(RenderType _type, ResourceLocation _tex) {
		if (_type == null)
			return RenderType.entityTranslucentCull(_tex);
		if (_type == RenderType.entityCutoutNoCull(_tex) || _type == RenderType.entityCutout(_tex)
				|| _type == RenderType.entitySolid(_tex) || _type == RenderType.entityTranslucent(_tex)
				|| _type == RenderType.entityTranslucentCull(_tex) || _type == RenderType.entityTranslucentEmissive(_tex)
				|| _type == RenderType.itemEntityTranslucentCull(_tex) || _type == RenderType.outline(_tex))
			return RenderType.entityTranslucentCull(_tex);
		return _type;
	}

// ===== HX_SYNC: 本工具类的渲染同步重放注册(只在客户端加载时执行一次) =====
static {
	RegPacketProcedure.hxRegister("ghost.start", _d -> { Entity _e = RegPacketProcedure.hxEnt(_d); if (_e != null) start(_e, RegPacketProcedure.hxS(_d, "s0"), RegPacketProcedure.hxN(_d, "a0"), RegPacketProcedure.hxN(_d, "a1"), RegPacketProcedure.hxN(_d, "a2"), RegPacketProcedure.hxI(_d, "a3")); });
	RegPacketProcedure.hxRegister("ghost.stop", _d -> { Entity _e = RegPacketProcedure.hxEnt(_d); if (_e != null) stop(_e); });
	RegPacketProcedure.hxRegister("ghost.size", _d -> { Entity _e = RegPacketProcedure.hxEnt(_d); if (_e != null) setSize(_e, RegPacketProcedure.hxN(_d, "a0")); });
	RegPacketProcedure.hxRegister("ghost.axis", _d -> { Entity _e = RegPacketProcedure.hxEnt(_d); if (_e != null) setSizeAxis(_e, RegPacketProcedure.hxN(_d, "a0"), RegPacketProcedure.hxN(_d, "a1")); });
	RegPacketProcedure.hxRegister("ghost.alpha", _d -> { Entity _e = RegPacketProcedure.hxEnt(_d); if (_e != null) setAlpha(_e, RegPacketProcedure.hxN(_d, "a0")); });
	RegPacketProcedure.hxRegister("ghost.place", _d -> { Entity _e = RegPacketProcedure.hxEnt(_d); if (_e != null) setPlace(_e, RegPacketProcedure.hxS(_d, "s0"), RegPacketProcedure.hxN(_d, "a0")); });
	RegPacketProcedure.hxRegister("ghost.offset", _d -> { Entity _e = RegPacketProcedure.hxEnt(_d); if (_e != null) setOffsetY(_e, RegPacketProcedure.hxN(_d, "a0")); });
	RegPacketProcedure.hxRegister("ghost.freeze", _d -> { Entity _e = RegPacketProcedure.hxEnt(_d); if (_e != null) setFreeze(_e, RegPacketProcedure.hxI(_d, "a0")); });
	RegPacketProcedure.hxRegister("ghost.view", _d -> { Entity _e = RegPacketProcedure.hxEnt(_d); if (_e != null) setView(_e, RegPacketProcedure.hxN(_d, "a0") > 0.5D); });
}
