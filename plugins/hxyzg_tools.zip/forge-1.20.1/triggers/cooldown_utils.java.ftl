<#include "procedures.java.ftl">
public class ${name}Procedure {
    public static void set(Entity _entity, String _key, int _ticks) {
        _entity.getPersistentData().putDouble("hxyzgcd_" + _key, (double) _entity.level().getGameTime() + (double) _ticks);
    }
    public static double remain(Entity _entity, String _key) {
        double _end = _entity.getPersistentData().getDouble("hxyzgcd_" + _key);
        double _now = (double) _entity.level().getGameTime();
        return Math.max(0.0, _end - _now);
    }
    public static boolean isOn(Entity _entity, String _key) {
        return remain(_entity, _key) > 0.0;
    }
    public static void clear(Entity _entity, String _key) {
        _entity.getPersistentData().putDouble("hxyzgcd_" + _key, 0.0);
    }
