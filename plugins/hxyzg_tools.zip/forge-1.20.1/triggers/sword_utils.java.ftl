<#include "procedures.java.ftl">
@Mod.EventBusSubscriber(Dist.CLIENT) public class ${name}Procedure {
    private static final java.util.ArrayList<double[]> _swords = new java.util.ArrayList<>();
    private static final java.util.ArrayList<ItemStack> _swordItems = new java.util.ArrayList<>();
    private static final java.util.ArrayList<Entity> _swordOwner = new java.util.ArrayList<>();

    public static void converge(LevelAccessor _accessor, double _x, double _y, double _z, double _distance,
            int _count, int _ticks, double _radius, double _speed, ItemStack _item, boolean _fromBehind,
            boolean _filled, boolean _forward) {
        if (_accessor == null || !_accessor.isClientSide()) return;   // 剑是纯客户端渲染, 服务端只负责广播同步
        Minecraft _mc = _prepare(_accessor, _count, _ticks, _radius, _item);
        if (_mc == null) return;
        double _r = _clampRadius(_radius);
        Entity _self = _mc.player;
        double _cx = _x, _cy = _y, _cz = _z;
        if (_fromBehind && _self != null) {
            Vec3 _f = _self.getViewVector(1.0F);
            double _back = _r * 0.5 + 0.6;
            _cx = _self.getX() - _f.x * _back;
            _cy = _self.getY() + (double) _self.getBbHeight() * 0.5;
            _cz = _self.getZ() - _f.z * _back;
        }
        // 扎向坐标: 全体收拢到那一个点
        // 直接往前: 每把剑各自沿视线平移(位置保持生成时的环, 不聚拢), 所以是"直直往前飞"
        Vec3 _fwd = _forward && _self != null ? _self.getViewVector(1.0F) : null;
        double[] _basis = _ringBasis(_fromBehind ? _self : null);
        for (int _i = 0; _i < _count; _i++) {
            double _ang = _slotAngle(_i, _count, _filled);
            double _rr = _filled ? _r * Math.sqrt((_i + 0.5) / _count) : _r;
            double _sx = _cx + _basis[0] * Math.cos(_ang) * _rr + _basis[3] * Math.sin(_ang) * _rr;
            double _sy = _cy + _basis[1] * Math.cos(_ang) * _rr + _basis[4] * Math.sin(_ang) * _rr;
            double _sz = _cz + _basis[2] * Math.cos(_ang) * _rr + _basis[5] * Math.sin(_ang) * _rr;
            double _ex = _x, _ey = _y, _ez = _z;
            if (_fwd != null) {
                _ex = _sx + _fwd.x * _distance;
                _ey = _sy + _fwd.y * _distance;
                _ez = _sz + _fwd.z * _distance;
            }
            _add(_mc, _item, 0.0, _speed, _sx, _sy, _sz, _ex, _ey, _ez, _r, _ticks, _ang);
        }
    }

    public static void rain(LevelAccessor _accessor, double _x, double _y, double _z, int _count, int _ticks,
            double _radius, double _speed, ItemStack _item, boolean _filled, boolean _toCenter) {
        if (_accessor == null || !_accessor.isClientSide()) return;   // 剑是纯客户端渲染, 服务端只负责广播同步
        Minecraft _mc = _prepare(_accessor, _count, _ticks, _radius, _item);
        if (_mc == null) return;
        double _r = _clampRadius(_radius);
        for (int _i = 0; _i < _count; _i++) {
            double _ang = _slotAngle(_i, _count, _filled);
            double _rr = _filled ? _r * Math.sqrt((_i + 0.5) / _count) : _r;
            double _sx = _x + Math.cos(_ang) * _rr;
            double _sz = _z + Math.sin(_ang) * _rr;
            double _h = 6.0 + 3.0 * ((_i % 5) / 4.0);
            // 两种下落方式剑尖都朝下, 只是落点不同
            _add(_mc, _item, 1.0, _speed, _sx, _y + _h, _sz, _toCenter ? _x : _sx, _y, _toCenter ? _z : _sz, _r, _ticks, _ang);
        }
    }

    public static void orbit(LevelAccessor _accessor, Entity _entity, int _count, int _ticks, double _radius,
            double _yOffset, double _speed, ItemStack _item, int _form, int _float) {
        if (_accessor == null || !_accessor.isClientSide()) return;   // 剑是纯客户端渲染, 服务端只负责广播同步
        Minecraft _mc = _prepare(_accessor, _count, _ticks, _radius, _item);
        if (_mc == null || _entity == null) return;
        double _r = _clampRadius(_radius);
        for (int _i = 0; _i < _count; _i++) {
            double _ang = Math.PI * 2.0 * _i / Math.max(1, _count);
            _add(_mc, _item, 2.0, _speed, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, _r, _ticks, _ang);
            int _last = _swords.size() - 1;
            _swords.get(_last)[1] = (double) _form;
            _swords.get(_last)[2] = (double) _float;
            _swords.get(_last)[17] = _yOffset;
            _swordOwner.set(_last, _entity);
        }
    }

    public static void clear() {
        _swords.clear();
        _swordItems.clear();
        _swordOwner.clear();
    }

    public static boolean isActive() {
        return !_swords.isEmpty();
    }

    private static double _clampRadius(double _radius) {
        return _radius < 0.5 ? 0.5 : (_radius > 48.0 ? 48.0 : _radius);
    }

    /** 空心环 = 角度均分; 满圆 = 黄金角 + sqrt 半径, 看起来更均匀 */
    private static double _slotAngle(int _i, int _count, boolean _filled) {
        if (!_filled) return Math.PI * 2.0 * _i / Math.max(1, _count);
        return _i * 2.399963229728653;
    }

    /** 返回客户端 Level 对应的 Minecraft, 不能生成时返回 null */
    private static Minecraft _prepare(LevelAccessor _accessor, int _count, int _ticks, double _radius,
            ItemStack _item) {
        if (!(_accessor instanceof Level)) return null;
        Minecraft _mc = Minecraft.getInstance();
        if (_mc.level == null || _mc.level != _accessor) return null;
        if (_item == null || _item.isEmpty()) return null;
        if (_count < 1) return null;
        return _mc;
    }

    /**
     * 环所在平面的正交基: 0..2 = right, 3..5 = up。
     * 传 null 时是水平环(法线朝上); 传实体时环面垂直于该实体视线(用于"实体背后").
     */
    private static double[] _ringBasis(Entity _e) {
        if (_e == null) return new double[] { 1.0, 0.0, 0.0, 0.0, 0.0, 1.0 };
        return _ringBasis(_e.getViewVector(1.0F));
    }
    /** 环平面的正交基: 0..2 = right, 3..5 = up (按给定朝向算; 传水平向量时环就是竖立的) */
    private static double[] _ringBasis(Vec3 _f) {
        double _rx = _f.z, _rz = -_f.x;
        double _rl = Math.sqrt(_rx * _rx + _rz * _rz);
        if (_rl < 1.0E-4) { _rx = 1.0; _rz = 0.0; } else { _rx /= _rl; _rz /= _rl; }
        double _ux = -_rz * _f.y;
        double _uy = _rz * _f.x - _rx * _f.z;
        double _uz = _rx * _f.y;
        return new double[] { _rx, 0.0, _rz, _ux, _uy, _uz };
    }

    private static void _add(Minecraft _mc, ItemStack _item, double _mode, double _speed, double _sx, double _sy, double _sz, double _ex,
            double _ey, double _ez, double _radius, int _ticks, double _angle) {
        _swords.add(new double[] { _mode, 0.0, 0.0, _sx, _sy, _sz, _ex, _ey, _ez, _radius,
                (double) Math.max(1, _ticks), (double) _mc.level.getGameTime(), _angle,
                Math.random() * 0.5 + 0.75, Math.random() * 6.0 + 2.0, Math.random() * 6.28,
                Math.random() * 3.0 + 0.6, 0.0, _speed > 0.05 ? _speed : 1.0 });
        _swordItems.add(_item.copy());
        _swordOwner.add(null);
    }
    // 物品模型(GROUND)下, 剑在模型空间里的朝向 —— 实测原版贴图得出:
    //   剑尖 pi  = 贴图右上角 -> 模型 (+X, +Y) 平面内
    //   剑脊法线  = 模型 +Z (贴图是一张面向 +Z 的平面卡片, 见 item/generated 的 fixed 变换)
    // 换用三叉戟等"剑尖在左下角"的贴图时, 把 LOCAL_TIP 取反即可。
    private static final double[] LOCAL_TIP = { 0.70710678, 0.70710678, 0.0 };
    private static final double[] LOCAL_FLAT = { 0.0, 0.0, 1.0 };

    /**
     * 把剑摆成: 剑尖朝 _lx/_ly/_lz, 剑脊法线朝 _nx/_ny/_nz。
     * 做法是求出 局部基(剑尖, 法线, 二者叉积) 到 世界基 的旋转矩阵, 所以不用手推欧拉角。
     */
    private static void _orient(PoseStack _pose, double _lx, double _ly, double _lz, double _nx, double _ny,
            double _nz) {
        double _ll = Math.sqrt(_lx * _lx + _ly * _ly + _lz * _lz);
        if (_ll < 1.0E-6) { _lx = 0.0; _ly = 0.0; _lz = -1.0; } else { _lx /= _ll; _ly /= _ll; _lz /= _ll; }
        double _dot = _nx * _lx + _ny * _ly + _nz * _lz;
        _nx -= _dot * _lx; _ny -= _dot * _ly; _nz -= _dot * _lz;
        double _nl = Math.sqrt(_nx * _nx + _ny * _ny + _nz * _nz);
        if (_nl < 1.0E-6) { _nx = -_lz; _ny = 0.0; _nz = _lx; _nl = Math.sqrt(_nx * _nx + _nz * _nz); }
        if (_nl < 1.0E-6) { _nx = 1.0; _ny = 0.0; _nz = 0.0; _nl = 1.0; }
        _nx /= _nl; _ny /= _nl; _nz /= _nl;
        double _wx = _ly * _nz - _lz * _ny, _wy = _lz * _nx - _lx * _nz, _wz = _lx * _ny - _ly * _nx;
        double _t0 = LOCAL_TIP[0], _t1 = LOCAL_TIP[1], _t2 = LOCAL_TIP[2];
        double _f0 = LOCAL_FLAT[0], _f1 = LOCAL_FLAT[1], _f2 = LOCAL_FLAT[2];
        double _c0 = _t1 * _f2 - _t2 * _f1, _c1 = _t2 * _f0 - _t0 * _f2, _c2 = _t0 * _f1 - _t1 * _f0;
        org.joml.Matrix3f _world = new org.joml.Matrix3f((float) _lx, (float) _ly, (float) _lz,
                (float) _nx, (float) _ny, (float) _nz, (float) _wx, (float) _wy, (float) _wz);
        org.joml.Matrix3f _local = new org.joml.Matrix3f((float) _t0, (float) _t1, (float) _t2,
                (float) _f0, (float) _f1, (float) _f2, (float) _c0, (float) _c1, (float) _c2);
        _world.mul(_local.transpose());
        _pose.mulPose(_world.getNormalizedRotation(new org.joml.Quaternionf()));
    }

    private static void _tickSwords(Minecraft _mc, PoseStack _pose, Vec3 _camera, float _pt) {
        if (_swords.isEmpty() || _mc.level == null) return;
        double _now = (double) _mc.level.getGameTime();
        MultiBufferSource _buffers = _mc.renderBuffers().bufferSource();
        for (int _i = _swords.size() - 1; _i >= 0; _i--) {
            double[] _d = _swords.get(_i);
            double _age = _now - _d[11];
            if (_age < 0.0) _age = 0.0;
            // 动画相位要用带小数的时间: _age 是整 tick 的, 直接拿去算相位会 20 次/秒地跳
            double _ageS = _age + (double) _pt;
            if (_age > _d[10]) {
                _swords.remove(_i);
                _swordItems.remove(_i);
                _swordOwner.remove(_i);
                continue;
            }
            double _t = _ageS * _d[18] / _d[10];          // 速度倍率: >1 更快到达
            if (_t > 1.0) _t = 1.0;
            double _eased = _t * _t * (3.0 - 2.0 * _t);
            double _px, _py, _pz, _lx, _ly, _lz, _nx, _ny, _nz;
            int _mode = (int) _d[0];
            if (_mode == 2) {
                Entity _owner = _swordOwner.get(_i);
                if (_owner == null || !_owner.isAlive()) continue;
                // 相机是插值过的, 剑也必须跟着插值: 直接取整 tick 的坐标, 实体一动剑环就一抖
                Vec3 _op = _owner.getPosition(_pt);
                double _cx = _op.x;
                double _cy = _op.y + (double) _owner.getBbHeight() * 0.5;
                double _cz = _op.z;
                int _form = (int) _d[1];
                if (_form == 3) {
                    // ④ 剑环固定在身体背后: 只用身体朝向(水平方向), 抬头/低头时环不会跟着动;
                    //    环面垂直于身体朝向(竖立在背后), 所有剑尖水平朝身体正前方且互相平行
                    double _dYaw = (double) _owner.getYRot() - (double) _owner.yRotO;
                    while (_dYaw < -180.0) _dYaw += 360.0;
                    while (_dYaw > 180.0) _dYaw -= 360.0;
                    double _yaw = Math.toRadians((double) _owner.yRotO + _dYaw * (double) _pt);
                    Vec3 _f = new Vec3(-Math.sin(_yaw), 0.0, Math.cos(_yaw));
                    double[] _b = _ringBasis(_f);
                    double _back = _d[9] * 0.5 + 0.6;
                    double _bx = _cx - _f.x * _back;
                    double _by = _cy + _d[17];
                    double _bz = _cz - _f.z * _back;
                    double _ang = _d[12] + _ageS * 0.10 * _d[18];
                    _px = _bx + (_b[0] * Math.cos(_ang) + _b[3] * Math.sin(_ang)) * _d[9];
                    _py = _by + (_b[1] * Math.cos(_ang) + _b[4] * Math.sin(_ang)) * _d[9];
                    _pz = _bz + (_b[2] * Math.cos(_ang) + _b[5] * Math.sin(_ang)) * _d[9];
                    _lx = _f.x; _ly = 0.0; _lz = _f.z;          // 剑尖水平朝前(不含俯仰)
                    _nx = _b[3]; _ny = _b[4]; _nz = _b[5];
                } else {
                    double _ang = _d[12] + _ageS * 0.12 * _d[18];
                    _px = _cx + Math.cos(_ang) * _d[9];
                    _pz = _cz + Math.sin(_ang) * _d[9];
                    // ①②③ 的 Y 坐标完全一致, 只有"浮动"会让它上下动
                    double _float = _d[2], _off = 0.0;
                    if (_float > 1.5) _off = Math.sin(_ageS * _d[13] * 0.5 + _d[15]) * 0.3;
                    else if (_float > 0.5) _off = Math.sin(_ageS * 0.2 + _ang * 2.0) * 0.35;
                    _py = _cy + _off + _d[17];
                    if (_form == 1) { _lx = 0.0; _ly = 1.0; _lz = 0.0; }
                    else if (_form == 2) { _lx = 0.0; _ly = -1.0; _lz = 0.0; }
                    else { _lx = Math.cos(_ang); _ly = 0.0; _lz = Math.sin(_ang); }
                    // ②③ 剑脊面向实体(法线指圆心), ① 剑脊朝上(平躺)
                    if (_form == 0) { _nx = 0.0; _ny = 1.0; _nz = 0.0; }
                    else { _nx = -Math.cos(_ang); _ny = 0.0; _nz = -Math.sin(_ang); }
                }
            } else {
                _px = _d[3] + (_d[6] - _d[3]) * _eased;
                _py = _d[4] + (_d[7] - _d[4]) * _eased;
                _pz = _d[5] + (_d[8] - _d[5]) * _eased;
                if (_mode == 1) {
                    _lx = 0.0; _ly = -1.0; _lz = 0.0;                    // 剑雨: 剑尖一律朝下
                } else {
                    double _dx = _d[6] - _px, _dy = _d[7] - _py, _dz = _d[8] - _pz;
                    double _dl = Math.sqrt(_dx * _dx + _dy * _dy + _dz * _dz);
                    if (_dl < 1.0E-4) { _lx = Math.cos(_d[12]); _ly = 0.0; _lz = Math.sin(_d[12]); }
                    else { _lx = _dx / _dl; _ly = _dy / _dl; _lz = _dz / _dl; }   // 归宗: 剑尖朝行进方向
                }
                _nx = Math.cos(_d[12]); _ny = 0.0; _nz = Math.sin(_d[12]);
            }
            ItemStack _stack = _swordItems.get(_i);
            if (_stack == null || _stack.isEmpty()) continue;   // 防御: 取不到物品就别画
            _pose.pushPose();
            _pose.translate(_px - _camera.x, _py - _camera.y, _pz - _camera.z);
            _orient(_pose, _lx, _ly, _lz, _nx, _ny, _nz);
            float _scale = (float) (2.0 * _d[13]);   // GROUND 自带 0.5 缩放, 这里补回来
            _pose.scale(_scale, _scale, _scale);
            // 卡片中心在模型空间是 (0.5, 0.5, 0.5), 但 item/generated 的 ground 显示变换是
            // translate(0, 2/16, 0) + scale(0.5), 于是卡片中心落在 (0.25, 0.375, 0.25)。
            // 这里是"先 scale 再 translate", 平移量会整体乘上 _scale(与缩放无关地抵消),
            // 所以直接填这个中心值取负即可 —— 不管每把剑缩放多少, 剑身中心都精确落在环位上。
            // (以前填了 -0.5/-0.625/-0.5, 即两倍, 于是每个环都会整体偏移 0.25*_scale 格。)
            _pose.translate(-0.25, -0.375, -0.25);
            _mc.getItemRenderer().renderStatic(_stack, ItemDisplayContext.GROUND, LevelRenderer.getLightColor(_mc.level, BlockPos.containing(_px, _py, _pz)),
                    OverlayTexture.NO_OVERLAY, _pose, _buffers, _mc.level, 0);
            _pose.popPose();
        }
    }
    @SubscribeEvent public static void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        _tickSwords(Minecraft.getInstance(), event.getPoseStack(), event.getCamera().getPosition(), event.getPartialTick());
    }

// ===== HX_SYNC: 万剑归宗三个积木的渲染同步重放注册 =====
static {
	RegPacketProcedure.hxRegister("sword.converge", _d -> converge(Minecraft.getInstance().level, RegPacketProcedure.hxN(_d, "a0"), RegPacketProcedure.hxN(_d, "a1"), RegPacketProcedure.hxN(_d, "a2"), RegPacketProcedure.hxN(_d, "a3"), RegPacketProcedure.hxI(_d, "a4"), RegPacketProcedure.hxI(_d, "a5"), RegPacketProcedure.hxN(_d, "a6"), RegPacketProcedure.hxN(_d, "a7"), RegPacketProcedure.hxItem(_d), RegPacketProcedure.hxB(_d, "a8"), RegPacketProcedure.hxB(_d, "a9"), RegPacketProcedure.hxB(_d, "a10")));
	RegPacketProcedure.hxRegister("sword.orbit", _d -> { net.minecraft.world.entity.Entity _e = RegPacketProcedure.hxEnt(_d); if (_e != null) orbit(Minecraft.getInstance().level, _e, RegPacketProcedure.hxI(_d, "a0"), RegPacketProcedure.hxI(_d, "a1"), RegPacketProcedure.hxN(_d, "a2"), RegPacketProcedure.hxN(_d, "a3"), RegPacketProcedure.hxN(_d, "a4"), RegPacketProcedure.hxItem(_d), RegPacketProcedure.hxI(_d, "a5"), RegPacketProcedure.hxI(_d, "a6")); });
	RegPacketProcedure.hxRegister("sword.rain", _d -> rain(Minecraft.getInstance().level, RegPacketProcedure.hxN(_d, "a0"), RegPacketProcedure.hxN(_d, "a1"), RegPacketProcedure.hxN(_d, "a2"), RegPacketProcedure.hxI(_d, "a3"), RegPacketProcedure.hxI(_d, "a4"), RegPacketProcedure.hxN(_d, "a5"), RegPacketProcedure.hxN(_d, "a6"), RegPacketProcedure.hxItem(_d), RegPacketProcedure.hxB(_d, "a7"), RegPacketProcedure.hxB(_d, "a8")));
}
