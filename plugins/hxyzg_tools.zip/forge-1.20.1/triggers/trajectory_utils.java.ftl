<#include "procedures.java.ftl">
@Mod.EventBusSubscriber(Dist.CLIENT) public class ${name}Procedure {

    private static void _p(LevelAccessor _a, ParticleOptions _particle, double _x, double _y, double _z) {
        if (_a instanceof Level _level) _level.addParticle(_particle, _x, _y, _z, 0.0, 0.0, 0.0);
    }
    private static final java.util.ArrayList<double[]> _traj = new java.util.ArrayList<>();
    private static final java.util.ArrayList<ParticleOptions> _trajParticle = new java.util.ArrayList<>();
    private static int _trajTick = 0;
    public static void velocity(LevelAccessor _accessor, double _x, double _y, double _z, double _vx, double _vy,
            double _vz, double _gravity, int _ticks, int _points, ParticleOptions _particle) {
        if (_particle == null) return;
        _traj.add(new double[] { _x, _y, _z, _vx, _vy, _vz, _gravity <= 0.0 ? 0.05 : _gravity,
                (double) Math.max(1, _ticks), (double) Math.max(2, _points), (double) (_trajTick + 1) });
        _trajParticle.add(_particle);
    }
    public static void aimed(LevelAccessor _accessor, double _x, double _y, double _z, double _speed, double _yaw,
            double _pitch, double _gravity, int _ticks, int _points, ParticleOptions _particle) {
        double _yr = Math.toRadians(_yaw), _pr = Math.toRadians(_pitch);
        velocity(_accessor, _x, _y, _z, -Math.sin(_yr) * Math.cos(_pr) * _speed, -Math.sin(_pr) * _speed,
                Math.cos(_yr) * Math.cos(_pr) * _speed, _gravity, _ticks, _points, _particle);
    }
    public static void clear() {
        _traj.clear();
        _trajParticle.clear();
    }
    private static void _tickTraj(Minecraft _mc) {
        _trajTick++;
        if (_traj.isEmpty() || _mc.level == null) return;
        for (int _i = _traj.size() - 1; _i >= 0; _i--) {
            double[] _d = _traj.get(_i);
            ParticleOptions _particle = _trajParticle.get(_i);
            if ((double) _trajTick - _d[9] > _d[7]) {
                _traj.remove(_i);
                _trajParticle.remove(_i);
                continue;
            }
            int _n = (int) _d[8];
            for (int _s = 0; _s <= _n; _s++) {
                double _t = (double) _s * 0.1;
                _p(_mc.level, _particle, _d[0] + _d[3] * _t, _d[1] + _d[4] * _t - 0.5 * _d[6] * _t * _t,
                        _d[2] + _d[5] * _t);
            }
        }
    }
    @SubscribeEvent public static void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        _tickTraj(Minecraft.getInstance());
    }
