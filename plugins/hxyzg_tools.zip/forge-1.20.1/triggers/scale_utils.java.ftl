<#include "procedures.java.ftl">
<#--
  「缩放」工具类(门面). 真正干活的是本插件生成的那套类(见 <分支>/generator.yaml):
    scale.HxgScale      —— 数据与纯计算(倍率钳制 / 过渡插值 / 运算模式)
    scale.HxgScaleNet   —— 尺寸(EntityEvent.Size) + 属性(速度/台阶/触及) + 存档 + 同步
    mixin.HxgScaleRenderMixin —— 模型那一层(客户端渲染时乘倍率)
  用法: 在工作区里建一个代码名为 ScaleUtils 的「全局触发器」流程, 此流程内不要放积木,
  6 个缩放积木生成的代码就会调用下面的方法.
  与 pehkui 没有依赖: 不引用它的任何类, 状态也只写自己的 hxyzg_scale 键.
  注意: 类体故意不闭合 —— 生成器会在后面追加 execute 方法再补最后的 }.
-->
import net.minecraft.world.entity.Entity;

public class ${name}Procedure {
	/** 设置整体缩放. mode = set/add/subtract/multiply/divide; ticks = 过渡刻数(0 = 立刻) */
	public static boolean set(Entity _e, double _v, String _mode, int _ticks) {
		return ${package}.scale.HxgScaleNet.set(_e, _v, _mode, _ticks);
	}

	/** 单独设置宽度/高度倍率(与整体倍率相乘, 直接到位) */
	public static boolean axis(Entity _e, double _w, double _h) {
		return ${package}.scale.HxgScaleNet.axis(_e, _w, _h);
	}

	/** 恢复原版大小(整体平滑回到 1) */
	public static boolean reset(Entity _e, int _ticks) {
		return ${package}.scale.HxgScaleNet.reset(_e, _ticks);
	}

	/** 把所有实体恢复原版大小 */
	public static int resetAll() {
		return ${package}.scale.HxgScaleNet.resetAll();
	}

	/** 这个实体是否被缩放过 */
	public static boolean has(Entity _e) {
		return ${package}.scale.HxgScaleNet.has(_e);
	}

	/** 读取: type = base / width / height / target (width/height 是乘上整体之后的实际倍率) */
	public static double get(Entity _e, String _type) {
		return ${package}.scale.HxgScaleNet.value(_e, _type);
	}

	/** 当前整体倍率 */
	public static double base(Entity _e) {
		return ${package}.scale.HxgScaleNet.value(_e, "base");
	}

	/** 当前实际宽度倍率(整体 x 宽度) */
	public static double width(Entity _e) {
		return ${package}.scale.HxgScaleNet.value(_e, "width");
	}

	/** 当前实际高度倍率(整体 x 高度) */
	public static double height(Entity _e) {
		return ${package}.scale.HxgScaleNet.value(_e, "height");
	}

	/** 过渡的目标整体倍率 */
	public static double target(Entity _e) {
		return ${package}.scale.HxgScaleNet.value(_e, "target");
	}
