<#include "procedures.java.ftl">
@Mod.EventBusSubscriber(Dist.CLIENT) public class ${name}Procedure {
    private static long _shakeUntil = 0L;
    private static double _shakeStrength = 0.0;
    private static long _fadeStart = 0L;
    private static long _fadeUntil = 0L;
    private static int _fadeColor = 0;
    public static void shake(int _ticks, double _strength) {
        _shakeUntil = System.currentTimeMillis() + (long) Math.max(0, _ticks) * 50L;
        _shakeStrength = _strength < 0.0 ? 0.0 : (_strength > 45.0 ? 45.0 : _strength);
    }
    public static void shakeStop() {
        _shakeUntil = 0L;
        _shakeStrength = 0.0;
    }
    public static void fade(int _argbColor, int _ticks) {
        _fadeColor = _argbColor;
        _fadeStart = System.currentTimeMillis();
        _fadeUntil = _fadeStart + (long) Math.max(0, _ticks) * 50L;
    }
    public static void fadeStop() {
        _fadeUntil = 0L;
    }
    public static boolean isShaking() {
        return _shakeUntil > System.currentTimeMillis();
    }
    public static boolean isFading() {
        return _fadeUntil > System.currentTimeMillis();
    }
    @SubscribeEvent public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        if (_shakeUntil <= System.currentTimeMillis() || _shakeStrength <= 0.0) return;
        event.setYaw(event.getYaw() + (float) ((Math.random() - 0.5) * 2.0 * _shakeStrength));
        event.setPitch(event.getPitch() + (float) ((Math.random() - 0.5) * 2.0 * _shakeStrength));
        event.setRoll(event.getRoll() + (float) ((Math.random() - 0.5) * 2.0 * _shakeStrength));
    }
    @SubscribeEvent public static void onRenderGui(RenderGuiEvent.Pre event) {
        long _now = System.currentTimeMillis();
        if (_fadeUntil <= _now) return;
        double _total = (double) Math.max(1L, _fadeUntil - _fadeStart);
        double _left = (double) (_fadeUntil - _now) / _total;
        if (_left > 1.0) _left = 1.0;
        if (_left < 0.0) _left = 0.0;
        int _alpha = (int) ((double) ((_fadeColor >>> 24) & 0xFF) * _left);
        int _color = (_alpha << 24) | (_fadeColor & 0xFFFFFF);
        event.getGuiGraphics().fill(0, 0, event.getGuiGraphics().guiWidth(),
                event.getGuiGraphics().guiHeight(), _color);
    }

// ===== HX_SYNC: 本工具类的渲染同步重放注册(只在客户端加载时执行一次) =====
static {
	RegPacketProcedure.hxRegister("camera.shake", _d -> shake(RegPacketProcedure.hxI(_d, "a0"), RegPacketProcedure.hxN(_d, "a1")));
	RegPacketProcedure.hxRegister("camera.shakeStop", _d -> shakeStop());
	RegPacketProcedure.hxRegister("camera.fade", _d -> fade(RegPacketProcedure.hxI(_d, "a0"), RegPacketProcedure.hxI(_d, "a1")));
	RegPacketProcedure.hxRegister("camera.fadeStop", _d -> fadeStop());
}
