<#include "procedures.java.ftl">
@Mod.EventBusSubscriber(Dist.CLIENT) public class ${name}Procedure {

    private static void _p(LevelAccessor _a, ParticleOptions _particle, double _x, double _y, double _z) {
        if (_a instanceof Level _level) _level.addParticle(_particle, _x, _y, _z, 0.0, 0.0, 0.0);
    }
    private static final java.util.HashMap<Entity, java.util.ArrayDeque<double[]>> _trailHist = new java.util.HashMap<>();
    private static final java.util.HashMap<Entity, ParticleOptions> _trailParticle = new java.util.HashMap<>();
    private static final java.util.HashMap<Entity, Integer> _trailWidth = new java.util.HashMap<>();
    private static int _trailTick = 0;
    public static void start(Entity _entity, ParticleOptions _particle, int _width) {
        if (_entity == null || _particle == null) return;
        _trailHist.put(_entity, new java.util.ArrayDeque<>());
        _trailParticle.put(_entity, _particle);
        _trailWidth.put(_entity, _width < 1 ? 1 : (_width > 20 ? 20 : _width));
    }
    public static void stop(Entity _entity) {
        if (_entity == null) return;
        _trailHist.remove(_entity);
        _trailParticle.remove(_entity);
        _trailWidth.remove(_entity);
    }
    public static boolean isActive(Entity _entity) {
        return _entity != null && _trailHist.containsKey(_entity);
    }
    public static void clearAll() {
        _trailHist.clear();
        _trailParticle.clear();
        _trailWidth.clear();
    }
    private static void _tickTrail(Minecraft _mc) {
        _trailTick++;
        if (_trailTick % 2 != 0 || _trailHist.isEmpty() || _mc.level == null) return;
        java.util.Iterator<java.util.Map.Entry<Entity, java.util.ArrayDeque<double[]>>> _it = _trailHist.entrySet().iterator();
        while (_it.hasNext()) {
            java.util.Map.Entry<Entity, java.util.ArrayDeque<double[]>> _e = _it.next();
            Entity _entity = _e.getKey();
            if (_entity == null || !_entity.isAlive() || _entity.level() != _mc.level) {
                _it.remove();
                _trailParticle.remove(_entity);
                _trailWidth.remove(_entity);
                continue;
            }
            java.util.ArrayDeque<double[]> _hist = _e.getValue();
            _hist.addFirst(new double[] { _entity.getX(), _entity.getY() + (double) _entity.getBbHeight() * 0.5,
                    _entity.getZ() });
            Integer _w = _trailWidth.get(_entity);
            int _max = (_w == null ? 6 : _w.intValue()) * 2;
            while (_hist.size() > _max) _hist.removeLast();
            ParticleOptions _particle = _trailParticle.get(_entity);
            if (_particle == null) continue;
            int _idx = 0;
            for (double[] _pos : _hist) {
                if (_idx % 2 == 0) _p(_mc.level, _particle, _pos[0], _pos[1], _pos[2]);
                _idx++;
            }
        }
    }
    @SubscribeEvent public static void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        _tickTrail(Minecraft.getInstance());
    }

// ===== HX_SYNC: 本工具类的渲染同步重放注册(只在客户端加载时执行一次) =====
static {
	RegPacketProcedure.hxRegister("trail.start", _d -> { net.minecraft.world.entity.Entity _e = RegPacketProcedure.hxEnt(_d); net.minecraft.core.particles.ParticleType<?> _pt = net.minecraft.core.registries.BuiltInRegistries.PARTICLE_TYPE.get(net.minecraft.resources.ResourceLocation.tryParse(RegPacketProcedure.hxS(_d, "s0"))); if (_e != null && _pt instanceof net.minecraft.core.particles.SimpleParticleType _sp) start(_e, _sp, RegPacketProcedure.hxI(_d, "a0")); });
	RegPacketProcedure.hxRegister("trail.stop", _d -> { net.minecraft.world.entity.Entity _e = RegPacketProcedure.hxEnt(_d); if (_e != null) stop(_e); });
}
