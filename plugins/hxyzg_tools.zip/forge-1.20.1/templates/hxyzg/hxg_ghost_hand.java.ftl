package ${package}.mixin;

/*
 * 「虚影视角」下把本体的第一人称手 / 手持物藏掉(客户端).
 *
 * 为什么: 镜头挪到虚影身上以后, 画面是从虚影那边看出去的, 但原版那一双"第一人称的手"
 * (连着手里的东西)还是按镜头画的 —— 于是右下角糊着一把离你不到半格的剑, 换视角以后
 * 看着就像"本体的模型还留在画面上". 虚影自己的身体由工具类照常画(第一人称能看到躯干/
 * 手臂/腿, 头由 HxgGhostPose 藏掉), 这里只切掉**本体**那一层.
 *
 * 挂在哪: ItemInHandRenderer.renderHandsWithItems(...) —— 第一人称画手/手持物的总入口
 * (原版只在第一人称调它, 第三人称 / F5 本来就不调, 所以这里取消对 F5 完全无影响).
 * 条件: HxgGhostView.viewing() —— 只有「虚影视角开着」时才取消; 关掉视角立刻恢复,
 * 与装插件之前逐位一致.
 *
 * 两个分支的宿主方法签名完全相同(1.20.1 / 1.21.1 都是
 * renderHandsWithItems(float, PoseStack, MultiBufferSource.BufferSource, LocalPlayer, int)),
 * 所以这份模板两分支逐字节相同.
 */

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import ${package}.ghost.HxgGhostView;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.MultiBufferSource;

import com.mojang.blaze3d.vertex.PoseStack;

@Mixin(ItemInHandRenderer.class)
public abstract class HxgGhostHandMixin {
	@Inject(method = "renderHandsWithItems(FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource$BufferSource;Lnet/minecraft/client/player/LocalPlayer;I)V", at = @At("HEAD"), cancellable = true)
	private void hxg$ghostHands(float _partial, PoseStack _pose, MultiBufferSource.BufferSource _buffers,
			LocalPlayer _player, int _light, CallbackInfo _ci) {
		try {
			if (HxgGhostView.viewing())
				_ci.cancel();
		} catch (Throwable _t) {
			// 藏手这件事出岔子也不能把渲染拖崩: 不取消就是原版那一套
		}
	}
}
