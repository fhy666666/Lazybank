package ${package}.scale;

/*
 * 「缩放」工具类的状态/同步/持久化层(forge-1.20.1).
 *
 * 一条链: 积木 -> ScaleUtilsProcedure -> 这里 -> 1) 尺寸(EntityEvent.Size 改碰撞箱与眼睛)
 *                                       -> 2) 属性(移动速度/台阶高度/触及距离)
 *                                       -> 3) 持久数据(hxyzg_scale) + 同步包(scale_sync)
 *                                       -> 4) 模型由 HxgScaleRenderMixin 在客户端那一层乘上去
 *
 * 为什么尺寸走事件而不是 mixin: forge 1.20.1 的 Entity.refreshDimensions() 会发 EntityEvent.Size,
 * 事件里能直接换掉新的 EntityDimensions 与眼高 —— 不改原版代码、不需要注入点、启动崩溃面最小.
 * (pehkui 走 mixin 是因为它要同时兼容 fabric/vanilla; 这里只做 forge/neo, 用事件更稳.)
 *
 * 平滑过渡: 服务端每刻把 base 往 target 插一步并广播; 客户端不自己再插值, 所以两边画面一致。
 */

import java.util.ArrayList;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import net.minecraftforge.common.ForgeMod;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class HxgScaleNet {
	private HxgScaleNet() {
	}

	/** 存在实体持久数据里的键(与 pehkui 的键互不相干) */
	private static final String KEY = "hxyzg_scale";
	/** 网络协议版本(包格式改了就 +1) */
	private static final String PROTO = "1";

	/** 属性修饰符的固定 id(每次刷新按 id 换值, 不会越叠越多) */
	private static final UUID U_SPEED = UUID.fromString("6f2a5c1e-2b7d-4f0a-9d3c-1a8e5b7c9d01");
	private static final UUID U_STEP = UUID.fromString("6f2a5c1e-2b7d-4f0a-9d3c-1a8e5b7c9d02");
	private static final UUID U_BLOCK = UUID.fromString("6f2a5c1e-2b7d-4f0a-9d3c-1a8e5b7c9d03");
	private static final UUID U_ENTITY = UUID.fromString("6f2a5c1e-2b7d-4f0a-9d3c-1a8e5b7c9d04");
	/** 原版台阶高度(1.20.1 的 base 值), 用"加成"属性时按它换算 */
	private static final double BASE_STEP = 0.6D;

	/** 服务端: 实体 -> 缩放 */
	private static final Map<Entity, HxgScale.S> SRV = new ConcurrentHashMap<>();
	/** 客户端: 实体 id -> 缩放(渲染/尺寸用) */
	private static final Map<Integer, HxgScale.S> CLI = new ConcurrentHashMap<>();

	private static final SimpleChannel CH = mkChannel();
	private static volatile boolean ready = false;

	private static SimpleChannel mkChannel() {
		try {
			return NetworkRegistry.newSimpleChannel(new ResourceLocation("${modid}", "scale_sync"), () -> PROTO,
					PROTO::equals, PROTO::equals);
		} catch (Throwable t) {
			return null;
		}
	}

	private static void reg() {
		if (ready)
			return;
		ready = true;
		if (CH != null)
			CH.registerMessage(0, Msg.class, Msg::encode, Msg::new, Msg::handle);
	}

	static {
		reg();
		MinecraftForge.EVENT_BUS.addListener(HxgScaleNet::onSize);
		MinecraftForge.EVENT_BUS.addListener(HxgScaleNet::onJoin);
		MinecraftForge.EVENT_BUS.addListener(HxgScaleNet::onTick);
	}

	/** 让本类在启动时就加载一次(否则要等第一次用到积木才注册监听器, 存档里的缩放就接不上) */
	@net.minecraftforge.fml.common.Mod.EventBusSubscriber(bus = net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus.MOD)
	public static class Net {
		@SubscribeEvent
		public static void init(net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent event) {
			reg();
		}
	}

	// ===== 读取(积木与 mixin 都用这个) =====

	/** 这个实体身上的缩放(没设过返回 null); 服务端查实体表, 客户端按 id 查 */
	public static HxgScale.S of(Entity e) {
		if (e == null)
			return null;
		HxgScale.S s = SRV.get(e);
		if (s == null)
			s = CLI.get(e.getId());
		return s;
	}

	public static boolean has(Entity e) {
		HxgScale.S s = of(e);
		return s != null && (!s.vanilla() || s.moving());
	}

	/** type: base / width / height / target (width/height 返回"已经乘上整体"的实际倍率) */
	public static double value(Entity e, String type) {
		HxgScale.S s = of(e);
		if (s == null)
			return 1.0D;
		String t = type == null ? "base" : type.trim().toLowerCase(java.util.Locale.ROOT);
		if ("width".equals(t))
			return (double) s.w();
		if ("height".equals(t))
			return (double) s.h();
		if ("target".equals(t))
			return (double) s.target;
		return (double) s.base;
	}

	// ===== 对外 API(积木调的就是这几个) =====

	/** 设置整体缩放: mode = set/add/subtract/multiply/divide; ticks = 过渡刻数(0 = 立刻) */
	public static boolean set(Entity e, double value, String mode, int ticks) {
		if (e == null || !(e.level() instanceof ServerLevel))
			return false;
		HxgScale.S s = ensure(e);
		float nv = HxgScale.clamp(HxgScale.op(s.base, mode, (float) value));
		start(s, nv, ticks);
		commit(e, s);
		return true;
	}

	/** 单独设置宽度/高度倍率(直接到位; 与整体倍率相乘) */
	public static boolean axis(Entity e, double width, double height) {
		if (e == null || !(e.level() instanceof ServerLevel))
			return false;
		HxgScale.S s = ensure(e);
		s.width = HxgScale.clamp((float) width);
		s.height = HxgScale.clamp((float) height);
		commit(e, s);
		return true;
	}

	/** 恢复原版大小(整体平滑回到 1, 宽高立即回 1) */
	public static boolean reset(Entity e, int ticks) {
		if (e == null || !(e.level() instanceof ServerLevel))
			return false;
		HxgScale.S s = SRV.get(e);
		if (s == null)
			s = load(e);
		if (s == null) {
			sync(e);
			return true;
		}
		s.width = 1.0F;
		s.height = 1.0F;
		start(s, 1.0F, ticks);
		if (s.left <= 0)
			clear(e);
		else
			commit(e, s);
		return true;
	}

	/** 把所有实体恢复原版大小 */
	public static int resetAll() {
		int n = 0;
		for (Entity e : new ArrayList<>(SRV.keySet())) {
			if (e == null)
				continue;
			reset(e, 0);
			n++;
		}
		return n;
	}

	// ===== 内部: 起一段过渡 =====

	private static void start(HxgScale.S s, float nv, int ticks) {
		int t = ticks < 0 ? 0 : ticks;
		s.from = s.base;
		s.target = nv;
		s.total = t;
		s.left = t;
		if (t <= 0 || Math.abs(nv - s.base) < 1.0E-5F) {
			s.base = nv;
			s.left = 0;
			s.total = 0;
		}
	}

	/** 把当前数值落到实体上(尺寸 + 属性 + 存档 + 同步) */
	private static void commit(Entity e, HxgScale.S s) {
		if (s == null)
			return;
		// 注意: 正在过渡时即使"当前 base 还是 1"也必须留下状态 —— 否则从 1 倍往大/小长的第一刻
		// 就会被当成"没缩放过"整份清掉, 过渡永远跑不起来(2.62.28 的实际缺陷).
		if (s.vanilla() && s.left <= 0) {
			clear(e);
			return;
		}
		SRV.put(e, s);
		save(e, s);
		dims(e);
		apply(e, s);
		bcast(e, s);
	}

	/** 恢复原版: 去掉表项、去掉存档键、把属性与尺寸还原 */
	private static void clear(Entity e) {
		SRV.remove(e);
		if (e == null)
			return;
		try {
			e.getPersistentData().remove(KEY);
		} catch (Throwable t) {
		}
		apply(e, null);
		dims(e);
		bcast(e, null);
	}

	private static void sync(Entity e) {
		if (e == null)
			return;
		dims(e);
		apply(e, SRV.get(e));
		bcast(e, SRV.get(e));
	}

	private static HxgScale.S ensure(Entity e) {
		HxgScale.S s = SRV.get(e);
		if (s != null)
			return s;
		s = load(e);
		if (s == null)
			s = new HxgScale.S();
		SRV.put(e, s);
		return s;
	}

	// ===== 尺寸: 换掉事件里的新尺寸与眼高 =====

	public static void onSize(EntityEvent.Size event) {
		Entity e = event.getEntity();
		HxgScale.S s = of(e);
		if (s == null || s.vanilla())
			return;
		EntityDimensions d = event.getNewSize();
		event.setNewSize(d.scale(s.w(), s.h()));
		event.setNewEyeHeight(event.getNewEyeHeight() * s.h());
	}

	private static void dims(Entity e) {
		try {
			if (e != null && e.level() != null)
				e.refreshDimensions();
		} catch (Throwable t) {
			// 尺寸刷新失败不该把游戏搞崩(下一刻还会再试)
		}
	}

	// ===== 属性: 移动速度 / 台阶高度 / 触及距离 =====

	private static void apply(Entity e, HxgScale.S s) {
		if (!(e instanceof LivingEntity))
			return;
		LivingEntity le = (LivingEntity) e;
		float b = (s == null || s.vanilla()) ? 1.0F : s.base;
		double k = (double) b - 1.0D;
		attr(le, Attributes.MOVEMENT_SPEED, U_SPEED, k, AttributeModifier.Operation.MULTIPLY_TOTAL, "hxg_scale_speed");
		attr(le, ForgeMod.STEP_HEIGHT_ADDITION.get(), U_STEP, BASE_STEP * k, AttributeModifier.Operation.ADDITION,
				"hxg_scale_step");
		if (le instanceof Player) {
			attr(le, ForgeMod.BLOCK_REACH.get(), U_BLOCK, k, AttributeModifier.Operation.MULTIPLY_TOTAL,
					"hxg_scale_block_reach");
			attr(le, ForgeMod.ENTITY_REACH.get(), U_ENTITY, k, AttributeModifier.Operation.MULTIPLY_TOTAL,
					"hxg_scale_entity_reach");
		}
	}

	private static void attr(LivingEntity le, Attribute a, UUID id, double amount, AttributeModifier.Operation op,
			String name) {
		if (a == null)
			return;
		AttributeInstance ins;
		try {
			ins = le.getAttribute(a);
		} catch (Throwable t) {
			return;
		}
		if (ins == null)
			return;
		AttributeModifier old = ins.getModifier(id);
		if (Math.abs(amount) < 1.0E-6D) {
			if (old != null)
				ins.removeModifier(id);
			return;
		}
		if (old != null && old.getOperation() == op && Math.abs(old.getAmount() - amount) < 1.0E-6D)
			return;
		if (old != null)
			ins.removeModifier(id);
		ins.addTransientModifier(new AttributeModifier(id, name, amount, op));
	}

	// ===== 服务端每刻: 推进过渡 + 心跳同步 =====

	public static void onTick(TickEvent.LevelTickEvent event) {
		if (event.phase != TickEvent.Phase.END)
			return;
		Level level = event.level;
		if (!(level instanceof ServerLevel))
			return;
		long now = level.getGameTime();
		for (Entity e : new ArrayList<>(SRV.keySet())) {
			HxgScale.S s = SRV.get(e);
			if (s == null)
				continue;
			if (e.isRemoved() || !e.isAlive()) {
				SRV.remove(e);
				continue;
			}
			if (e.level() != level)
				continue;
			if (s.moving()) {
				s.left--;
				float t = s.total <= 0 ? 1.0F : 1.0F - (float) s.left / (float) s.total;
				s.base = HxgScale.lerp(s.from, s.target, HxgScale.ease(t));
				if (s.left <= 0) {
					s.base = s.target;
					s.left = 0;
				}
				save(e, s);
				dims(e);
				apply(e, s);
				bcast(e, s);
				if (s.base == 1.0F && s.width == 1.0F && s.height == 1.0F && !s.moving()) {
					clear(e);
					continue;
				}
			}
			if (now % 20L == 0L)
				bcast(e, s);
		}
	}

	/** 实体从存档读回来/跨维度: 身上还记着缩放就自动接上 */
	public static void onJoin(EntityJoinLevelEvent event) {
		Entity e = event.getEntity();
		if (e == null)
			return;
		if (e.level() instanceof ServerLevel) {
			if (SRV.get(e) == null) {
				HxgScale.S s = load(e);
				if (s != null) {
					SRV.put(e, s);
					dims(e);
					apply(e, s);
				}
			}
			HxgScale.S s = SRV.get(e);
			if (s != null)
				bcast(e, s);
		} else if (CLI.containsKey(e.getId())) {
			dims(e);
		}
	}

	// ===== 持久化 =====

	private static void save(Entity e, HxgScale.S s) {
		try {
			CompoundTag t = new CompoundTag();
			t.putFloat("b", s.base);
			t.putFloat("w", s.width);
			t.putFloat("h", s.height);
			t.putFloat("tg", s.target);
			t.putFloat("fr", s.from);
			t.putInt("lf", s.left);
			t.putInt("tt", s.total);
			e.getPersistentData().put(KEY, t);
		} catch (Throwable t) {
		}
	}

	private static HxgScale.S load(Entity e) {
		try {
			CompoundTag t = e.getPersistentData().getCompound(KEY);
			if (t == null || !t.contains("b"))
				return null;
			HxgScale.S s = new HxgScale.S();
			s.base = HxgScale.clamp(t.getFloat("b"));
			s.width = HxgScale.clamp(t.getFloat("w"));
			s.height = HxgScale.clamp(t.getFloat("h"));
			int lf = t.contains("lf") ? t.getInt("lf") : 0;
			int tt = t.contains("tt") ? t.getInt("tt") : 0;
			if (lf > 0) {
				// 存档是在过渡中途: 从起点接着跑(已经过去的刻数不再补), 不把 base 当成最终值
				s.from = t.contains("fr") ? HxgScale.clamp(t.getFloat("fr")) : s.base;
				s.target = t.contains("tg") ? HxgScale.clamp(t.getFloat("tg")) : s.base;
				s.base = s.from;
				s.left = lf;
				s.total = tt;
			} else {
				s.target = s.base;
				s.from = s.base;
				s.left = 0;
				s.total = 0;
			}
			if (s.vanilla() && s.left <= 0)
				return null;
			return s;
		} catch (Throwable t) {
			return null;
		}
	}

	// ===== 同步: 服务端 -> 同维度所有玩家 =====

	private static void bcast(Entity e, HxgScale.S s) {
		if (CH == null || e == null || !(e.level() instanceof ServerLevel))
			return;
		ServerLevel sl = (ServerLevel) e.level();
		float b = s == null ? 1.0F : s.base;
		float w = s == null ? 1.0F : s.width;
		float h = s == null ? 1.0F : s.height;
		float tg = s == null ? 1.0F : s.target;
		int lf = s == null ? 0 : s.left;
		int tt = s == null ? 0 : s.total;
		Msg m = new Msg(e.getId(), b, w, h, tg, lf, tt);
		for (ServerPlayer p : sl.players())
			CH.send(PacketDistributor.PLAYER.with(() -> p), m);
	}

	/** 收到服务端广播: 记下来(1/1/1 = 恢复原版) 并刷新这一次的尺寸 */
	public static void recv(int id, float base, float width, float height, float target, int left, int total) {
		HxgScale.S s = new HxgScale.S();
		s.base = base;
		s.width = width;
		s.height = height;
		s.target = target;
		s.left = left;
		s.total = total;
		if (s.vanilla())
			CLI.remove(id);
		else
			CLI.put(id, s);
		try {
			net.minecraft.client.multiplayer.ClientLevel cl = net.minecraft.client.Minecraft.getInstance().level;
			if (cl == null)
				return;
			Entity e = cl.getEntity(id);
			if (e != null)
				dims(e);
		} catch (Throwable t) {
		}
	}

	public static class Msg {
		private final int id;
		private final float b, w, h, tg;
		private final int lf, tt;

		public Msg(int id, float b, float w, float h, float tg, int lf, int tt) {
			this.id = id;
			this.b = b;
			this.w = w;
			this.h = h;
			this.tg = tg;
			this.lf = lf;
			this.tt = tt;
		}

		public static void encode(Msg m, net.minecraft.network.FriendlyByteBuf buf) {
			buf.writeVarInt(m.id);
			buf.writeFloat(m.b);
			buf.writeFloat(m.w);
			buf.writeFloat(m.h);
			buf.writeFloat(m.tg);
			buf.writeVarInt(m.lf);
			buf.writeVarInt(m.tt);
		}

		public Msg(net.minecraft.network.FriendlyByteBuf buf) {
			this.id = buf.readVarInt();
			this.b = buf.readFloat();
			this.w = buf.readFloat();
			this.h = buf.readFloat();
			this.tg = buf.readFloat();
			this.lf = buf.readVarInt();
			this.tt = buf.readVarInt();
		}

		public void handle(java.util.function.Supplier<net.minecraftforge.network.NetworkEvent.Context> ctx) {
			net.minecraftforge.network.NetworkEvent.Context c = ctx.get();
			c.enqueueWork(() -> recv(id, b, w, h, tg, lf, tt));
			c.setPacketHandled(true);
		}
	}
}
