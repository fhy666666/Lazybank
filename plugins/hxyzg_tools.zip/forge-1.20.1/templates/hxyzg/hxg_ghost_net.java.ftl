package ${package}.ghost;

/*
 * 「虚影视角」的服务端配合: 把玩家的"够到距离"临时放宽「本体眼睛 -> 虚影眼睛」那一段(forge-1.20.1).
 *
 * 为什么需要它: 准星/挖掘/攻击的射线起点已经在客户端换成了虚影眼睛(HxgGhostPickMixin /
 * HxgGhostGPickMixin), 但服务端校验(破坏方块 / 放方块 / 攻击实体 / 右键实体)永远是
 * "玩家眼睛 + 触及距离"。虚影离本体越远, 被服务端判成"够不着"的概率越大 —— 于是从虚影那边
 * 看着能挖的方块, 挖下去却没反应。
 *
 * 客户端那边(GhostUtilsProcedure 的 _reachLocal(...): 给本机玩家的方块/实体触及距离加一段
 * 属性修饰符, 拾取长度与"太远就丢掉"那道闸都读它)已经把这**一段加进射线长度**了: 从虚影眼睛
 * 出发能挖到「本体距离 + 这一段」. 所以从本体眼睛量过去, 最远是两倍这一段 ——
 * 服务端的放宽量就取这个两倍(上限 64 格):
 *   服务端校验起点(本体眼睛) + 2 x (虚影距离) >= 虚影那边看到的任何目标距离
 * 所以"虚影够得着的"在服务端一定判得过(客户端多出来的那一段不会被判成超距);
 * 而虚影视角一关, 客户端马上发 0, 修饰符当场撤掉。
 *
 * 用属性修饰符而不是改校验逻辑: 两个分支的破坏/放置/攻击/右键全都走
 * ForgeMod.BLOCK_REACH / ENTITY_REACH(1.21.1 是原版 BLOCK_INTERACTION_RANGE / ENTITY_INTERACTION_RANGE),
 * 加一个 ADDITION 修饰符就够了 —— 不注入任何服务端代码、不改原版校验、退出世界时玩家实体没了修饰符自然消失。
 *
 * 安全性: 只接受**发送者自己**的数值(拿不到别人的), 上限 64 格(虚影本身最远也就 ±16 格距离 + ±16 格 Y 偏移,
 * 斜着算约 27.7 格), 并且只在虚影视角开启期间生效。它确实等于"允许超距交互", 但那正是这个功能要的:
 * 镜头在虚影身上时, 你人在本体、手在虚影。
 */

import java.util.UUID;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.player.Player;

import net.minecraftforge.common.ForgeMod;

/** 注意: 本类会被客户端与服务端同时加载, 里面**不能**出现任何客户端类 */
public final class HxgGhostNet {
	private HxgGhostNet() {
	}

	private static final String PROTO = "1";
	/** 与缩放工具类用的那 4 个 id 错开, 互不覆盖 */
	private static final UUID U_BLOCK = UUID.fromString("6f2a5c1e-2b7d-4f0a-9d3c-1a8e5b7c9d05");
	private static final UUID U_ENTITY = UUID.fromString("6f2a5c1e-2b7d-4f0a-9d3c-1a8e5b7c9d06");
	private static final double MAX = 64.0D;

	private static final net.minecraftforge.network.simple.SimpleChannel CH = mk();
	private static volatile boolean ready = false;

	private static net.minecraftforge.network.simple.SimpleChannel mk() {
		try {
			return net.minecraftforge.network.NetworkRegistry.newSimpleChannel(
					new ResourceLocation("${modid}", "ghost_view"), () -> PROTO, PROTO::equals, PROTO::equals);
		} catch (Throwable t) {
			return null;
		}
	}

	private static void reg() {
		if (ready)
			return;
		ready = true;
		if (CH != null)
			CH.registerMessage(0, Msg.class, Msg::encode, Msg::new, Msg::handle);
	}

	static {
		reg();
	}

	/** 让本类在启动时就加载一次(否则要等第一次用到虚影才建通道) */
	@net.minecraftforge.fml.common.Mod.EventBusSubscriber(bus = net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus.MOD)
	public static class Net {
		@net.minecraftforge.eventbus.api.SubscribeEvent
		public static void init(net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent event) {
			reg();
		}
	}

	/** 客户端调: 告诉服务端「镜头在虚影身上, 本体眼睛离它 extra 格」; extra <= 0 = 撤掉放宽 */
	public static void send(double extra) {
		if (CH == null)
			return;
		try {
			CH.sendToServer(new Msg((float) clamp(extra)));
		} catch (Throwable t) {
			// 没连上/服务端没装: 发不出去就算了, 客户端画面不受影响
		}
	}

	static double clamp(double v) {
		return v < 0.0D ? 0.0D : (v > MAX ? MAX : v);
	}

	/** 服务端: 把够到距离临时加上这一段(只作用在发送者自己身上) */
	static void apply(Player p, double extra) {
		if (p == null)
			return;
		// 客户端那边的射线长度 = 本体距离 + 这一段(从虚影眼睛出发); 从**本体眼睛**量, 最远就是两倍这一段
		double d = clamp(extra);
		double dd = clamp(d + d);
		attr(p, ForgeMod.BLOCK_REACH.get(), U_BLOCK, dd);
		attr(p, ForgeMod.ENTITY_REACH.get(), U_ENTITY, dd);
	}

	private static void attr(Player p, Attribute a, UUID id, double amount) {
		if (a == null)
			return;
		AttributeInstance ins;
		try {
			ins = p.getAttribute(a);
		} catch (Throwable t) {
			return;
		}
		if (ins == null)
			return;
		AttributeModifier old = ins.getModifier(id);
		if (Math.abs(amount) < 1.0E-4D) {
			if (old != null)
				ins.removeModifier(id);
			return;
		}
		if (old != null && Math.abs(old.getAmount() - amount) < 1.0E-4D)
			return;
		if (old != null)
			ins.removeModifier(id);
		ins.addTransientModifier(
				new AttributeModifier(id, "hxg_ghost_reach", amount, AttributeModifier.Operation.ADDITION));
	}

	/** 一条「虚影离本体多远」的客户端->服务端消息 */
	public static class Msg {
		private final float extra;

		public Msg(float extra) {
			this.extra = extra;
		}

		public static void encode(Msg m, net.minecraft.network.FriendlyByteBuf buf) {
			buf.writeFloat(m.extra);
		}

		public Msg(net.minecraft.network.FriendlyByteBuf buf) {
			this.extra = buf.readFloat();
		}

		public void handle(java.util.function.Supplier<net.minecraftforge.network.NetworkEvent.Context> ctx) {
			net.minecraftforge.network.NetworkEvent.Context c = ctx.get();
			c.enqueueWork(() -> apply(c.getSender(), extra));
			c.setPacketHandled(true);
		}
	}
}
