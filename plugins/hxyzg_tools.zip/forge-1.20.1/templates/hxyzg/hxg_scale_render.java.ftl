package ${package}.mixin;

/*
 * 「缩放」的模型层: 只改渲染用的姿势矩阵, 不碰任何物理.
 *
 * 注入点在 LivingEntityRenderer.render() 里 "this.scale(...)" 那一次调用之后 —— 此时渲染器已经
 * 把模型空间摆好(rotate + scale(-1,-1,1)), 还没做 translate(0,-1.501,0); 这里乘上倍率就等于
 * "以脚为原点把模型拉大/缩小", 与 1.21.1 原版 SCALE 属性的做法同一个位置(所以脚不会沉进地里).
 *
 * 放在这个位置而不是 scale() 方法体里, 是为了连"重写了 scale() 但没调 super"的那些渲染器也一起盖上.
 * 名牌/阴影在 popPose() 之后画, 不受影响.
 */

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.mojang.blaze3d.vertex.PoseStack;

import ${package}.scale.HxgScale;
import ${package}.scale.HxgScaleNet;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.world.entity.LivingEntity;

@Mixin(LivingEntityRenderer.class)
public abstract class HxgScaleRenderMixin {
	@Inject(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;scale(Lnet/minecraft/world/entity/LivingEntity;Lcom/mojang/blaze3d/vertex/PoseStack;F)V", shift = At.Shift.AFTER))
	private void hxg$scaleModel(LivingEntity entity, float yaw, float partial, PoseStack pose, MultiBufferSource buffer,
			int light, CallbackInfo ci) {
		try {
			HxgScale.S s = HxgScaleNet.of(entity);
			if (s == null || s.vanilla())
				return;
			pose.scale(s.w(), s.h(), s.w());
		} catch (Throwable t) {
			// 渲染不能因为这里出错就崩
		}
	}
}
