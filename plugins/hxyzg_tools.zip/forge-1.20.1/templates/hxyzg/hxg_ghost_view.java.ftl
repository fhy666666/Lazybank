package ${package}.ghost;

/*
 * 「虚影视角」(客户端).
 *
 * 干什么: 把镜头挪到某一具虚影的"眼睛"上 —— 你看到的是虚影那个位置/高度的画面, 但移动、瞄准、按键
 * 仍然全部作用在本体上(相机实体没换, 只是位置被顶掉).
 *
 * 谁在什么时候写: 工具类每帧算好这具虚影的眼睛位置(落点 + 眼高 x 高度倍率)与「本体眼睛到虚影眼睛」的距离
 * 后调 update(...); 相机 mixin(HxgGhostCameraMixin)在 Camera.setup 的 RETURN 处读 eye(...) 并把相机挪过去;
 * 准星/挖掘/攻击的射线起点由 Entity.pick 与 GameRenderer.pick 上的两个 mixin 用 eyeFor(...) 换成同一个点
 * (所以「从虚影位置看出去」和「从虚影位置够得着」是同一个原点), 射线长度再用 extra() 加上那一段
 * (从虚影那边继续往够 = 本体距离 + 本体到虚影这一段; 服务端按同一口径放宽).
 * 另外 viewing() 给「第一人称把手/手持物藏掉」那个 mixin 用(HxgGhostHandMixin):
 * 镜头既然在虚影身上, 本体那一双第一人称的手就不该再糊在画面右下角.
 * 之所以由工具类喂坐标、这个类只存坐标: 相机 setup 比虚影渲染早, 只能吃"上一帧算好的那个点",
 * 而这样本类就不需要认识虚影的任何状态(没建工具类流程时它一直返回 false, 等于不存在).
 *
 * 只对自己这台机器上的玩家生效: 别人的摄像机不该被你改(工具类在 setView 里判 e == mc.player).
 */
public final class HxgGhostView {
	// 哪一具虚影在当摄像机 / 它的眼睛位置(上一帧算好的) / 有没有算过一次
	private static net.minecraft.world.entity.Entity _entity;
	private static double _x, _y, _z;
	// 本体眼睛 -> 虚影眼睛 的直线距离(格): 准星/挖掘/攻击的射线要按它加长, 服务端也按它放宽
	private static double _extra;
	private static boolean _has;

	public static void setView(net.minecraft.world.entity.Entity _e, boolean _on) {
		if (_on) {
			_entity = _e;
			_has = false;	// 还没算过眼睛位置: 相机先别动, 免得跳一下(0,0,0)
			_extra = 0.0D;
		} else if (_e == null || _entity == _e) {
			clearAll();
		}
	}

	public static boolean isView(net.minecraft.world.entity.Entity _e) {
		return _e != null && _entity == _e;
	}

	/** 工具类每帧调: 记下这具虚影此刻的眼睛位置 */
	public static void update(net.minecraft.world.entity.Entity _e, double _x2, double _y2, double _z2) {
		update(_e, _x2, _y2, _z2, 0.0D);
	}

	/** 工具类每帧调: 眼睛位置 + 「本体眼睛到虚影眼睛」这一段(射线长度按它加长; 负数/无效值按 0) */
	public static void update(net.minecraft.world.entity.Entity _e, double _x2, double _y2, double _z2, double _d) {
		if (_e == null || _entity != _e)
			return;
		_x = _x2;
		_y = _y2;
		_z = _z2;
		_extra = _d > 0.0D ? _d : 0.0D;
		_has = true;
	}

	/**
	 * 窄入口: 只有「这具虚影正在当摄像机」时才给眼睛位置 —— 准星 / 挖掘 / 攻击的射线起点用它.
	 * 与 eye(...) 的区别: 这里带实体校验, 在 Entity.pick / GameRenderer.pick 那种「谁来问都可能」的地方才安全.
	 */
	public static boolean eyeFor(net.minecraft.world.entity.Entity _e, double[] _out) {
		if (_e == null || _entity != _e)
			return false;
		return eye(_out);
	}

	/** 相机 mixin 调: 拿到眼睛位置就返回 true 并写进 _out */
	public static boolean eye(double[] _out) {
		if (!_has || _entity == null || _out == null || _out.length < 3)
			return false;
		_out[0] = _x;
		_out[1] = _y;
		_out[2] = _z;
		return true;
	}

	/** 射线要加长多少(本体眼睛 -> 虚影眼睛); 没开视角 / 还没算过 = 0 */
	public static double extra() {
		return _has ? _extra : 0.0D;
	}

	/** 虚影视角现在开着没有(第一人称要藏掉本体那双第一人称的手/手持物时用它) */
	public static boolean viewing() {
		return _entity != null;
	}

	public static void clear(net.minecraft.world.entity.Entity _e) {
		if (_e != null && _entity == _e)
			clearAll();
	}

	public static void clearAll() {
		_entity = null;
		_has = false;
		_x = 0.0D;
		_y = 0.0D;
		_z = 0.0D;
		_extra = 0.0D;
	}

	/** 虚影的眼睛位置 = 落点 + 眼高 x 高度倍率(纯函数) */
	public static double[] eyeOf(double[] _anchor, double _eyeH, double _sh) {
		if (_anchor == null || _anchor.length < 3)
			return new double[] { 0.0D, 0.0D, 0.0D };
		return new double[] { _anchor[0], _anchor[1] + _eyeH * _sh, _anchor[2] };
	}
}
