package ${package}.mixin;

/*
 * 「虚影视角」的准星 / 挖掘 / 攻击原点 —— 方块与实体拾取那一段(客户端, forge-1.20.1).
 *
 * 与 HxgGhostPickMixin 是一对: 那一份换的是 Entity.pick 里的眼睛(方块射线), 这一份换的是
 * GameRenderer 拾取循环里的那个眼睛(实体射线 + 距离过滤). 两份必须是同一个点, 否则会出现
 * "方块从虚影那边选、实体从本体那边选" —— 准星在实体和方块之间来回跳.
 *
 * 挂在哪个方法: forge-1.20.1 = GameRenderer.pick(F)V (public void pick(float))
 *
 * 只换**起点**, 不碰距离: 长度/触及距离那一套仍走本体的属性值(方块/实体触及距离).
 * 「虚影视角下够到距离 = 本体距离 + 本体到虚影这一段」是在客户端**加属性修饰符**做的
 * —— 见 GhostUtilsProcedure 的 _reachLocal(...): 原版这四个距离全都从属性读数
 * (getPickRange -> getBlockReach; 实体射线用 getEntityReach), 加一段就等于三处一起加长,
 * 不用在方法体里挨个改常量. 服务端按同一口径放宽两倍(见 ghost/HxgGhostNet).
 *
 * 视野方向、以及这里之外任何一处 getEyePosition(雾 / 音源 / 入水判定 / 弹射物起点)都不碰.
 */

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import ${package}.ghost.HxgGhostView;

import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

@Mixin(GameRenderer.class)
public abstract class HxgGhostGPickMixin {
	private static final double[] _HX_PICK_EYE = new double[3];

	@Redirect(method = "pick(F)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;getEyePosition(F)Lnet/minecraft/world/phys/Vec3;"))
	private Vec3 hxg$ghostPickEye(Entity _self, float _partial) {
		if (HxgGhostView.eyeFor(_self, _HX_PICK_EYE))
			return new Vec3(_HX_PICK_EYE[0], _HX_PICK_EYE[1], _HX_PICK_EYE[2]);
		return _self.getEyePosition(_partial);
	}
}
