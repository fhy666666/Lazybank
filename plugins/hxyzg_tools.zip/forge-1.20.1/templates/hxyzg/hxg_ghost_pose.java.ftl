package ${package}.ghost;

/*
 * 「虚影」的部位冻结(客户端).
 *
 * 干什么: 让某一具虚影的头 / 手 / 腿「不动」—— 勾上的部位记住"勾上那一刻的姿势"并一直保持,
 * 其余部位照常跟着本体做动作. 只对正在画的那具虚影生效(工具类在画之前 begin、画完 end),
 * 本体自己的渲染完全不受影响.
 *
 * 怎么接上: 本插件生成的 HxgGhostPoseMixin 在 LivingEntityRenderer.render 里 this.model.setupAnim(...)
 * 之后调用 apply(model) —— 那一刻姿势刚算完、还没画到缓冲, 是唯一能"改部位"的缝.
 *
 * 另外还管「第一人称时把虚影的头藏掉」: 镜头就在虚影的眼睛里(= 头里面)的时候, 如果照常画,
 * 头的前脸会糊满整个屏幕; 所以工具类在 begin 时传 hideHead = true, 这里把 HumanoidModel.head 的
 * visible 临时置 false(帽子是它的子节点, 一起藏), 画完 end() 里按原值复原 —— 复原有必要:
 * 模型对象是跟本体共用的, 不还原下一帧本体自己的头也没了.
 *
 * 支持范围: 人形模型(HumanoidModel: 玩家 / 僵尸 / 骷髅 / 村民 / 掠夺者 ...).
 * 其它模型(四足动物等)调用 apply 什么也不做, 不会崩、也不会画出怪东西.
 */
public final class HxgGhostPose {
	public static final int HEAD = 1;	// 头 + 帽子
	public static final int ARMS = 2;	// 左右手
	public static final int LEGS = 4;	// 左右腿
	public static final int SNEAK = 8;	// 潜行不动: 本体蹲下/爬行时虚影保持站立时的姿势

	// 部位表序号: 0 头, 1 帽子, 2 右臂, 3 左臂, 4 右腿, 5 左腿 (每个部位记 3 个旋转)
	private static final int _PARTS = 6;
	private static final int _ALL = HEAD | ARMS | LEGS | SNEAK;

	// 每个实体一份: 冻结哪些部位 / 记住的姿势 / 哪几组已经记过 / 站立姿势(潜行不动用)
	private static final java.util.concurrent.ConcurrentHashMap<net.minecraft.world.entity.Entity, Integer> _MASK = new java.util.concurrent.ConcurrentHashMap<>();
	private static final java.util.concurrent.ConcurrentHashMap<net.minecraft.world.entity.Entity, float[]> _SNAP = new java.util.concurrent.ConcurrentHashMap<>();
	private static final java.util.concurrent.ConcurrentHashMap<net.minecraft.world.entity.Entity, Integer> _DONE = new java.util.concurrent.ConcurrentHashMap<>();
	private static final java.util.concurrent.ConcurrentHashMap<net.minecraft.world.entity.Entity, float[]> _STAND = new java.util.concurrent.ConcurrentHashMap<>();

	// 正在画的那具虚影(只在渲染线程里写读)
	private static net.minecraft.world.entity.Entity _rendering;
	// 这一下要不要把头藏掉(第一人称镜头在虚影头里的时候) / 藏之前那具模型与它 head.visible 的原值
	private static boolean _hideHead;
	private static net.minecraft.client.model.HumanoidModel<?> _hidden;
	private static boolean _hiddenWas = true;

	/** 四个开关 -> 位掩码(纯函数) */
	public static int mask(boolean _head, boolean _arms, boolean _legs, boolean _sneak) {
		return (_head ? HEAD : 0) | (_arms ? ARMS : 0) | (_legs ? LEGS : 0) | (_sneak ? SNEAK : 0);
	}

	/** 老签名(没有潜行这一档)的兼容重载 */
	public static int mask(boolean _head, boolean _arms, boolean _legs) {
		return mask(_head, _arms, _legs, false);
	}

	/** 部位序号 -> 它属于哪一组(纯函数) */
	static int _bitOf(int _i) {
		return _i <= 1 ? HEAD : (_i <= 3 ? ARMS : LEGS);
	}

	public static void setFreeze(net.minecraft.world.entity.Entity _e, int _mask) {
		if (_e == null)
			return;
		int _m = _mask & _ALL;
		if (_m == 0) {
			clear(_e);
			return;
		}
		_MASK.put(_e, Integer.valueOf(_m));
		_DONE.remove(_e);	// 重新勾选 = 重新取一次"当前的姿势"
	}

	public static int maskOf(net.minecraft.world.entity.Entity _e) {
		if (_e == null)
			return 0;
		Integer _m = _MASK.get(_e);
		return _m == null ? 0 : _m.intValue();
	}

	/** 停掉某实体的虚影 / 实体没了 / 退出世界时把记录也清掉 */
	public static void clear(net.minecraft.world.entity.Entity _e) {
		if (_e == null)
			return;
		_MASK.remove(_e);
		_SNAP.remove(_e);
		_DONE.remove(_e);
		_STAND.remove(_e);
	}

	public static void clearAll() {
		_MASK.clear();
		_SNAP.clear();
		_DONE.clear();
		_STAND.clear();
	}

	/** 工具类在画虚影之前调 */
	public static void begin(net.minecraft.world.entity.Entity _e) {
		begin(_e, false);
	}

	/** 工具类在画虚影之前调; _hideH = 这一下把头藏掉(第一人称镜头就在这具虚影头里的时候) */
	public static void begin(net.minecraft.world.entity.Entity _e, boolean _hideH) {
		_rendering = _e;
		_hideHead = _hideH;
	}

	/** 工具类画完虚影之后调(放在 finally 里): 顺便把藏掉的头按原值复原 */
	public static void end() {
		if (_hidden != null) {
			try {
				_hidden.head.visible = _hiddenWas;
			} catch (Throwable _t) {
				// 复原失败也只是多藏一帧, 不能因此把这一帧的渲染拖崩
			}
			_hidden = null;
		}
		_rendering = null;
		_hideHead = false;
	}

	/** mixin 在 setupAnim 之后调: 把冻结的部位按第一次记下的姿势按住; _crouching = 本体此刻是否在潜行 */
	public static void apply(net.minecraft.client.model.EntityModel<?> _model, boolean _crouching) {
		// 先处理「藏头」: 它跟部位冻结无关, 没勾任何冻结也要生效(第一人称画面就靠它)
		if (_hideHead && _model instanceof net.minecraft.client.model.HumanoidModel) {
			net.minecraft.client.model.HumanoidModel<?> _hm = (net.minecraft.client.model.HumanoidModel<?>) _model;
			if (_hm.head != null) {
				_hidden = _hm;
				_hiddenWas = _hm.head.visible;
				_hm.head.visible = false;
			}
		}
		net.minecraft.world.entity.Entity _e = _rendering;
		if (_e == null || _model == null)
			return;
		int _mask = maskOf(_e);
		if (_mask == 0)
			return;
		if (!(_model instanceof net.minecraft.client.model.HumanoidModel))
			return;	// 只有人形模型有这 6 个部位
		net.minecraft.client.model.HumanoidModel<?> _hm = (net.minecraft.client.model.HumanoidModel<?>) _model;
		net.minecraft.client.model.geom.ModelPart[] _parts = new net.minecraft.client.model.geom.ModelPart[] { _hm.head, _hm.hat, _hm.rightArm,
				_hm.leftArm, _hm.rightLeg, _hm.leftLeg };
		float[] _s = _SNAP.get(_e);
		if (_s == null) {
			_s = new float[_PARTS * 3];
			_SNAP.put(_e, _s);
		}
		// 潜行不动: 没蹲的时候每帧记下"站立姿势", 蹲下时把站立姿势按住(站起来立刻恢复跟本体)
		boolean _sneak = (_mask & SNEAK) != 0;
		float[] _st = null;
		if (_sneak) {
			_st = _STAND.get(_e);
			if (_st == null) {
				_st = new float[_PARTS * 3];
				_STAND.put(_e, _st);
			}
			if (!_crouching)
				_poseSave(_st, _parts);	// 站着: 一直刷新站立姿势(顺便跟着走路摆臂走)
		}
		Integer _done = _DONE.get(_e);
		int _d = _done == null ? 0 : _done.intValue();
		boolean _changed = false;
		for (int _i = 0; _i < _PARTS; _i++) {
			if ((_mask & _bitOf(_i)) == 0)
				continue;
			net.minecraft.client.model.geom.ModelPart _p = _parts[_i];
			if (_p == null)
				continue;
			if ((_d & _bitOf(_i)) == 0) {	// 这一组第一次画: 记住现在的姿势
				_s[_i * 3] = _p.xRot;
				_s[_i * 3 + 1] = _p.yRot;
				_s[_i * 3 + 2] = _p.zRot;
				_d |= _bitOf(_i);
				_changed = true;
			} else {	// 之后每帧写回去 = 定住不动
				_p.xRot = _s[_i * 3];
				_p.yRot = _s[_i * 3 + 1];
				_p.zRot = _s[_i * 3 + 2];
			}
		}
		if (_changed)
			_DONE.put(_e, Integer.valueOf(_d));
		if (_sneak && _crouching && _st != null)
			_poseApply(_st, _parts);
	}

	/** 把 6 个部位的旋转记进数组(潜行不动用) */
	static void _poseSave(float[] _s, net.minecraft.client.model.geom.ModelPart[] _p) {
		if (_s == null || _p == null)
			return;
		for (int _i = 0; _i < _PARTS; _i++) {
			if (_p[_i] == null)
				continue;
			_s[_i * 3] = _p[_i].xRot;
			_s[_i * 3 + 1] = _p[_i].yRot;
			_s[_i * 3 + 2] = _p[_i].zRot;
		}
	}

	/** 把数组里的旋转写回 6 个部位 */
	static void _poseApply(float[] _s, net.minecraft.client.model.geom.ModelPart[] _p) {
		if (_s == null || _p == null)
			return;
		for (int _i = 0; _i < _PARTS; _i++) {
			if (_p[_i] == null)
				continue;
			_p[_i].xRot = _s[_i * 3];
			_p[_i].yRot = _s[_i * 3 + 1];
			_p[_i].zRot = _s[_i * 3 + 2];
		}
	}
}
