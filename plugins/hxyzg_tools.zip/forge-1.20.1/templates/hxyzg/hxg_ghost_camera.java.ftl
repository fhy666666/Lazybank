package ${package}.mixin;

/*
 * 「虚影视角」的相机注入点(客户端).
 *
 * 注入在 Camera.setup 的 RETURN: 原版(以及重力那一套 HxgCameraMixin 的 @Redirect)已经把相机的
 * 位置/朝向摆好了, 这里最后一步把"位置"换成虚影身上的点 —— 朝向不动, 所以鼠标、准星、
 * 手上物品、移动方向全都还是本体那一套(=「实际还是操作本体」).
 *
 * 【F5 三种人称也要能用】原版 setup 的流程是: 先把相机摆在本体眼睛上; 只有在第三人称(detached)
 * 时才再沿 -forwards 从眼睛往后挪一段(距离 = getMaxZoom(4.0), 撞到方块会缩短)。所以这里**不改"挪多远"**,
 * 只把"从哪儿开始挪"换成虚影的眼睛:
 *   1) 原版算完之后, 相机位置 - 原版眼睛位置 = 那一小段 offset(第一人称时它约等于 0);
 *   2) 把这个 offset 的长度当拉远距离、方向当朝向, 从虚影眼睛出发**重新做一次**防穿墙裁剪
 *      (8 个抖动采样, 与原版 getMaxZoom 同一套) —— 不重新裁的话, 虚影身后有墙时镜头会穿进墙里;
 *   3) 相机位置 = 虚影眼睛 + 方向 x 新距离。
 * 于是: 第一人称 = 就在虚影眼睛里; 第三人称(背后) = 退到虚影后面; 第二人称(正面) = 绕到虚影前面.
 * 原版那两个布尔量不改: 朝向、FOV、雾都还是本体那套.
 *
 * 为什么不用 @Redirect 抢 setPosition 那个调用点: HxgCameraMixin 已经在那一个 ordinal 上挂了
 * @Redirect(重力), 同一个调用点再来一个会打架; 用 RETURN 注入只是"再调一次同名的 protected 方法",
 * 不碰原调用点, 两边可以共存. setPosition 是 protected, 混入类不是 Camera 的子类, 只能 @Shadow 挂出来.
 *
 * 没开虚影视角 / 还没算过眼睛位置时 eye(...) 返回 false, 这里立刻返回, 与原版逐位一致.
 */

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import ${package}.ghost.HxgGhostView;

import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

@Mixin(Camera.class)
public abstract class HxgGhostCameraMixin {
	@Shadow
	protected abstract void setPosition(double x, double y, double z);

	// getPosition() 是 Camera 的公开方法, 但混入类不是 Camera 的子类 —— 想调就得先 @Shadow 挂出来
	@Shadow
	public abstract Vec3 getPosition();

	// 原版 setup 里那两个"平滑过的眼高"(相机跟本体眼高跟得很慢), 拿它才能算出与原版逐位相同的起始眼睛位置
	@Shadow
	private float eyeHeight;
	@Shadow
	private float eyeHeightOld;

	private static final double[] _HX_EYE = new double[3];

	@Inject(method = "setup(Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/world/entity/Entity;ZZF)V", at = @At("RETURN"))
	private void hxg$ghostView(BlockGetter _level, Entity _entity, boolean _detached, boolean _front, float _partial,
			CallbackInfo _ci) {
		try {
			if (!HxgGhostView.eye(_HX_EYE))
				return;
			if (!_detached) {
				// 第一人称(以及睡觉那一档): 相机就摆在虚影的眼睛里
				this.setPosition(_HX_EYE[0], _HX_EYE[1], _HX_EYE[2]);
				return;
			}
			// 原版 setup 第一句 setPosition 用的那个"眼睛"点 = 插值位置 + 相机平滑过的眼高
			Vec3 _pos = this.getPosition();
			double _bx = _entity.xo + (_entity.getX() - _entity.xo) * (double) _partial;
			double _by = _entity.yo + (_entity.getY() - _entity.yo) * (double) _partial
					+ (double) (this.eyeHeightOld + (this.eyeHeight - this.eyeHeightOld) * _partial);
			double _bz = _entity.zo + (_entity.getZ() - _entity.zo) * (double) _partial;
			double _dx = _pos.x - _bx;
			double _dy = _pos.y - _by;
			double _dz = _pos.z - _bz;
			double _len = Math.sqrt(_dx * _dx + _dy * _dy + _dz * _dz);
			if (_len < 0.01D) {
				// 原版这一档没挪(理论上不会发生), 按第一人称处理, 免得除零
				this.setPosition(_HX_EYE[0], _HX_EYE[1], _HX_EYE[2]);
				return;
			}
			double _ux = _dx / _len;
			double _uy = _dy / _len;
			double _uz = _dz / _len;
			double _d = _zoom(_level, _entity, _HX_EYE, _ux, _uy, _uz, _len);
			this.setPosition(_HX_EYE[0] + _ux * _d, _HX_EYE[1] + _uy * _d, _HX_EYE[2] + _uz * _d);
		} catch (Throwable _t) {
			// 相机不能因为这里出错就崩
		}
	}

	/**
	 * 从虚影眼睛沿 (ux,uy,uz) 退 max 格, 撞到方块就提前停下(与原版 Camera.getMaxZoom 同一套 8 点抖动采样).
	 * 原版那段是从本体眼睛出发采样的; 镜头挪到虚影身上以后必须从虚影眼睛重新采, 否则虚影后面有墙时镜头会穿墙.
	 */
	// 必须是 private: Mixin 的 apply 阶段会拒绝混入类里任何非 private 的静态成员
	// (MixinApplicatorStandard.checkMethodVisibility -> InvalidMixinException, 启动即崩)
	private static double _zoom(BlockGetter _level, Entity _entity, double[] _eye, double _ux, double _uy, double _uz,
			double _max) {
		double _d = _max;
		if (_level == null || _eye == null || _eye.length < 3)
			return _d;
		for (int _i = 0; _i < 8; _i++) {
			double _jx = (double) ((_i & 1) * 2 - 1) * 0.1D;
			double _jy = (double) ((_i >> 1 & 1) * 2 - 1) * 0.1D;
			double _jz = (double) ((_i >> 2 & 1) * 2 - 1) * 0.1D;
			Vec3 _from = new Vec3(_eye[0] + _jx, _eye[1] + _jy, _eye[2] + _jz);
			Vec3 _to = new Vec3(_eye[0] + _ux * _max + _jx, _eye[1] + _uy * _max + _jy, _eye[2] + _uz * _max + _jz);
			HitResult _hit = _level.clip(
					new ClipContext(_from, _to, ClipContext.Block.VISUAL, ClipContext.Fluid.NONE, _entity));
			if (_hit.getType() != HitResult.Type.MISS) {
				double _dd = _hit.getLocation().distanceTo(_from);
				if (_dd < _d)
					_d = _dd;
			}
		}
		return _d;
	}
}
