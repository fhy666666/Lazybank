package ${package}.scale;

/*
 * 「缩放」工具类的数据层(纯数据 + 纯计算, 不碰任何原版 API 的副作用).
 *
 * 与 pehkui 的关系: 这份实现不引用 pehkui 的任何类/接口, 也不读写它的键 —— 自己的状态只存在
 * 实体持久数据的 hxyzg_scale 里(与 pehkui:scale_data_types 互不相干), 所以两个都装时:
 * 不覆盖、不报错、不需要 pehkui 的 API; 同一个实体两边都设了倍率时数值相乘(两套系统各自算自己的).
 *
 * 这里只放"算得出来"的部分: 倍率钳制、过渡插值、运算模式. 真正改世界的副作用(碰撞箱/眼睛/模型/
 * 属性/同步/存档)在 HxgScaleNet, 模型那一层在 HxgScaleRenderMixin.
 */
public final class HxgScale {
	private HxgScale() {
	}

	/** 允许的最小倍率(再小会让碰撞箱变成 0 宽) */
	public static final float MIN = 0.05F;
	/** 允许的最大倍率(再大会把区块挤爆/卡死服务端) */
	public static final float MAX = 16.0F;

	/** 一个实体身上那份缩放(服务端权威, 客户端收到的是同一份数值) */
	public static final class S {
		/** 整体倍率 */
		public float base = 1.0F;
		/** 宽度倍率(单独乘在整体上) */
		public float width = 1.0F;
		/** 高度倍率(单独乘在整体上) */
		public float height = 1.0F;
		/** 过渡的目标整体倍率 */
		public float target = 1.0F;
		/** 过渡的起点整体倍率 */
		public float from = 1.0F;
		/** 过渡剩余刻数(0 = 不过渡, 直接到位) */
		public int left;
		/** 过渡总刻数 */
		public int total;

		/** 实际宽度倍率 */
		public float w() {
			return clamp(base * width);
		}

		/** 实际高度倍率 */
		public float h() {
			return clamp(base * height);
		}

		/** 与"没缩放过"是否等价 */
		public boolean vanilla() {
			return Math.abs(w() - 1.0F) < 1.0E-4F && Math.abs(h() - 1.0F) < 1.0E-4F;
		}

		/** 这一刻是否还在长大/缩小 */
		public boolean moving() {
			return left > 0 && Math.abs(base - target) > 1.0E-5F;
		}
	}

	/** 倍率钳制(填 0 / 负数 / NaN 都按 1 处理) */
	public static float clamp(float v) {
		if (Float.isNaN(v) || v <= 0.0F)
			return 1.0F;
		return v < MIN ? MIN : (v > MAX ? MAX : v);
	}

	/** 线性插值 */
	public static float lerp(float a, float b, float t) {
		return a + (b - a) * t;
	}

	/** 缓入缓出(与重力过渡同一套 smoothstep) */
	public static float ease(float t) {
		if (t <= 0.0F)
			return 0.0F;
		if (t >= 1.0F)
			return 1.0F;
		return t * t * (3.0F - 2.0F * t);
	}

	/** 按模式把 v 叠到当前值上: set / add / subtract / multiply / divide */
	public static float op(float cur, String mode, float v) {
		String m = mode == null ? "set" : mode.trim().toLowerCase(java.util.Locale.ROOT);
		if ("add".equals(m))
			return cur + v;
		if ("subtract".equals(m))
			return cur - v;
		if ("multiply".equals(m))
			return cur * v;
		if ("divide".equals(m))
			return Math.abs(v) < 1.0E-6F ? cur : cur / v;
		return v;
	}
}
