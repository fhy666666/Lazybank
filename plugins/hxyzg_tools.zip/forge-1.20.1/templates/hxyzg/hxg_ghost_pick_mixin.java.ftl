package ${package}.mixin;

/*
 * 「虚影视角」的准星 / 挖掘 / 攻击原点 —— 方块拾取那一段(客户端).
 *
 * 现象: 开了虚影视角以后画面是从虚影位置看出去的, 但准星选中的方块还是从**本体眼睛**射出去的 ——
 * 从虚影那边看到的东西打不到、挖不到, 而且选中框会跟画面错开一截.
 *
 * 原版这两条射线都是 Entity.pick(...) 从 this.getEyePosition(...) 出发的(它是个 final 方法, 不能覆盖),
 * 所以只能在**调用点**上换掉那一次取眼睛: 只改 pick(DFZ) 里的那一处, 别处(雾、音源、入水判定、
 * 弹射物起点...)全都还是本体眼睛 —— 那些地方挪了会出真问题, 这里一个都不碰.
 *
 * 距离不改: 拾取长度仍是「本体的方块/实体触及距离」那一套属性值(缩放工具类放大过的就是放大后的值),
 * 所以虚影"继承"的就是本体被放大后的距离; 关掉虚影视角时这个 mixin 立刻什么都不做(eyeFor 返回 false).
 */

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import ${package}.ghost.HxgGhostView;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

@Mixin(Entity.class)
public abstract class HxgGhostPickMixin {
	private static final double[] _HX_PICK_EYE = new double[3];

	@Redirect(method = "pick(DFZ)Lnet/minecraft/world/phys/HitResult;", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;getEyePosition(F)Lnet/minecraft/world/phys/Vec3;"))
	private Vec3 hxg$ghostPickEye(Entity _self, float _partial) {
		if (HxgGhostView.eyeFor(_self, _HX_PICK_EYE))
			return new Vec3(_HX_PICK_EYE[0], _HX_PICK_EYE[1], _HX_PICK_EYE[2]);
		return _self.getEyePosition(_partial);
	}
}
