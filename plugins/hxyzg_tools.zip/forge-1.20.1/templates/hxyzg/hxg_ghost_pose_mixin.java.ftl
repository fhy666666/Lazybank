package ${package}.mixin;

/*
 * 「虚影」部位冻结的注入点(客户端).
 *
 * 为什么在这里: 虚影是把本体再用同一个渲染器画一遍, 部位旋转是 LivingEntityRenderer.render 里
 * this.model.setupAnim(...) 那一下算出来的 —— 想"算完姿势、还没画"之间改部位, 只有这一个缝.
 * 加在 setupAnim 之后(shift = AFTER): 晚一步就被画进缓冲了, 早一步会被 setupAnim 覆盖掉.
 *
 * 只在工具类的 begin/end 之间(也就是画虚影的那一下)真正生效, 本体自己的渲染完全不受影响;
 * 没有建 GhostUtils 流程时 HxgGhostPose 里 _rendering 永远是 null, 这里等于一次空检查.
 * 两分支逐字节相同: 宿主方法与原方法都有映射(forge 走 refmap, neo 本来就在 named 上跑).
 */

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.mojang.blaze3d.vertex.PoseStack;

import ${package}.ghost.HxgGhostPose;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.world.entity.LivingEntity;

@Mixin(LivingEntityRenderer.class)
public abstract class HxgGhostPoseMixin {
	@Inject(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/EntityModel;setupAnim(Lnet/minecraft/world/entity/Entity;FFFFF)V", shift = At.Shift.AFTER))
	private void hxg$ghostFreeze(LivingEntity _entity, float _yaw, float _partial, PoseStack _pose, MultiBufferSource _buffers, int _light,
			CallbackInfo _ci) {
		try {
			HxgGhostPose.apply(((LivingEntityRenderer<?, ?>) (Object) this).getModel(), _entity.isCrouching());
		} catch (Throwable _t) {
			// 画虚影不能因为这里出错就崩
		}
	}
}
