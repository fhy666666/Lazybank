if (world.isClientSide()) {
    LightBeamUtilsProcedure.rotate(${input$id}, ${input$rotate}, LightBeamUtilsProcedure.spinOf("${(field$spin!"NONE")?upper_case}"));
}
RegPacketProcedure.hxSend(world, "lightbeam.rotate", ${input$id}, ${input$rotate}, LightBeamUtilsProcedure.spinOf("${(field$spin!"NONE")?upper_case}"));
