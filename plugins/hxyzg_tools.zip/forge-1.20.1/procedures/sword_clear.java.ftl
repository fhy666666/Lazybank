SwordUtilsProcedure.clear();
