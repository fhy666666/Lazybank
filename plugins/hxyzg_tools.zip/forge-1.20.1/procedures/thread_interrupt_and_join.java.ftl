${input$thread}.interrupt();
try {
	${input$thread}.join((long) ${input$time});
} catch (InterruptedException _ie) {
	Thread.currentThread().interrupt();
}