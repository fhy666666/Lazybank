BlueprintUtilsProcedure.copy(world, ${input$name}, ${input$x1}, ${input$y1}, ${input$z1}, ${input$x2}, ${input$y2}, ${input$z2}, <#if field$entities == "TRUE">true<#else>false</#if>);
