<#if field$type=="Double">
${field$tagID}.putDouble(${input$tagName}, ${input$tagValue});
<#elseif field$type=="Float">
${field$tagID}.putFloat(${input$tagName}, (float) ${input$tagValue});
<#elseif field$type=="Integer">
${field$tagID}.putInt(${input$tagName}, (int) ${input$tagValue});
<#elseif field$type=="Short">
${field$tagID}.putShort(${input$tagName}, (short) ${input$tagValue});
<#elseif field$type=="Long">
${field$tagID}.putLong(${input$tagName}, (long) ${input$tagValue});
<#else>
${field$tagID}.putByte(${input$tagName}, (byte) ${input$tagValue});
</#if>
