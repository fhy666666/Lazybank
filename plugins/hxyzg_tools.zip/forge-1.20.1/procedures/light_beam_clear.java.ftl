if (world.isClientSide()) {
    LightBeamUtilsProcedure.clear();
}
RegPacketProcedure.hxSend(world, "lightbeam.clear");
