<#if field$type=="int">
(new java.util.Random()).nextInt(${opt.toInt(input$num1)} - ${opt.toInt(input$num2)} + 1) + ${opt.toInt(input$num2)}
<#elseif field$type=="long">
(new java.util.Random()).nextLong(${opt.toLong(input$num1)} - ${opt.toLong(input$num2)} + 1) + ${opt.toLong(input$num2)}
<#elseif field$type=="short">
(short) ((new java.util.Random()).nextInt(${opt.toInt(input$num1)} - ${opt.toInt(input$num2)} + 1) + ${opt.toInt(input$num2)})
<#elseif field$type=="byte">
(byte) ((new java.util.Random()).nextInt(${opt.toInt(input$num1)} - ${opt.toInt(input$num2)} + 1) + ${opt.toInt(input$num2)})
<#elseif field$type=="float">
(${input$num2} + (${input$num1} - ${input$num2}) * (new java.util.Random()).nextFloat())
<#else>
(${input$num2} + (${input$num1} - ${input$num2}) * (new java.util.Random()).nextDouble())
</#if>
