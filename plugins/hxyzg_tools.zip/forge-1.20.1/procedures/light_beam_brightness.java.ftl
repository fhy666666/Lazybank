if (world.isClientSide()) {
    LightBeamUtilsProcedure.brightness(${input$id}, ${input$brightness});
}
RegPacketProcedure.hxSend(world, "lightbeam.brightness", ${input$id}, ${input$brightness});
