if (world.isClientSide()) {
    LightBeamUtilsProcedure.clearId(${input$id});
}
RegPacketProcedure.hxSend(world, "lightbeam.clearid", ${input$id});
