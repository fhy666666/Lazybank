if (world.isClientSide()) {
    AfterimageUtilsProcedure.start(${input$entity}, ${opt.toInt(input$width)}, ${input$spacing}, ${opt.toInt(input$duration)});
}
RegPacketProcedure.hxSend(world, "afterimage.start", ${input$entity}, ${opt.toInt(input$width)}, ${input$spacing}, ${opt.toInt(input$duration)});
