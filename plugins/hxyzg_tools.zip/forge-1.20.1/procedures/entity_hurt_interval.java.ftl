${input$entity}.invulnerableTime = (int)${input$tagValue};
