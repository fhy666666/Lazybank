<#include "mcitems.ftl">
<#assign _hxName = "hxyzg_attr_" + field$attribute?lower_case + "_" + field$slots?lower_case>
{
	net.minecraft.world.item.ItemStack _stack = ${mappedMCItemToItemStackCode(input$item, 1)};
	net.minecraft.nbt.ListTag _mods = _stack.getOrCreateTag().getList("AttributeModifiers", 10);
	for (int _i = _mods.size() - 1; _i >= 0; _i--)
		if ("${_hxName}".equals(_mods.getCompound(_i).getString("Name")))
			_mods.remove(_i);
	_stack.addAttributeModifier(${generator.map(field$attribute, "attributes")}, new AttributeModifier(java.util.UUID.nameUUIDFromBytes("${modid}:${_hxName}".getBytes(java.nio.charset.StandardCharsets.UTF_8)), "${_hxName}", ${input$tagValue}, AttributeModifier.Operation.ADDITION), EquipmentSlot.${generator.map(field$slots, "slots")});
}