if (world.isClientSide()) {
	GhostUtilsProcedure.setSizeAxis(${input$entity}, ${input$width}, ${input$height});
}
RegPacketProcedure.hxSend(world, "ghost.axis", ${input$entity}, ${input$width}, ${input$height});
