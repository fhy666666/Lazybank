<#include "mcelements.ftl">
BuildUtilsProcedure.member(${input$structure}, ${input$weight}, ${input$ox}, ${input$oy}, ${input$oz}, ${field$rotation});