if (event instanceof RenderGuiOverlayEvent.Pre _event) {
	String OverlayIdTemp = _event.getOverlay().id().toString();
	${statement$do}
}
