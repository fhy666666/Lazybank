if (world.isClientSide()) {
	GhostUtilsProcedure.stop(${input$entity});
}
RegPacketProcedure.hxSend(world, "ghost.stop", ${input$entity});
