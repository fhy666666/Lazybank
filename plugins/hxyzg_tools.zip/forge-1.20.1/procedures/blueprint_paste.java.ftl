BlueprintUtilsProcedure.paste(world, ${input$name}, ${input$x}, ${input$y}, ${input$z}, ${field$rotation}, ${field$mirror}, <#if field$entities == "TRUE">true<#else>false</#if>);
