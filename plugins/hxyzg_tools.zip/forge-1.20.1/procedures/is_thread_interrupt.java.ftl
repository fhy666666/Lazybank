${input$thread}.isInterrupted()
