if (${input$entity} instanceof ServerPlayer _splayer && ${input$_placeholder} instanceof ServerPlayer _target && !_splayer.level().isClientSide()) {
	net.minecraft.nbt.CompoundTag nbtTemp = _splayer.getPersistentData();
	RegPacketProcedure.sendToPlayer(_target, nbtTemp);
}
