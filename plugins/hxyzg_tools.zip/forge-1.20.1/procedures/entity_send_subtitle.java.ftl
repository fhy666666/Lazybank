if (${input$entity} instanceof ServerPlayer _player) {
	_player.connection.send(new ClientboundSetSubtitleTextPacket(net.minecraft.network.chat.Component.literal(${input$text})));
}
