if (world.isClientSide()) {
    CameraUtilsProcedure.fade(${opt.toInt(input$color)}, ${opt.toInt(input$ticks)});
}
RegPacketProcedure.hxSend(world, "camera.fade", ${opt.toInt(input$color)}, ${opt.toInt(input$ticks)});
