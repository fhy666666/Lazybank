CooldownUtilsProcedure.clear(${input$entity}, ${input$key});
