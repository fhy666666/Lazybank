<#include "mcelements.ftl">
BuildUtilsProcedure.big(world, ${toResourceLocation(input$structure)}, ${input$x}, ${input$y}, ${input$z}, ${field$rotation}, ${field$mirror}, ${input$ms});