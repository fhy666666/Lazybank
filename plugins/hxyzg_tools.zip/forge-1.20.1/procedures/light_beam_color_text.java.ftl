if (world.isClientSide()) {
    LightBeamUtilsProcedure.color(${input$id}, ${input$color_text});
}
RegPacketProcedure.hxSend(world, "lightbeam.color", ${input$id}, ${input$color_text});
