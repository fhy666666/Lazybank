if (${input$entity} instanceof ServerPlayer _splayer && !_splayer.level().isClientSide()) {
	net.minecraft.nbt.CompoundTag nbtTemp = _splayer.getPersistentData();
	RegPacketProcedure.sendToNearby(_splayer.level(), _splayer.getX(), _splayer.getY(), _splayer.getZ(), ${input$tagValue}, nbtTemp);
}
