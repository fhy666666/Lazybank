(TrailUtilsProcedure.isActive(${input$entity}))
