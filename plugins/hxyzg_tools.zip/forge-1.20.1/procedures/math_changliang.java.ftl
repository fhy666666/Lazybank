<#if field$type=="TAU">(Math.PI * 2)<#else>Math.${field$type}</#if>
