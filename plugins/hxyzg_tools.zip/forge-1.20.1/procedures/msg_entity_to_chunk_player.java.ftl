if (${input$entity} instanceof ServerPlayer _splayer && !_splayer.level().isClientSide()) {
	net.minecraft.nbt.CompoundTag nbtTemp = _splayer.getPersistentData();
	RegPacketProcedure.sendToTrackingChunk(_splayer.level().getChunkAt(_splayer.blockPosition()), nbtTemp);
}
