if (world.isClientSide()) {
    LightBeamUtilsProcedure.alpha(${input$id}, ${input$alpha});
}
RegPacketProcedure.hxSend(world, "lightbeam.alpha", ${input$id}, ${input$alpha});
