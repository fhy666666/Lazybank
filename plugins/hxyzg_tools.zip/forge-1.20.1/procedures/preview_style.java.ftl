if (world.isClientSide()) {
    PreviewUtilsProcedure.setStyle(${opt.toInt(input$alpha)}, <#if field$shell == "TRUE">true<#else>false</#if>);
}
RegPacketProcedure.hxSend(world, "preview.style", ${opt.toInt(input$alpha)}, <#if field$shell == "TRUE">true<#else>false</#if>);
