(CooldownUtilsProcedure.isOn(${input$entity}, ${input$key}))
