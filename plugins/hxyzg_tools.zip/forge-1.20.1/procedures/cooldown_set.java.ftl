CooldownUtilsProcedure.set(${input$entity}, ${input$key}, ${opt.toInt(input$ticks)});
