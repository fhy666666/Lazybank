${field$tagID}.putString(${input$tagName}, ${input$tagValue});
