if (world.isClientSide()) {
    DecalUtilsProcedure.show(${input$x}, ${input$y}, ${input$z}, "${field$face}", ${input$texture}, ${input$size}, ${input$rot}, ${opt.toInt(input$ticks)});
}
RegPacketProcedure.hxSend(world, "decal.show", ${input$x}, ${input$y}, ${input$z}, "${field$face}", ${input$texture}, ${input$size}, ${input$rot}, ${opt.toInt(input$ticks)});
