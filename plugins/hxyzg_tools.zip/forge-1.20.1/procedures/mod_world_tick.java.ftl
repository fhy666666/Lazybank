((world.getDayTime() % (long) ${input$num1}) == (long) ${input$num2})
