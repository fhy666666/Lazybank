<#if field$type=="double">
${input$entity}.getPersistentData().getDouble(${input$tagName})
<#elseif field$type=="float">
${input$entity}.getPersistentData().getFloat(${input$tagName})
<#elseif field$type=="long">
${input$entity}.getPersistentData().getLong(${input$tagName})
<#elseif field$type=="short">
${input$entity}.getPersistentData().getShort(${input$tagName})
<#elseif field$type=="byte">
${input$entity}.getPersistentData().getByte(${input$tagName})
<#else>
${input$entity}.getPersistentData().getInt(${input$tagName})
</#if>