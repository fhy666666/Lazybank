<#include "mcelements.ftl">
<#-- @formatter:off -->
if(${input$entity} instanceof ServerPlayer _ent) {
	NetworkHooks.openScreen((ServerPlayer) _ent, new MenuProvider() {
		@Override public Component getDisplayName() {
			return Component.literal("${field$guiname}");
		}
		@Override public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
			FriendlyByteBuf packetBuffer = new FriendlyByteBuf(Unpooled.buffer());
			packetBuffer.writeBlockPos(${input$entity}.blockPosition());
			packetBuffer.writeByte(0);
			packetBuffer.writeVarInt(${input$getid}.getId());
			return new ${(field$guiname)}Menu(id, inventory, packetBuffer);
		}
	}, buf -> {
			buf.writeBlockPos(${input$entity}.blockPosition());
			buf.writeByte(0);
			buf.writeVarInt(${input$getid}.getId());
		});
}
<#-- @formatter:on -->