<#include "mcitems.ftl">
ShapeUtilsProcedure.fillSphere(world, ${input$x}, ${input$y}, ${input$z}, ${input$radius}, ${mappedBlockToBlockStateCode(input$block)});
