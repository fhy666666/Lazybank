if (${input$entity} instanceof ServerPlayer _player) {
	_player.connection.send(new ClientboundClearTitlesPacket(true));
}
