ScaleUtilsProcedure.axis(${input$entity}, ${input$width}, ${input$height});
