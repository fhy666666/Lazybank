if (Minecraft.getInstance() != null) {
	Minecraft.getInstance().execute(() -> {
${statement$do}
	});
}