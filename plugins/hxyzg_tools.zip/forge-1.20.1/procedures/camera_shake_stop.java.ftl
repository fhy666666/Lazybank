if (world.isClientSide()) {
    CameraUtilsProcedure.shakeStop();
}
RegPacketProcedure.hxSend(world, "camera.shakeStop");
