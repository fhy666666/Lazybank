(${field$tagID}.contains(${input$tagName}) ? ${field$tagID}.getBoolean(${input$tagName}) : false)
