(BlueprintUtilsProcedure.sizeY(${input$name}))
