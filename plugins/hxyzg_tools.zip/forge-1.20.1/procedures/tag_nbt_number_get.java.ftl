<#if field$type=="Double">
(${field$tagID}.contains(${input$tagName}) ? ${field$tagID}.getDouble(${input$tagName}) : 0)
<#elseif field$type=="Float">
(${field$tagID}.contains(${input$tagName}) ? ${field$tagID}.getFloat(${input$tagName}) : 0)
<#elseif field$type=="Integer">
(${field$tagID}.contains(${input$tagName}) ? ${field$tagID}.getInt(${input$tagName}) : 0)
<#elseif field$type=="Short">
(${field$tagID}.contains(${input$tagName}) ? ${field$tagID}.getShort(${input$tagName}) : 0)
<#elseif field$type=="Long">
(${field$tagID}.contains(${input$tagName}) ? ${field$tagID}.getLong(${input$tagName}) : 0)
<#else>
(${field$tagID}.contains(${input$tagName}) ? ${field$tagID}.getByte(${input$tagName}) : 0)
</#if>
