(world instanceof ServerLevel ? ((ServerLevel) world).getSeed() : 0L)
