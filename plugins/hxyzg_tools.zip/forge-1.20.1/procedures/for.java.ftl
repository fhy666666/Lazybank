for (${field$type_0} ${field$local_variable_name} = ${input$content}; ${field$local_variable_name} ${field$type_1} ${input$number}; ${field$local_variable_name}${field$type_2}) {
${statement$do}
}