if (${input$entitycheck} instanceof LivingEntity _entity)
				_entity.heal((float) ${input$amount});
