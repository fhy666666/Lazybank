(new Object() {
	public String getString() {
		String[] _parts = (${input$string}).split(java.util.regex.Pattern.quote(${input$string2}));
		return _parts.length > ${opt.toInt(input$index)} && ${opt.toInt(input$index)} >= 0 ? _parts[${opt.toInt(input$index)}] : "";
	}
}.getString())
