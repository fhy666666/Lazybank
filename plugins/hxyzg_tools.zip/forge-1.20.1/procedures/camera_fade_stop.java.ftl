if (world.isClientSide()) {
    CameraUtilsProcedure.fadeStop();
}
RegPacketProcedure.hxSend(world, "camera.fadeStop");
