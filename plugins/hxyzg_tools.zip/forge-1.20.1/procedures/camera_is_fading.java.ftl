(CameraUtilsProcedure.isFading())
