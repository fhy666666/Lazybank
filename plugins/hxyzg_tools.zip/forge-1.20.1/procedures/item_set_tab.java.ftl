<#include "mcitems.ftl">
_event.accept(${mappedMCItemToItemStackCode(input$item, 1)});