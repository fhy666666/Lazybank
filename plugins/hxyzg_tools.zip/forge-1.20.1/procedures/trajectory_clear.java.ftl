TrajectoryUtilsProcedure.clear();
