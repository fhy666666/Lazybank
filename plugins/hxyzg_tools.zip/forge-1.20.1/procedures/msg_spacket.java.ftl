RegPacketProcedure.CHANNELB.sendToServer(new RegPacketProcedure.RegPacketCommB(${input$tagValue}));
