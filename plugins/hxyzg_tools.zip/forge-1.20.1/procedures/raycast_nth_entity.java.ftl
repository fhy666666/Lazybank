(RayCastUtilsProcedure.nthEntity(${input$entity}, ${input$range}, ${opt.toInt(input$index)}, <#if field$ignoreliquid == "TRUE">true<#else>false</#if>))
