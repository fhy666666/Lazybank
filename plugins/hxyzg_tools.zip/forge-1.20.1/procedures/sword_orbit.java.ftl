<#include "mcitems.ftl">
SwordUtilsProcedure.orbit(world, ${input$entity}, ${opt.toInt(input$count)}, ${opt.toInt(input$ticks)}, ${input$radius}, ${input$yOffset}, ${input$speed}, ${mappedMCItemToItemStackCode(input$item, 1)}, ${field$form?number}, ${field$float?number});
RegPacketProcedure.hxSend(world, "sword.orbit", world, ${input$entity}, ${opt.toInt(input$count)}, ${opt.toInt(input$ticks)}, ${input$radius}, ${input$yOffset}, ${input$speed}, ${mappedMCItemToItemStackCode(input$item, 1)}, ${field$form?number}, ${field$float?number});
