(RayCastUtilsProcedure.spread(${input$entity}, ${input$range}, ${input$spread}, <#if field$ignoreblocks == "TRUE">true<#else>false</#if>, <#if field$ignoreliquid == "TRUE">true<#else>false</#if>))
