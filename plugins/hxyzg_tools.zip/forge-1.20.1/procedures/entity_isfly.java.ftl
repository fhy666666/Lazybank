(${input$entity} instanceof Player _pl ? _pl.getAbilities().mayfly : false)
