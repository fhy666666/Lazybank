<#if field$type=="double">
${input$entity}.getPersistentData().putDouble(${input$tagName}, ${input$tagValue});
<#elseif field$type=="float">
${input$entity}.getPersistentData().putFloat(${input$tagName}, ${input$tagValue});
<#elseif field$type=="long">
${input$entity}.getPersistentData().putLong(${input$tagName}, ${input$tagValue});
<#elseif field$type=="short">
${input$entity}.getPersistentData().putShort(${input$tagName}, ${input$tagValue});
<#elseif field$type=="byte">
${input$entity}.getPersistentData().putByte(${input$tagName}, ${input$tagValue});
<#else>
${input$entity}.getPersistentData().putInt(${input$tagName}, ${input$tagValue});
</#if>