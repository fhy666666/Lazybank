{
	net.minecraft.world.entity.Entity _ent = ${input$entity};
	_ent.teleportTo(${input$x}, ${input$y}, ${input$z});
}
