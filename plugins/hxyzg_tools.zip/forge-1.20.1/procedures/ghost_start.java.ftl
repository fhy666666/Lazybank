if (world.isClientSide()) {
	GhostUtilsProcedure.start(${input$entity}, "${field$place}", ${input$size}, ${input$alpha}, ${input$distance}, (int) (${input$life}));
}
RegPacketProcedure.hxSend(world, "ghost.start", ${input$entity}, "${field$place}", ${input$size}, ${input$alpha}, ${input$distance}, (int) (${input$life}));
