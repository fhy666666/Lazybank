Minecraft.getInstance().options.${generator.map(field$keym, "keym")}.setDown(false);
