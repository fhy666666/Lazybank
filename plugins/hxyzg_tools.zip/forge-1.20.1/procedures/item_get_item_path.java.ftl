<#include "mcitems.ftl">
(new Object() {
    public String getString() {
        if (FMLEnvironment.dist != Dist.CLIENT) return "Server side - cannot get texture";
        
        ItemStack stack = ${mappedMCItemToItemStackCode(input$item, 1)};
        if (stack.isEmpty()) return "No item in hand";
        
        ResourceLocation itemId = ForgeRegistries.ITEMS.getKey(stack.getItem());
        if (itemId != null) {
            return new ResourceLocation(itemId.getNamespace(), 
                "textures/item/" + itemId.getPath() + ".png").toString();
        }
        
        return "Unknown texture";
    }
}.getString())