(${field$tagID}.contains(${input$tagName}) ? ${field$tagID}.getString(${input$tagName}) : "")
