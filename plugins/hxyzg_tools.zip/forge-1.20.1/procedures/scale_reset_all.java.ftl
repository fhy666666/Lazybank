ScaleUtilsProcedure.resetAll();
