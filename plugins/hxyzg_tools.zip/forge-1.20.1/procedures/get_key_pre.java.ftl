if (event instanceof InputEvent.Key _event) {
	${statement$do}
}
