ShapeUtilsProcedure.breakSphere(world, ${input$x}, ${input$y}, ${input$z}, ${input$radius}, <#if field$drop == "TRUE">true<#else>false</#if>);
