if (world.isClientSide()) {
    FakeTerrainUtilsProcedure.crack(world, ${input$x}, ${input$y}, ${input$z}, ${input$radius}, ${opt.toInt(input$ticks)}, ${input$angle}, <#if field$hide == "TRUE">true<#else>false</#if>, ${field$profile?number}, ${input$offset_y!0});
}
RegPacketProcedure.hxSend(world, "terrain.crack", world, ${input$x}, ${input$y}, ${input$z}, ${input$radius}, ${opt.toInt(input$ticks)}, ${input$angle}, <#if field$hide == "TRUE">true<#else>false</#if>, ${field$profile?number}, ${input$offset_y!0});
