if (event instanceof BuildCreativeModeTabContentsEvent _event) {
	${statement$do}
}
