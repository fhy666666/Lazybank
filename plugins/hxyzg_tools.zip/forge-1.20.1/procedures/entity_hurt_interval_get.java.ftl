${input$entity}.invulnerableTime
