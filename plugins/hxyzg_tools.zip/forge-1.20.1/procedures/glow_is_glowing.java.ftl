(GlowUtilsProcedure.isGlowing(${input$entity}))
