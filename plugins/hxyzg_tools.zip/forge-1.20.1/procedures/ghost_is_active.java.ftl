(GhostUtilsProcedure.isActive(${input$entity}))
