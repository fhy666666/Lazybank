new Thread(() -> {
${statement$do}
}<#if field$name?has_content>, "${field$name}"</#if>).start();