if (${input$entity} instanceof ServerPlayer _splayer && !_splayer.level().isClientSide()) {
	net.minecraft.nbt.CompoundTag nbtTemp = _splayer.getPersistentData();
	nbtTemp.putDouble("Attack", _splayer.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE).getBaseValue());
	RegPacketProcedure.sendToPlayer(_splayer, nbtTemp);
}
