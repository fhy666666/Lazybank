if (world.isClientSide()) {
    LightBeamUtilsProcedure.texture(${input$id}, ${input$texture}, ${((field$tile!"STRETCH")?upper_case == "TILE")?c});
}
RegPacketProcedure.hxSend(world, "lightbeam.texture", ${input$id}, ${input$texture}, ${((field$tile!"STRETCH")?upper_case == "TILE")?c});
