if (world.isClientSide()) {
	GhostUtilsProcedure.setView(${input$entity}, "${field$mode}".equals("on"));
}
RegPacketProcedure.hxSend(world, "ghost.view", ${input$entity}, ("${field$mode}".equals("on") ? 1 : 0));
