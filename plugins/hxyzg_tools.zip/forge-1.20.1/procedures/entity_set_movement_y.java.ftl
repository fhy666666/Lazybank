{
	net.minecraft.world.entity.Entity _ent = ${input$entity};
	_ent.setDeltaMovement(new net.minecraft.world.phys.Vec3(_ent.getDeltaMovement().x, ${input$vy}, _ent.getDeltaMovement().z));
}
