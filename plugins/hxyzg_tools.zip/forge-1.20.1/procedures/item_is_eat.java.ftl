<#include "mcitems.ftl">
((${mappedMCItemToItemStackCode(input$item, 1)}).getUseAnimation() == net.minecraft.world.item.UseAnim.EAT)
