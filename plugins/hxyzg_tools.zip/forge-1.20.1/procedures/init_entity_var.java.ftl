net.minecraft.world.entity.Entity ${field$local_variable_name} = ${input$entity};
