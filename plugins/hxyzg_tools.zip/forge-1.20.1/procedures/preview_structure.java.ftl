<#include "mcelements.ftl">
if (world.isClientSide()) {
    PreviewUtilsProcedure.show(${toResourceLocation(input$structure)}, ${input$x}, ${input$y}, ${input$z}, ${field$rotation}, ${field$mirror});
}
RegPacketProcedure.hxSend(world, "preview.show", ${toResourceLocation(input$structure)}, ${input$x}, ${input$y}, ${input$z}, ${field$rotation}, ${field$mirror});
