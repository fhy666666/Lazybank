if (world.isClientSide()) {
	GhostUtilsProcedure.setPlace(${input$entity}, "${field$place}", ${input$distance});
}
RegPacketProcedure.hxSend(world, "ghost.place", ${input$entity}, "${field$place}", ${input$distance});
