if (world.isClientSide()) {
    TrailUtilsProcedure.stop(${input$entity});
}
RegPacketProcedure.hxSend(world, "trail.stop", ${input$entity});
