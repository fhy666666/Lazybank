<#include "mcelements.ftl">
if (world instanceof ServerLevel _level) {
	Entity entityToSpawn = ${input$entitycheck}.spawn(_level, ${toBlockPos(input$x,input$y,input$z)}, MobSpawnType.MOB_SUMMONED);
	if (entityToSpawn != null) {
		entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
	}
}