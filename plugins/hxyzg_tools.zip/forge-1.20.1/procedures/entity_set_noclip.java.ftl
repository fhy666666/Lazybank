${input$entity}.noClip = ${input$gravityValue};
