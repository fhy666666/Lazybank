(AfterimageUtilsProcedure.isActive(${input$entity}))
