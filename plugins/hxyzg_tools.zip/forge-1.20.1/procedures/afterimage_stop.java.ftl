if (world.isClientSide()) {
    AfterimageUtilsProcedure.stop(${input$entity});
}
RegPacketProcedure.hxSend(world, "afterimage.stop", ${input$entity});
