(${input$entity} instanceof Player _pl ? _pl.getAbilities().flying : false)
