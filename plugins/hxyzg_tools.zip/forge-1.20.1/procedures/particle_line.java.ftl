ParticleShapesProcedure.line(world, ${input$x1}, ${input$y1}, ${input$z1}, ${input$x2}, ${input$y2}, ${input$z2}, ${generator.map(field$particle, "particles")}, ${opt.toInt(input$count)});
