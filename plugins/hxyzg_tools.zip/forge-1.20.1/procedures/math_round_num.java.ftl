(new java.math.BigDecimal(${input$tagValue}).setScale(${opt.toInt(input$two)}, java.math.RoundingMode.HALF_UP).doubleValue())
