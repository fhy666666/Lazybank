(event instanceof RenderHandEvent && ((RenderHandEvent) event).getHand() == InteractionHand.${field$hand})
