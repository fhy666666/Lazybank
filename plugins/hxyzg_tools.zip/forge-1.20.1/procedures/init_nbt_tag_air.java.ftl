net.minecraft.nbt.CompoundTag ${field$tagID} = new net.minecraft.nbt.CompoundTag();
