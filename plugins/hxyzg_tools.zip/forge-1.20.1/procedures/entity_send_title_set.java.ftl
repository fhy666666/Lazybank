if (${input$entity} instanceof ServerPlayer _player) {
	_player.connection.send(new ClientboundSetTitlesAnimationPacket(${opt.toInt(input$numa)}, ${opt.toInt(input$numb)}, ${opt.toInt(input$numc)}));
}
