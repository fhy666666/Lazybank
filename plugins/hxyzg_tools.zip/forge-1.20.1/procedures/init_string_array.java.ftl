String ${field$array_name}Tmp = ${input$content};
String[] ${field$array_name} = ${field$array_name}Tmp.split(",");