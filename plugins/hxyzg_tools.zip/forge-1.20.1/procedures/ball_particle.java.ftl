BallParticleProcedure.BallParticle(${input$entity}.level(), new Vec3(${input$x}, ${input$y}, ${input$z}), ${input$NumA}, ${generator.map(field$particle, "particles")}, (int)${input$NumB});
