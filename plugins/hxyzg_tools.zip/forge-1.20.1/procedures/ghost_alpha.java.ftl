if (world.isClientSide()) {
	GhostUtilsProcedure.setAlpha(${input$entity}, ${input$alpha});
}
RegPacketProcedure.hxSend(world, "ghost.alpha", ${input$entity}, ${input$alpha});
