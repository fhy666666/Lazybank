if (world.isClientSide()) {
    FakeTerrainUtilsProcedure.smash(world, ${input$x1}, ${input$y1}, ${input$z1}, ${input$x2}, ${input$y2}, ${input$z2}, ${input$width}, ${opt.toInt(input$ticks)}, ${input$angle}, ${field$shape?number}, <#if field$hide == "TRUE">true<#else>false</#if>, ${input$offset_y!0});
}
RegPacketProcedure.hxSend(world, "terrain.smash", world, ${input$x1}, ${input$y1}, ${input$z1}, ${input$x2}, ${input$y2}, ${input$z2}, ${input$width}, ${opt.toInt(input$ticks)}, ${input$angle}, ${field$shape?number}, <#if field$hide == "TRUE">true<#else>false</#if>, ${input$offset_y!0});
