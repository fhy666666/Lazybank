<#include "mcelements.ftl">
<#assign entity = generator.map(field$entity, "entities", 1)!"null">
<#if entity != "null">
if (world instanceof ServerLevel _level) {
	net.minecraft.world.entity.Entity entityToSpawn = ${entity}.spawn(_level, ${toBlockPos(input$x,input$y,input$z)}, net.minecraft.world.entity.MobSpawnType.MOB_SUMMONED);
	if (entityToSpawn != null) {
		entityToSpawn.setCustomName(net.minecraft.network.chat.Component.literal(${input$name}));
		entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
	}
}
</#if>
