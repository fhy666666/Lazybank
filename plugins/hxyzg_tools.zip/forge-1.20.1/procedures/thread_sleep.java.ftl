try {
	${input$thread}.sleep((long) ${input$time});
} catch (InterruptedException _ie) {
	Thread.currentThread().interrupt();
}