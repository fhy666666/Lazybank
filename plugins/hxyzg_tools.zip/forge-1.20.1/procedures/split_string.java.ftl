String[] ${field$array_name} = (${input$text}).split(java.util.regex.Pattern.quote(${input$character_string}));
