(Minecraft.getInstance().screen instanceof ${field$type})
