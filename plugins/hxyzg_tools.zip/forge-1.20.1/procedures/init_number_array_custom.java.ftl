String ${field$array_name}TextTmp = ${input$content};
String[] ${field$array_name}Array = ${field$array_name}TextTmp.split(${input$separate});
${field$type}[] ${field$array_name} = new ${field$type}[${field$array_name}Array.length];
for (int i = 0; i < ${field$array_name}Array.length; i++) {
    <#if field$type=="double">
    ${field$array_name}[i] = Double.parseDouble(${field$array_name}Array[i]);
    <#elseif field$type=="float">
    ${field$array_name}[i] = Float.parseFloat(${field$array_name}Array[i]);
    <#elseif field$type=="long">
    ${field$array_name}[i] = Long.parseLong(${field$array_name}Array[i]);
    <#elseif field$type=="short">
    ${field$array_name}[i] = Short.parseShort(${field$array_name}Array[i]);
    <#elseif field$type=="byte">
    ${field$array_name}[i] = Byte.parseByte(${field$array_name}Array[i]);
    <#else>
    ${field$array_name}[i] = Integer.parseInt(${field$array_name}Array[i]);
    </#if>
}