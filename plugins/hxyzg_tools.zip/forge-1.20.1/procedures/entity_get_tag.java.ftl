(${input$entity}.getCustomName() != null ? ${input$entity}.getCustomName().getString() : "")
