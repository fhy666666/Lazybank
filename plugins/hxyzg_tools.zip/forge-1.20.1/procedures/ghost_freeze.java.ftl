if (world.isClientSide()) {
	GhostUtilsProcedure.setFreeze(${input$entity}, GhostUtilsProcedure.freezeMask(${((field$head!"FALSE")?lower_case == "true")?c}, ${((field$arms!"FALSE")?lower_case == "true")?c}, ${((field$legs!"FALSE")?lower_case == "true")?c}, ${((field$sneak!"FALSE")?lower_case == "true")?c}));
}
RegPacketProcedure.hxSend(world, "ghost.freeze", ${input$entity}, GhostUtilsProcedure.freezeMask(${((field$head!"FALSE")?lower_case == "true")?c}, ${((field$arms!"FALSE")?lower_case == "true")?c}, ${((field$legs!"FALSE")?lower_case == "true")?c}, ${((field$sneak!"FALSE")?lower_case == "true")?c}));
