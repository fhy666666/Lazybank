if (event instanceof RenderHandEvent _event) {
	InteractionHand HandTemp = _event.getHand();
	${statement$do}
}
