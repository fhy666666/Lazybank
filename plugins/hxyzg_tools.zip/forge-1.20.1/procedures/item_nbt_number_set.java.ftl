<#include "mcitems.ftl">
{
	net.minecraft.world.item.ItemStack _stack = ${mappedMCItemToItemStackCode(input$item, 1)};
	net.minecraft.nbt.CompoundTag _nbt = _stack.getOrCreateTag();
	<#if field$type=="Double">
	_nbt.putDouble(${input$tagName}, ${input$tagValue});
	<#elseif field$type=="Float">
	_nbt.putFloat(${input$tagName}, (float) ${input$tagValue});
	<#elseif field$type=="Int">
	_nbt.putInt(${input$tagName}, (int) ${input$tagValue});
	<#elseif field$type=="Long">
	_nbt.putLong(${input$tagName}, (long) ${input$tagValue});
	<#elseif field$type=="Short">
	_nbt.putShort(${input$tagName}, (short) ${input$tagValue});
	<#else>
	_nbt.putByte(${input$tagName}, (byte) ${input$tagValue});
	</#if>
}
