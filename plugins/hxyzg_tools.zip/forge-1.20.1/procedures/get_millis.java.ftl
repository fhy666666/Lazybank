java.util.Calendar.getInstance().getTimeInMillis()
