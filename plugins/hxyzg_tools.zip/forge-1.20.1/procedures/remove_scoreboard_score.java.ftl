if (world instanceof ServerLevel _level) {
	Scoreboard _sc = _level.getScoreboard();
	Objective _so = _sc.getObjective(${input$score});
	if (_so != null)
	_sc.removeObjective(_so);
}
