ScaleUtilsProcedure.reset(${input$entity}, (int) (${input$ticks}));
