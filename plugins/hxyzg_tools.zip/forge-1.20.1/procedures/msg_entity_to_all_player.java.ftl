if (${input$entity} instanceof ServerPlayer _splayer && !_splayer.level().isClientSide()) {
	net.minecraft.nbt.CompoundTag nbtTemp = _splayer.getPersistentData();
	RegPacketProcedure.sendToTracking(_splayer, nbtTemp);
}
