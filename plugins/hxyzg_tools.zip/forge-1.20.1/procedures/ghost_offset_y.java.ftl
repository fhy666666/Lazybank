if (world.isClientSide()) {
	GhostUtilsProcedure.setOffsetY(${input$entity}, ${input$offset});
}
RegPacketProcedure.hxSend(world, "ghost.offset", ${input$entity}, ${input$offset});
