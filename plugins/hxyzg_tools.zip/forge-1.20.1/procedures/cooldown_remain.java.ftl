(CooldownUtilsProcedure.remain(${input$entity}, ${input$key}))
