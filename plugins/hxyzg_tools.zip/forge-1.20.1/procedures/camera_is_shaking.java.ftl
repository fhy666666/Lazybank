(CameraUtilsProcedure.isShaking())
