net.minecraft.nbt.CompoundTag ${field$tagID} = ${input$entity}.getPersistentData().getCompound("${field$tagText}");
