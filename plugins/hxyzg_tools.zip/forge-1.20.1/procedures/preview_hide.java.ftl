if (world.isClientSide()) {
    PreviewUtilsProcedure.hide();
}
RegPacketProcedure.hxSend(world, "preview.hide");
