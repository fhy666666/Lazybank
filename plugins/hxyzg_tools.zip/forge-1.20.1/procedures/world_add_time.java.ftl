if (world instanceof ServerLevel) {
	ServerLevel serverWorld = (ServerLevel) world;
	long currentTime = serverWorld.getDayTime();
	serverWorld.setDayTime(currentTime + ((int) ${input$time}));
}