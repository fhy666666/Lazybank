if (world.isClientSide()) {
    CameraUtilsProcedure.shake(${opt.toInt(input$ticks)}, ${input$strength});
}
RegPacketProcedure.hxSend(world, "camera.shake", ${opt.toInt(input$ticks)}, ${input$strength});
