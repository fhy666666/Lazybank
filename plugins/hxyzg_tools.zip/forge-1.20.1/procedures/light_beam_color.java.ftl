if (world.isClientSide()) {
    LightBeamUtilsProcedure.color(${input$id}, "${field$color!"#ffffff"}");
}
RegPacketProcedure.hxSend(world, "lightbeam.color", ${input$id}, "${field$color!"#ffffff"}");
