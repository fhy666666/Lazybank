if (event instanceof LivingDamageEvent _event) {
	_event.setAmount((float)${input$tagValue});
}
