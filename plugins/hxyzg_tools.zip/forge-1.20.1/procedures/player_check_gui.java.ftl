(${input$entitycheck} instanceof Player && ((Player) ${input$entitycheck}).containerMenu instanceof ${field$guiname}Menu)
