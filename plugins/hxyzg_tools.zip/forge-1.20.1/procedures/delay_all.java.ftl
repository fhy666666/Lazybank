java.util.concurrent.Executors.newScheduledThreadPool(Runtime.getRuntime().availableProcessors()).schedule(() -> {
${statement$do}
}, (long) ${input$time}, java.util.concurrent.TimeUnit.${field$type});
