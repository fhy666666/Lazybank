if (${input$entity} instanceof ServerPlayer _player) {
	_player.connection.send(new ClientboundSetTitleTextPacket(net.minecraft.network.chat.Component.literal(${input$text})));
}
