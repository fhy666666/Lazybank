if (world.isClientSide()) {
    LightBeamUtilsProcedure.shape(${input$id}, ${((field$shape!"SQUARE")?upper_case == "ROUND")?c});
}
RegPacketProcedure.hxSend(world, "lightbeam.shape", ${input$id}, ${((field$shape!"SQUARE")?upper_case == "ROUND")?c});
