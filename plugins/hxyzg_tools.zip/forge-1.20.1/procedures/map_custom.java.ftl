{
	if (world instanceof ServerLevel serverLevel){
		BlockPos PosTemp = new BlockPos(${input$x}, ${input$y}, ${input$z});
		Player player = (Player) ${input$entity};
		MapUtilsProcedure.createTargetMap(serverLevel, player, PosTemp, ${input$MapName}, (byte)${input$NumA}, ${input$NumB});
	}
}