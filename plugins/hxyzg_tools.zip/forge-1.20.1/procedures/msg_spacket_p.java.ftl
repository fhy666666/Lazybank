UUID uuidTemp = UUID.fromString(${input$entity}.getStringUUID());
String textTemp = ${input$tagValue};
RegPacketProcedure.CHANNELC.sendToServer(new RegPacketProcedure.RegPacketCommC(uuidTemp, textTemp));
