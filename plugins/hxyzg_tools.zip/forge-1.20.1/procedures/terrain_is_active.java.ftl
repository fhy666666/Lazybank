(FakeTerrainUtilsProcedure.isActive())
