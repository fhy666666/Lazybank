for (${field$type} ${field$local_variable_name} : ${field$array_name}) {
${statement$do}
}
