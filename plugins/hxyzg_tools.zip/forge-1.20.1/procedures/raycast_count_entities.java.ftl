(RayCastUtilsProcedure.countEntities(${input$entity}, ${input$range}, <#if field$ignoreliquid == "TRUE">true<#else>false</#if>))
