(RayCastUtilsProcedure.hitFace(${input$entity}, ${input$range}, <#if field$ignoreblocks == "TRUE">true<#else>false</#if>, <#if field$ignoreliquid == "TRUE">true<#else>false</#if>))
