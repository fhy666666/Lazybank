${field$one} (${field$two}) {
${statement$do}
}