${field$local_variable_name} = ${input$content};
