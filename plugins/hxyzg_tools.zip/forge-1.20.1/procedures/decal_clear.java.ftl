if (world.isClientSide()) {
    DecalUtilsProcedure.clear();
}
RegPacketProcedure.hxSend(world, "decal.clear");
