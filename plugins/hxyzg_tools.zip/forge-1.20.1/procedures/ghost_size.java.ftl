if (world.isClientSide()) {
	GhostUtilsProcedure.setSize(${input$entity}, ${input$size});
}
RegPacketProcedure.hxSend(world, "ghost.size", ${input$entity}, ${input$size});
