if (world.isClientSide()) {
    LightBeamUtilsProcedure.place(${input$id}, ${input$x}, ${input$y}, ${input$z}, ${input$height}, ${input$width}, ${input$color}, ${((field$fade_in!"FALSE")?lower_case == "true")?c}, ${input$fade_in_ticks}, ${((field$fade_out!"FALSE")?lower_case == "true")?c}, ${input$fade_out_ticks});
}
RegPacketProcedure.hxSend(world, "lightbeam.place", ${input$id}, ${input$x}, ${input$y}, ${input$z}, ${input$height}, ${input$width}, ${input$color}, ${((field$fade_in!"FALSE")?lower_case == "true")?c}, ${input$fade_in_ticks}, ${((field$fade_out!"FALSE")?lower_case == "true")?c}, ${input$fade_out_ticks});
