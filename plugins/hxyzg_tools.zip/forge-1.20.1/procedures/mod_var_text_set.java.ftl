{
	String _setval = ${input$tagValue};
	${input$entity}.getCapability(${field$modid}ModVariables.PLAYER_VARIABLES, null).ifPresent(capability -> {
		capability.${field$varName} = _setval;
		capability.syncPlayerVariables(${input$entity});
	});
}