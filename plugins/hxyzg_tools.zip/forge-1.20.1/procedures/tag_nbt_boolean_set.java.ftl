${field$tagID}.putBoolean(${input$tagName}, ${input$tagValue});
