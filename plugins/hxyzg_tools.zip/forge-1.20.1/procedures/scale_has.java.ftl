ScaleUtilsProcedure.has(${input$entity})
