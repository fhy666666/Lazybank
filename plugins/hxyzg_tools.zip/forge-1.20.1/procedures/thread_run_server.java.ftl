if (world instanceof ServerLevel _sl && _sl.getServer() != null) {
	_sl.getServer().execute(() -> {
${statement$do}
	});
}