<#include "mcelements.ftl">
<#assign entity = generator.map(field$entity, "entities", 1)!"null">
<#if entity != "null">
if (world instanceof ServerLevel _level) {
	net.minecraft.world.entity.Entity entityToSpawn = ${entity}.spawn(_level, ${toBlockPos(input$x,input$y,input$z)}, net.minecraft.world.entity.MobSpawnType.MOB_SUMMONED);
	if (entityToSpawn != null) {
		entityToSpawn.setYRot(${opt.toFloat(input$yaw)});
		entityToSpawn.setYBodyRot(${opt.toFloat(input$yaw)});
		entityToSpawn.setYHeadRot(${opt.toFloat(input$yaw)});
		entityToSpawn.setXRot(${opt.toFloat(input$pitch)});
		${statement$foreach}
	}
}
</#if>
