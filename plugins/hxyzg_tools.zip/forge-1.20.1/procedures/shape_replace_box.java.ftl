<#include "mcitems.ftl">
ShapeUtilsProcedure.replaceBox(world, ${input$x1}, ${input$y1}, ${input$z1}, ${input$x2}, ${input$y2}, ${input$z2}, ${mappedBlockToBlockStateCode(input$blockFrom)}, ${mappedBlockToBlockStateCode(input$blockTo)});
