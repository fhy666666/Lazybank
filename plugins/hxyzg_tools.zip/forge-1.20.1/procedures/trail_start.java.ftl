if (world.isClientSide()) {
    TrailUtilsProcedure.start(${input$entity}, ${generator.map(field$particle, "particles")}, ${opt.toInt(input$width)});
}
RegPacketProcedure.hxTrailStart(world, ${input$entity}, ${generator.map(field$particle, "particles")}, ${opt.toInt(input$width)});
