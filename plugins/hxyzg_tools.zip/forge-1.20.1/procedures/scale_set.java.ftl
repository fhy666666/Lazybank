ScaleUtilsProcedure.set(${input$entity}, ${input$value}, "${field$mode}", (int) (${input$ticks}));
