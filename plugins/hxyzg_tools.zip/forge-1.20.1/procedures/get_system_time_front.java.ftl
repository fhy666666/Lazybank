java.util.Calendar cal = java.util.Calendar.getInstance();
${statement$do}
