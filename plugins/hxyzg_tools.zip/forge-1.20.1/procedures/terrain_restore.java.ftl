if (world.isClientSide()) {
    FakeTerrainUtilsProcedure.restore(world);
}
RegPacketProcedure.hxSend(world, "terrain.restore", world);
