{
	net.minecraft.world.entity.Entity _ent = ${input$entity};
	_ent.setDeltaMovement(new net.minecraft.world.phys.Vec3(${input$vx}, _ent.getDeltaMovement().y, _ent.getDeltaMovement().z));
}
