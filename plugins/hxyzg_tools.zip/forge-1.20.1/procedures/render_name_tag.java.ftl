${input$entity}.setCustomNameVisible(${input$tagValue});
