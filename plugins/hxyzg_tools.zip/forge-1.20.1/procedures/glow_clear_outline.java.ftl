GlowUtilsProcedure.clearOutline(world, ${input$entity});
