<#include "mcelements.ftl">
${package}.init.${JavaModName}BerSupport.swapLookedSlot(world, ${toBlockPos(input$x, input$y, input$z)}, ${input$entity}, InteractionHand.MAIN_HAND);
