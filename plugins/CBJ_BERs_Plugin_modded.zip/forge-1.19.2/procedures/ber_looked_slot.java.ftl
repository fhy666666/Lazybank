<#include "mcelements.ftl">
/*@int*/${package}.init.${JavaModName}BerSupport.getLookedSlot(world, ${toBlockPos(input$x, input$y, input$z)}, ${input$entity})
