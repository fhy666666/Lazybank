<#include "mcelements.ftl">
/*@int*/${package}.init.${JavaModName}BerSupport.getDisplaySlotCount(world, ${toBlockPos(input$x, input$y, input$z)})
