<#include "mcelements.ftl">
/*@ItemStack*/(${package}.init.${JavaModName}BerSupport.getDisplayItem(world, ${toBlockPos(input$x, input$y, input$z)}, ${opt.toInt(input$slotid)}).copy())
