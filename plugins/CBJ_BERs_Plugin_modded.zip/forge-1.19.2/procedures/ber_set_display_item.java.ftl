<#include "mcelements.ftl">
<#include "mcitems.ftl">
{
	ItemStack _berStack = ${mappedMCItemToItemStackCode(input$item, 1)}.copy();
	_berStack.setCount(${opt.toInt(input$amount)});
	${package}.init.${JavaModName}BerSupport.setDisplayItem(world, ${toBlockPos(input$x, input$y, input$z)}, ${opt.toInt(input$slotid)}, _berStack);
}
