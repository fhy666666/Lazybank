<#include "mcelements.ftl">
${package}.init.${JavaModName}BerSupport.setSlotsLocked(world, ${toBlockPos(input$x, input$y, input$z)}, false);
