<#include "mcelements.ftl">
${package}.init.${JavaModName}BerSupport.insertIntoNextEmpty(world, ${toBlockPos(input$x, input$y, input$z)}, ${input$entity}, InteractionHand.MAIN_HAND);
