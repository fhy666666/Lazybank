<#include "mcelements.ftl">
/*@int*/${package}.init.${JavaModName}BerSupport.getFirstEmptyDisplaySlot(world, ${toBlockPos(input$x, input$y, input$z)})
