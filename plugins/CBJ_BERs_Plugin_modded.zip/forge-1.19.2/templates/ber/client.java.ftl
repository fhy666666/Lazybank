<#-- Overlay rendering is unused; items are drawn by each BER renderer. -->
package ${package}.init;

public class ${JavaModName}BerClient {
}
