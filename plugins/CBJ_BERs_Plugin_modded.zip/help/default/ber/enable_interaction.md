Deprecated. Use **Right-click interaction** instead.

When **Look at a display slot** is selected, right-clicking while looking at a display slot inserts, extracts, or swaps the item.

- Empty slot + item in hand: place one item
- Occupied slot + empty hand: take the item
- Same item: add one to the stack
- Different items: swap stacks

Sneaking can be set to skip this and open the block GUI instead.
