Optional procedure run when a display slot is used.

`slotid` is the **display slot index** (0 is the first slot in this BER element), not necessarily the block inventory index.

Provided dependencies:

- `x / y / z` — block position
- `world`
- `entity` — the clicking player
- `itemstack` — item in the used hand
- `slotid` — display slot that was used
- `blockstate`

If a built-in interaction mode is also enabled, that insert/extract happens first, then this procedure runs.
