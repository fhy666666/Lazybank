The custom block this renderer is attached to.

The block **must have inventory / tile entity enabled** in its Block editor. That block entity is what the BER reads items from and what Minecraft uses to register the renderer.

Use a normal JSON/block model for the block itself (not the Entity model render type). The BER draws the items on top of that model.
