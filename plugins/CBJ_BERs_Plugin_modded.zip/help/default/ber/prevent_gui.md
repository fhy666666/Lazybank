When a display slot is hit, cancel the default block right-click (usually the inventory GUI).

Leave this on for shelves and item frames. Turn it off if you want the GUI to open even when looking at a slot.
