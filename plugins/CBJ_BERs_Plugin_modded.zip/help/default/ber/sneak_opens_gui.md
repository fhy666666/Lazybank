If enabled, sneaking while right-clicking ignores display-slot interaction so the block's GUI (or other right-click behavior) can run.

Useful for shelves that both display items and have a storage screen.
