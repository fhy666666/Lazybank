How right-clicking the block interacts with display slots.

**Fill next empty display slot** — each right-click puts the item in the player's main hand into the first empty display slot (0, then 1, then 2, …). An empty hand takes the last occupied slot back. You do **not** have to look at a specific spot.

**Look at a display slot** — right-click the slot you are aiming at to insert, extract, or swap.

**None (use procedures)** — the plugin does not handle right-click. Use the block's own right-click procedure plus BER procedure blocks such as *Put main-hand item into first empty BER display slot*.
