How far away the player can be (in blocks) and still see the rendered items.

64 matches vanilla block-entity renderers. Increase it for large display pieces.
