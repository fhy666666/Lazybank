When enabled, display slot positions and items rotate with the block's `FACING` / `HORIZONTAL_FACING` / `AXIS` property.

Define slot offsets as if the block faces **north** (front is -Z). The plugin rotates them at runtime.
