**Regular** stands the item upright and uses one hitbox size for X, Y, and Z.

**Flat** lays the item down on the shelf. The hitbox can then be sized separately on X, Y, and Z so a thin plate matches the item.

Rotation still applies on top of either type. Author offsets as if the block faces north.
