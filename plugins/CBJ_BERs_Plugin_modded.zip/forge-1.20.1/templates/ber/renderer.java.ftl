<#include "../mcitems.ftl">
<#-- @formatter:off -->
package ${package}.client.renderer.block;

<#assign animated = data.isAnimatedTarget()>
<#assign beClass = data.getTargetBlockEntityClass()>

@Mod.EventBusSubscriber(modid = ${JavaModName}.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ${name}BlockEntityRenderer <#if animated>extends ${package}.block.renderer.${data.getTargetName()}TileRenderer<#else>implements BlockEntityRenderer<${beClass}></#if> {

	<#if animated>
	public ${name}BlockEntityRenderer() {
		super();
	}

	@Override
	public void render(${beClass} blockEntity, float partialTick, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, int packedOverlay) {
		super.render(blockEntity, partialTick, poseStack, bufferSource, packedLight, packedOverlay);
		renderDisplayItems(blockEntity, poseStack, bufferSource, packedLight, packedOverlay);
	}
	<#else>
	public ${name}BlockEntityRenderer(BlockEntityRendererProvider.Context context) {
	}

	@Override public int getViewDistance() {
		return ${data.viewDistance};
	}

	@Override
	public void render(${beClass} blockEntity, float partialTick, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, int packedOverlay) {
		renderDisplayItems(blockEntity, poseStack, bufferSource, packedLight, packedOverlay);
	}
	</#if>

	private static void renderDisplayItems(BlockEntity blockEntity, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, int packedOverlay) {
		Level level = blockEntity.getLevel();
		if (level == null)
			return;
		BlockState state = blockEntity.getBlockState();
		ItemRenderer itemRenderer = Minecraft.getInstance().getItemRenderer();
		<#list data.displaySlots as slot>
		{
			ItemStack stack;
			<#if slot.hasFixedItem()>
			stack = ${mappedMCItemToItemStackCode(slot.fixedItem.getUnmappedValue(), 1)};
			<#else>
			stack = ItemStack.EMPTY;
			if (blockEntity instanceof Container container && ${slot.inventorySlot} < container.getContainerSize())
				stack = container.getItem(${slot.inventorySlot});
			</#if>
			if (!stack.isEmpty()) {
				poseStack.pushPose();
				<#if data.rotateWithBlockFacing && slot.followBlockRotation>
				<#if animated>
				poseStack.translate(0.5, 0, 0.5);
				applyFacingRotation(poseStack, state);
				poseStack.translate(${(slot.offsetX - 0.5)?c}, ${slot.offsetY?c}, ${(slot.offsetZ - 0.5)?c});
				<#else>
				poseStack.translate(0.5, 0.5, 0.5);
				applyFacingRotation(poseStack, state);
				poseStack.translate(${(slot.offsetX - 0.5)?c}, ${(slot.offsetY - 0.5)?c}, ${(slot.offsetZ - 0.5)?c});
				</#if>
				<#else>
				poseStack.translate(${slot.offsetX?c}, ${slot.offsetY?c}, ${slot.offsetZ?c});
				</#if>
				<#if slot.isFlat()>
				poseStack.mulPose(Axis.YP.rotationDegrees(${(slot.rotationY + 180)?c}f));
				poseStack.mulPose(Axis.XP.rotationDegrees(${(90 + slot.rotationX)?c}f));
				<#if slot.rotationZ != 0>
				poseStack.mulPose(Axis.ZP.rotationDegrees(${slot.rotationZ?c}f));
				</#if>
				<#else>
				<#if slot.rotationX != 0>
				poseStack.mulPose(Axis.XP.rotationDegrees(${slot.rotationX?c}f));
				</#if>
				poseStack.mulPose(Axis.YP.rotationDegrees(${(slot.rotationY + 180)?c}f));
				<#if slot.rotationZ != 0>
				poseStack.mulPose(Axis.ZP.rotationDegrees(${slot.rotationZ?c}f));
				</#if>
				</#if>
				float _scale${slot?index} = ${slot.scale?c}f;
				poseStack.scale(_scale${slot?index}, _scale${slot?index}, _scale${slot?index});
				itemRenderer.renderStatic(stack, ItemDisplayContext.${slot.displayContext!'FIXED'}, packedLight, packedOverlay, poseStack, bufferSource, level, ${slot?index});
				poseStack.popPose();
			}
		}
		</#list>
	}

	private static void applyFacingRotation(PoseStack poseStack, BlockState state) {
		Direction facing = Direction.NORTH;
		if (state.hasProperty(BlockStateProperties.HORIZONTAL_FACING))
			facing = state.getValue(BlockStateProperties.HORIZONTAL_FACING);
		else if (state.hasProperty(BlockStateProperties.FACING))
			facing = state.getValue(BlockStateProperties.FACING);
		switch (facing) {
			<#if animated>
			case SOUTH -> poseStack.mulPose(Axis.YP.rotationDegrees(180f));
			case WEST -> poseStack.mulPose(Axis.YP.rotationDegrees(90f));
			case EAST -> poseStack.mulPose(Axis.YP.rotationDegrees(270f));
			case UP -> poseStack.mulPose(Axis.XP.rotationDegrees(90f));
			case DOWN -> poseStack.mulPose(Axis.XN.rotationDegrees(90f));
			<#else>
			case SOUTH -> poseStack.mulPose(Axis.YP.rotationDegrees(180f));
			case WEST -> poseStack.mulPose(Axis.YP.rotationDegrees(90f));
			case EAST -> poseStack.mulPose(Axis.YP.rotationDegrees(270f));
			case UP -> poseStack.mulPose(Axis.XP.rotationDegrees(90f));
			case DOWN -> poseStack.mulPose(Axis.XP.rotationDegrees(-90f));
			</#if>
			default -> {
			}
		}
	}

	@SubscribeEvent(priority = EventPriority.LOW)
	public static void registerBlockEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		<#if animated>
		event.registerBlockEntityRenderer(${JavaModName}BlockEntities.${data.getTargetRegistryNameUpper()}.get(), context -> new ${name}BlockEntityRenderer());
		<#else>
		event.registerBlockEntityRenderer(${JavaModName}BlockEntities.${data.getTargetRegistryNameUpper()}.get(), ${name}BlockEntityRenderer::new);
		</#if>
	}

}
<#-- @formatter:on -->
