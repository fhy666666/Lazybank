<#include "procedures.java.ftl">
@Mod.EventBusSubscriber public class ${name}Procedure {
	@SubscribeEvent public static void onLivingChangeTarget(LivingChangeTargetEvent event) {
		if (event != null && event.getEntity() != null) {
  		<#assign dependenciesCode><#compress>
  			<@procedureDependenciesCode dependencies, {
  			"x": "event.getEntity().getX()",
  			"y": "event.getEntity().getY()",
  			"z": "event.getEntity().getZ()",
  			"world": "event.getEntity().level()",
  			"entity": "event.getOriginalTarget()",
  			"sourceentity": "event.getEntity()",
  			"event": "event"
  			}/>
  		</#compress></#assign>
  		execute(event<#if dependenciesCode?has_content>,</#if>${dependenciesCode});
  	}
  }