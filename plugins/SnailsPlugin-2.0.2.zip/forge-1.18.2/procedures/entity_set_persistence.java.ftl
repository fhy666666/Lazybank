if(${input$entity} instanceof Mob _entity) _entity.setPersistenceRequired();
