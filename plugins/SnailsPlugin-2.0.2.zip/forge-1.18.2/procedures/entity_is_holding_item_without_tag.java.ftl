<#include "mcelements.ftl">
<#include "mcitems.ftl">
(!(${input$entity} instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).is(ItemTags.create(${toResourceLocation(input$tag)})) || !(${input$entity} instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).is(ItemTags.create(${toResourceLocation(input$tag)})))