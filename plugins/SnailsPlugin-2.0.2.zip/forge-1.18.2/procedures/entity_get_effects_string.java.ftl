"" + ${input$entity} instanceof LivingEntity _entity ? _entity.getActiveEffects()
