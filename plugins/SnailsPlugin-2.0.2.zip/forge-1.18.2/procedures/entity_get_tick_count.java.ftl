(${input$entity}.tickCount)

