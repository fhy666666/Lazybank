<#include "procedures.java.ftl">
public class ${name}Procedure {
    public static void placeholderEvent(PlaceholderEvent event) {
        <#assign dependenciesCode><#compress>
            <@procedureDependenciesCode dependencies, {
            "x": "props.pos().x()",
            "y": "props.pos().y()",
            "z": "props.pos().z()",
            "entity": "props.entity()",
            "world": "props.level()",
            "sourceentity": "props.sourceEntity()",
            "immediatesourceentity": "props.immediateSourceEntity()",
            "blockstate": "props.blockState()",
			"itemstack": "props.itemStack()",
			"damagesource": "props.damageSource()",
			"direction": "props.direction()",
			"dimension": "props.dimension()"
            }/>
        </#compress></#assign>
        var props = event.properties();
        execute(event<#if dependenciesCode?has_content>,</#if>${dependenciesCode});
    }