<#include "redwires_plugin_utils.ftl">
arguments.getSource().sendSuccess(Component.literal(${opt.removeParentheses(input$message)}), ${input$inform});