<#include "redwires_plugin_utils.ftl">
if (event instanceof PlayerXpEvent.XpChange _xpChange${index})
    _xpChange${index}.setAmount(${opt.toInt(input$amount)});