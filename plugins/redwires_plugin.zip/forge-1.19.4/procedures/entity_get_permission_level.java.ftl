<#include "redwires_plugin_utils.ftl">
<@templateOrFallback "get_permission_level"/>
getPermissionLevel(${opt.removeParentheses(input$entity)})