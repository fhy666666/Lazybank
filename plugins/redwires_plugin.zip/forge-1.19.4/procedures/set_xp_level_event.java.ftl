<#include "redwires_plugin_utils.ftl">
if (event instanceof PlayerXpEvent.LevelChange _lvlChange${index})
    _lvlChange${index}.setLevels(${opt.toInt(input$amount)});