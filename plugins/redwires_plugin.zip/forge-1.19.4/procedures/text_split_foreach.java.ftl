<#include "redwires_plugin_utils.ftl">
<#assign splitTxt = input$2split>
<#if (field$stringliteral!"TRUE") == "TRUE">
<#assign splitTxt = "Pattern.quote(${splitTxt})">
</#if>
<#if (field$includedelimiter!"FALSE") == "TRUE">
String _splitContent${index} = ${splitTxt};
<#assign splitTxt = "\"(?=\" + _splitContent${index} + \")|(?<=\" + _splitContent${index} + \")\"">
</#if>
<#if field$usewholestring == "TRUE">
String _toSplit${index} = ${input$text};
String[] _array${index} = _toSplit${index}.split(${splitTxt});
for (int _iter${index} = 0; _iter${index} < Math.max(1, _array${index}.length); _iter${index}++) {
    String stringiterator = _array${index}.length == 0 ? _toSplit${index} : _array${index}[_iter${index}];
<#else>
for (String stringiterator : ${input$text}.split(${splitTxt})) {
</#if>
    ${statement$foreach}
}