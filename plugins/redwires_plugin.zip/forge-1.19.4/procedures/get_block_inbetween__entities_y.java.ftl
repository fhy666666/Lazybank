<@addTemplate file="utils/get_block_between_entities.java.ftl"/>
/*@int*/getBlockBetweenEntities(${input$entity}, ${input$sourceentity}).getY()