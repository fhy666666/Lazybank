<#include "nbt_tags_utils.ftl">
Component.Serializer.fromJson((Tag) ${input$tag} instanceof StringTag _tag${index} ? _tag${index}.getAsString() : "\"\"")