package ${package}.mixin;

/*
 * 实体这一层的重力改造(参照成熟实现 GravityChanger 的做法).
 *
 * 速度与角度都按"重力坐标系"理解(上 = 身体的上), 所以那些拿世界轴当"上"的原版代码要接上换算:
 *   - 碰撞箱: 原版是按 (x, y..y+高, z) 摆的竖箱子, 这里把它转成"身体坐标系里的箱子";
 *   - 眼睛: 眼睛不再永远在 +Y 方向, 而是转到身体的"头"那一侧;
 *   - 视线: calculateViewVector 把"重力坐标系里的角度"换成世界方向(准星/射线/鞘翅都用它);
 *   - move: 进来的位移是重力坐标系里的量, 碰撞/落位要用世界量, 所以换过去再换回来.
 *
 * 注意: "换回来"只对 6 个轴方向做(此时换算是整数置换, 逐位精确, 与参考实现一致), 这样
 * roll/pitch/yaw/onGround/脚步声判定全都落在身体坐标系里. 斜向重力下原版那套"世界轴被挡住"
 * 的判定没法一一对应, 那时保持世界量, 并由 hxg$footProbe 自己沿重力方向探"脚底下有没有东西".
 */

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import ${package}.gravity.HxgGravity;

import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

@Mixin(Entity.class)
public abstract class HxgEntityMixin {
	@Shadow
	private float eyeHeight;

	private HxgGravity.G hxg$g() {
		return HxgGravity.of((Entity) (Object) this);
	}

	// ===== 碰撞箱: 换成"身体坐标系里的箱子" =====

	@Inject(method = "makeBoundingBox()Lnet/minecraft/world/phys/AABB;", at = @At("RETURN"), cancellable = true)
	private void hxg$makeBox(CallbackInfoReturnable<AABB> cir) {
		HxgGravity.G g = hxg$g();
		if (g == null || g.vanilla)
			return;
		Entity self = (Entity) (Object) this;
		Vec3 pos = self.position();
		AABB local = cir.getReturnValue().move(-pos.x, -pos.y, -pos.z);
		// 脚那一面(重力坐标系里的 -Y 面)往身体内侧收一点, 留出空隙. 原版是按世界轴解算碰撞的:
		// 箱子与脚下方块贴死/重合时会被当成"卡在方块里", 再被整个挤出去(表现就是"被挤到方块上方").
		// 旧代码在这里对 POSITIVE 方向挪 -1.0E-6 —— 方向反了(那是往脚下方块里压, 自己造出重合),
		// 而且 1e-6 只比引擎的 1.0E-7 容差大一个数量级, 挡不住这种判定.
		local = new AABB(local.minX, local.minY + HxgGravity.FOOT_GAP, local.minZ, local.maxX, local.maxY,
				local.maxZ);
		cir.setReturnValue(HxgGravity.boxL2W(g, local).move(pos));
	}

	@Inject(method = "getBoundingBoxForPose(Lnet/minecraft/world/entity/Pose;)Lnet/minecraft/world/phys/AABB;", at = @At("RETURN"), cancellable = true)
	private void hxg$makeBoxPose(Pose pose, CallbackInfoReturnable<AABB> cir) {
		HxgGravity.G g = hxg$g();
		if (g == null || g.vanilla)
			return;
		Entity self = (Entity) (Object) this;
		Vec3 pos = self.position();
		// 这个箱子只喂 canEnterPose(蹲下/换姿势进不进得去), 本来就整体收 0.01; 改成读同一个常量,
		// 免得以后只改了 makeBoundingBox 那一边.
		AABB local = cir.getReturnValue().move(-pos.x, -pos.y, -pos.z).inflate(-HxgGravity.FOOT_GAP);
		cir.setReturnValue(HxgGravity.boxL2W(g, local).move(pos));
	}

	// ===== 视线与眼睛 =====

	@Inject(method = "calculateViewVector(FF)Lnet/minecraft/world/phys/Vec3;", at = @At("RETURN"), cancellable = true)
	private void hxg$viewVec(float pitch, float yaw, CallbackInfoReturnable<Vec3> cir) {
		HxgGravity.G g = hxg$g();
		if (g == null || g.vanilla)
			return;
		cir.setReturnValue(HxgGravity.l2w(g, cir.getReturnValue()));
	}

	@Inject(method = "getEyePosition()Lnet/minecraft/world/phys/Vec3;", at = @At("HEAD"), cancellable = true)
	private void hxg$eye(CallbackInfoReturnable<Vec3> cir) {
		HxgGravity.G g = hxg$g();
		if (g == null || g.vanilla)
			return;
		cir.setReturnValue(HxgGravity.l2w(g, 0.0D, (double) this.eyeHeight, 0.0D).add(((Entity) (Object) this).position()));
	}

	@Inject(method = "getEyePosition(F)Lnet/minecraft/world/phys/Vec3;", at = @At("HEAD"), cancellable = true)
	private void hxg$eyeLerp(float partial, CallbackInfoReturnable<Vec3> cir) {
		HxgGravity.G g = hxg$g();
		if (g == null || g.vanilla)
			return;
		Entity self = (Entity) (Object) this;
		Vec3 off = HxgGravity.l2w(g, 0.0D, (double) this.eyeHeight, 0.0D);
		cir.setReturnValue(new Vec3(Mth.lerp((double) partial, self.xo, self.getX()) + off.x,
				Mth.lerp((double) partial, self.yo, self.getY()) + off.y,
				Mth.lerp((double) partial, self.zo, self.getZ()) + off.z));
	}

	// ===== 摩擦方块 / 落脚方块 =====

	@Inject(method = "getBlockPosBelowThatAffectsMyMovement()Lnet/minecraft/core/BlockPos;", at = @At("HEAD"), cancellable = true)
	private void hxg$frictionPos(CallbackInfoReturnable<BlockPos> cir) {
		HxgGravity.G g = hxg$g();
		if (g == null || g.vanilla)
			return;
		Entity self = (Entity) (Object) this;
		cir.setReturnValue(BlockPos.containing(HxgGravity.l2w(g, 0.0D, -0.5000001D, 0.0D).add(self.position())));
	}

	@Inject(method = "getOnPosLegacy()Lnet/minecraft/core/BlockPos;", at = @At("HEAD"), cancellable = true)
	private void hxg$onPos(CallbackInfoReturnable<BlockPos> cir) {
		HxgGravity.G g = hxg$g();
		if (g == null || g.vanilla)
			return;
		Entity self = (Entity) (Object) this;
		cir.setReturnValue(
				BlockPos.containing(HxgGravity.l2w(g, 0.0D, -0.20000000298023224D, 0.0D).add(self.position())));
	}

	// ===== move: 位移按世界量算, 算完(轴方向时)换回重力坐标系, 让"哪根轴被挡住"的判定仍然成立 =====

	@ModifyVariable(method = "move(Lnet/minecraft/world/entity/MoverType;Lnet/minecraft/world/phys/Vec3;)V", at = @At("HEAD"), argsOnly = true, ordinal = 0)
	private Vec3 hxg$moveHead(Vec3 v) {
		HxgGravity.G g = hxg$g();
		if (g == null || g.vanilla)
			return v;
		return HxgGravity.l2w(g, v);
	}

	@ModifyVariable(method = "move(Lnet/minecraft/world/entity/MoverType;Lnet/minecraft/world/phys/Vec3;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/profiling/ProfilerFiller;pop()V", ordinal = 0), argsOnly = true, ordinal = 0)
	private Vec3 hxg$moveParamBack(Vec3 v) {
		HxgGravity.G g = hxg$g();
		if (g == null || g.vanilla || !g.axis)
			return v;
		return HxgGravity.w2l(g, v);
	}

	@ModifyVariable(method = "move(Lnet/minecraft/world/entity/MoverType;Lnet/minecraft/world/phys/Vec3;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/profiling/ProfilerFiller;pop()V", ordinal = 0), ordinal = 1)
	private Vec3 hxg$moveResultBack(Vec3 v) {
		HxgGravity.G g = hxg$g();
		if (g == null || g.vanilla || !g.axis)
			return v;
		return HxgGravity.w2l(g, v);
	}

	/** 斜向重力: 原版的 verticalCollisionBelow(世界轴) 说明不了"脚底下有没有东西", 这里自己沿重力方向探 */
	@Inject(method = "move(Lnet/minecraft/world/entity/MoverType;Lnet/minecraft/world/phys/Vec3;)V", at = @At("TAIL"))
	private void hxg$footProbe(MoverType type, Vec3 movement, CallbackInfo ci) {
		HxgGravity.G g = hxg$g();
		if (g == null || g.vanilla || g.axis)
			return;
		Entity self = (Entity) (Object) this;
		AABB probe = self.getBoundingBox().move(-g.x * 0.06D, -g.y * 0.06D, -g.z * 0.06D);
		boolean hit = false;
		for (net.minecraft.world.phys.shapes.VoxelShape s : self.level().getBlockCollisions(self, probe)) {
			if (!s.isEmpty()) {
				hit = true;
				break;
			}
		}
		self.setOnGround(hit);
	}

	// ===== 别的按世界轴取方块/摆盒子的地方 =====
	//
	// 这两处原来写的是 @ModifyArgs —— 那个注入器会让 Mixin 在运行期给被改的调用点生成一个
	// org.spongepowered.asm.synthetic.args.Args$N 合成类, 而 Forge/ModLauncher 的 ModuleClassLoader
	// 不认这个包(不在 mixin 模块的 ModulePackages 里, 也没被 export), 游戏一启动就
	// NoClassDefFoundError: org/spongepowered/asm/synthetic/args/Args$2. 改成 @Redirect 后不需要合成类,
	// 语义逐位等价(原来是把三个参数换掉再调原方法, 现在是自己换好再调原方法).

	@Redirect(method = "isFree(DDD)Z", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/phys/AABB;move(DDD)Lnet/minecraft/world/phys/AABB;", ordinal = 0))
	private AABB hxg$freeMove(AABB self, double x, double y, double z) {
		HxgGravity.G g = hxg$g();
		if (g == null || g.vanilla)
			return self.move(x, y, z);
		Vec3 v = HxgGravity.l2w(g, x, y, z);
		return self.move(v.x, v.y, v.z);
	}

	@Redirect(method = "isInWall()Z", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/phys/AABB;ofSize(Lnet/minecraft/world/phys/Vec3;DDD)Lnet/minecraft/world/phys/AABB;", ordinal = 0))
	private AABB hxg$inWall(Vec3 center, double sx, double sy, double sz) {
		HxgGravity.G g = hxg$g();
		if (g == null || g.vanilla)
			return AABB.ofSize(center, sx, sy, sz);
		Vec3 v = HxgGravity.l2w(g, sx, sy, sz);
		return AABB.ofSize(center, v.x, v.y, v.z);
	}
}
