package ${package}.mixin;

/*
 * 生物这一层的重力改造(参照成熟实现 GravityChanger 的做法).
 *
 * 速度/角度已经是重力坐标系里的量, 所以绝大多数原版逻辑(重力大小、摩擦、跳跃、游泳、鞘翅)
 * 不用改就直接对. 这里只补三件"按世界 +Y 取东西"的事:
 *   1) travel() 里判断"是不是在水/岩浆里、往上顶一格有没有空间"用的是世界 Y, 要换成身体坐标系的 Y;
 *   2) 鞘翅那一段拿 getLookAngle()(世界方向)当局部方向用, 要换回来;
 *   3) 摔落伤害: 身体坐标系里掉 1 格和世界 Y 掉 1 格不是一回事, 按强度开方折一下(与参考实现一致).
 */

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import ${package}.gravity.HxgGravity;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

@Mixin(LivingEntity.class)
public abstract class HxgLivingEntityMixin {
	private HxgGravity.G hxg$g() {
		return HxgGravity.of((Entity) (Object) this);
	}

	/** travel() 里的世界 Y -> 身体坐标系的 Y(在水/岩浆里判断"顶上去有没有空间"用) */
	@Redirect(method = "travel(Lnet/minecraft/world/phys/Vec3;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getY()D", ordinal = 0))
	private double hxg$travelY0(LivingEntity self) {
		HxgGravity.G g = HxgGravity.of(self);
		if (g == null || g.vanilla)
			return self.getY();
		return HxgGravity.w2l(g, self.position()).y;
	}

	@Redirect(method = "travel(Lnet/minecraft/world/phys/Vec3;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getY()D", ordinal = 1))
	private double hxg$travelY1(LivingEntity self) {
		HxgGravity.G g = HxgGravity.of(self);
		if (g == null || g.vanilla)
			return self.getY();
		return HxgGravity.w2l(g, self.position()).y;
	}

	@Redirect(method = "travel(Lnet/minecraft/world/phys/Vec3;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getY()D", ordinal = 2))
	private double hxg$travelY2(LivingEntity self) {
		HxgGravity.G g = HxgGravity.of(self);
		if (g == null || g.vanilla)
			return self.getY();
		return HxgGravity.w2l(g, self.position()).y;
	}

	@Redirect(method = "travel(Lnet/minecraft/world/phys/Vec3;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getY()D", ordinal = 3))
	private double hxg$travelY3(LivingEntity self) {
		HxgGravity.G g = HxgGravity.of(self);
		if (g == null || g.vanilla)
			return self.getY();
		return HxgGravity.w2l(g, self.position()).y;
	}

	/** 鞘翅: 那一段把视线方向当"局部方向"用, 所以把世界方向换回重力坐标系 */
	@ModifyVariable(method = "travel(Lnet/minecraft/world/phys/Vec3;)V", at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/world/entity/LivingEntity;getLookAngle()Lnet/minecraft/world/phys/Vec3;", ordinal = 0), ordinal = 2)
	private Vec3 hxg$travelLook(Vec3 v) {
		HxgGravity.G g = hxg$g();
		if (g == null || g.vanilla)
			return v;
		return HxgGravity.w2l(g, v);
	}

	/** 姿势用的"局部"碰撞箱(原版也当成相对实体位置的世界轴盒子用) */
	@Inject(method = "getLocalBoundsForPose(Lnet/minecraft/world/entity/Pose;)Lnet/minecraft/world/phys/AABB;", at = @At("RETURN"), cancellable = true)
	private void hxg$localBounds(Pose pose, CallbackInfoReturnable<AABB> cir) {
		HxgGravity.G g = hxg$g();
		if (g == null || g.vanilla)
			return;
		// 这个箱子也是"脚摆在局部原点"的摆法, 同样把脚那一面往身体内侧收, 与 makeBoundingBox 留一样
		// 的空隙(理由见 HxgGravity.FOOT_GAP)
		AABB box = cir.getReturnValue();
		box = new AABB(box.minX, box.minY + HxgGravity.FOOT_GAP, box.minZ, box.maxX, box.maxY, box.maxZ);
		cir.setReturnValue(HxgGravity.boxL2W(g, box));
	}

	/** 摔落伤害按强度的开方折一下(身体坐标系里掉一格不等于世界 Y 掉一格) */
	@ModifyVariable(method = "calculateFallDamage(FF)I", at = @At("HEAD"), ordinal = 0, argsOnly = true)
	private float hxg$fallDamage(float value) {
		HxgGravity.G g = hxg$g();
		if (g == null || g.vanilla || g.strength == 1.0D)
			return value;
		return value * (float) Math.sqrt(g.strength);
	}
}
