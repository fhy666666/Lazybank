package ${package}.mixin;

/*
 * 方块遮挡覆盖层(ScreenEffectRenderer): 采样点也要按重力摆 —— 这就是"屏幕被方块贴图糊住"的根因.
 *
 * 现象(用户报的): 设过重力之后, 走在方块上时整个屏幕被方块贴图盖住; 有时候离方块差不多一格也会被盖住.
 * 这**不是相机的问题**(2.62.5 的 clampEye / 2.62.7 的余量 / 2.62.8 的空腔 / 2.62.9 的"余量最大"全都是
 * 在兜相机), 所以怎么兜都治不好 —— 这是原版"头埋在方块里"的那个**整屏效果**:
 *
 *   ScreenEffectRenderer.renderScreenEffect()
 *     -> getOverlayBlock(player)  取 8 个采样点
 *     只要有一个点落在"会挡住视线"的方块里(isViewBlocking), 就用那个方块的贴图铺满整屏(renderTex).
 *
 * 那 8 个采样点是这么来的(原版按"世界轴 = 身体轴"写死):
 *   x = getX()    + ((i>>0)%2 - 0.5) * 宽*0.8
 *   y = getEyeY() + ((i>>1)%2 - 0.5) * 0.1[ * 体型缩放]
 *   z = getZ()    + ((i>>2)%2 - 0.5) * 宽*0.8
 * 其中 **getEyeY() = position.y + eyeHeight 永远是世界 +Y 上的量**(它不在本插件改写的名单里: 改写的是
 * getEyePosition, 那个才是被搬进重力坐标系的真眼睛). 于是采样盒是"沿世界轴、还被抬高一整个眼高"的一小片,
 * 与真眼睛差了整整一个眼高(玩家站立时 1.62 格):
 *   - 重力颠倒(下 = 世界 +Y): 真眼睛在 position.y - 1.62, 采样盒却在 position.y + 1.62 —— 差 3.24 格;
 *   - 重力侧躺(下 = 世界 ±X / ±Z): 真眼睛在 position 水平方向 1.62 格处, 采样盒却在正上方 1.62 格 ——
 *     水平差 1.62、竖直再差 1.62.
 * 于是"玩家自己那一格明明是空气", 采样点却整片落进脚下方块 / 头顶方块 / 旁边的墙里 ⇒ 整屏糊贴图;
 * 走动时落到哪一块上就换哪一张贴图 —— 与用户说的"移动时贴图会变、变动的贴图符合包围着自己的方块"
 * 完全一致. 离方块差不多一格就被盖住, 也是这个"整体平移了一个眼高"的直接后果.
 *
 * 修法(与参考实现 GravityChanger 的 InGameOverlayRendererMixin 同一套几何):
 *   1) 采样中心改用**真眼睛** getEyePosition()(它已经被 HxgEntityMixin 搬进重力坐标系);
 *   2) "宽*0.8 / 0.1 / 宽*0.8" 这个尺寸向量用 HxgGravity.l2w 转到世界(6 个轴方向是精确的整数置换),
 *      于是采样盒变成"围着真眼睛、沿重力方向只有 0.1 厚、在身体平面里一个身宽"的那一小片.
 *
 * 【默认重力下与原版逐位一致】: 原版采样中心 (getX(), getEyeY(), getZ()) 正好等于 getEyePosition()
 * (Entity.getEyePosition 的正文就是 `new Vec3(this.getX(), this.getEyeY(), this.getZ())`), 而
 * l2w(null/vanilla, …) 原样返回 ⇒ 下面那份"原版采样"与装插件之前逐字相同, 一个点都不动.
 *
 * 【为什么挂 renderScreenEffect 里那次调用, 而不是挂 getOverlayBlock 本身】
 *   getOverlayBlock 是 Forge/NeoForge 往原版里**加的**方法(它把返回值换成 Pair<BlockState, BlockPos>,
 *   好让 RenderBlockScreenEffectEvent 拿到坐标), Mojang 映射表里**没有它** ⇒ `method = "getOverlayBlock(…)"`
 *   这种写法会被 Mixin 的注解处理器直接判死:
 *     error: Unable to locate obfuscation mapping for @Inject target getOverlayBlock
 *   (实测: _test\apcheck 里跑真处理器复现过; 这类错误在用户的 Gradle 构建里就是构建失败.)
 *   所以这里反过来: 宿主方法挑**有映射的原版方法** renderScreenEffect, 再用 @Redirect 换掉它内部那一次
 *   采样调用, 并且给 @At 标上 **remap = false** —— 注解处理器读到 remap=false 就完全跳过对 @At 目标的
 *   映射查找(AnnotatedMixinElementHandlerInjector.registerInjectionPoint 里 `if (elem.shouldRemap())`),
 *   而运行时用的就是字面名 getOverlayBlock, 这正是 Forge/NeoForge 打在补丁里的名字(生产环境也不会被
 *   重映射, 因为它不属于 Mojang 映射).
 *
 * 参考实现挂的是 Fabric 的 getViewBlockingState, 那份在 Forge/NeoForge 上只剩一个转手调 getOverlayBlock
 * 的薄壳、渲染路径自己不再调它, 照抄等于什么都没做 —— 这也是为什么这里换成了 redirect 调用点.
 */

import org.apache.commons.lang3.tuple.Pair;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import ${package}.gravity.HxgGravity;

import net.minecraft.client.renderer.ScreenEffectRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

@Mixin(ScreenEffectRenderer.class)
public abstract class HxgOverlayMixin {
	@Redirect(method = "renderScreenEffect(Lnet/minecraft/client/Minecraft;Lcom/mojang/blaze3d/vertex/PoseStack;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/ScreenEffectRenderer;getOverlayBlock(Lnet/minecraft/world/entity/player/Player;)Lorg/apache/commons/lang3/tuple/Pair;", remap = false))
	private static Pair<BlockState, BlockPos> hxg$overlay(Player player) {
		// 原版采样: 中心 (getX(), getEyeY(), getZ()), 尺寸沿世界轴. 默认重力下就用这一份(逐位一致).
		double w = (double) player.getBbWidth() * 0.8D;
		double h = 0.1D * (double) player.getScale();
		Vec3 eye = new Vec3(player.getX(), player.getEyeY(), player.getZ());
		Vec3 m = new Vec3(w, h, w);
		try {
			HxgGravity.G g = HxgGravity.of(player);
			if (g != null && !g.vanilla) {
				eye = player.getEyePosition(); // 真眼睛(已被搬到重力坐标系)
				m = HxgGravity.l2w(g, w, h, w); // 尺寸向量跟着重力转: 6 个轴方向是整数置换
			}
		} catch (Throwable t) {
			// 出错就退回上面那份原版采样: 宁可多一次原版判定, 也不能让渲染崩
		}
		BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
		for (int i = 0; i < 8; i++) {
			double x = eye.x + (((double) ((i >> 0) % 2) - 0.5D) * m.x);
			double y = eye.y + (((double) ((i >> 1) % 2) - 0.5D) * m.y);
			double z = eye.z + (((double) ((i >> 2) % 2) - 0.5D) * m.z);
			pos.set(x, y, z);
			BlockState state = player.level().getBlockState(pos);
			if (state.getRenderShape() != RenderShape.INVISIBLE && state.isViewBlocking(player.level(), pos)) {
				return Pair.of(state, pos.immutable());
			}
		}
		return null;
	}
}
