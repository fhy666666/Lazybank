package ${package}.gravity;

/*
 * 重力工具的状态/同步层(服务端权威 + 客户端画面).
 *
 * 与参考实现一致: 换重力方向时把实体"绕碰撞箱中心"转过去(不再传送去贴地), 位置/上一刻位置一起改,
 * 速度按新坐标系重算, 客户端同时起一段过渡动画. 客户端也会自己算一遍同样的位置改动, 所以两边不会打架.
 *
 * 生命体(含玩家)的重力大小交给原版的重力属性(entity_gravity), 所以强度倍数是直接改属性;
 * 其它实体(掉落物/箭/船…)仍然由我们每刻沿重力方向补一份加速度.
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

public final class HxgGravityNet {
	private HxgGravityNet() {
	}

	/** 存在实体持久数据里的键(沿用老键, 老存档里那份还能读回来) */
	private static final String KEY = "hxyzg_gravity";
	/** 网络协议版本(包格式改了就 +1) */
	private static final String PROTO = "3";
	/** 换重力过渡动画时长(毫秒) */
	public static final int ANIM_MS = 500;
	/** 原版重力基准(与 LivingEntity.DEFAULT_BASE_GRAVITY 一致) */
	private static final double BASE_G = 0.08D;

	private static final net.minecraftforge.network.simple.SimpleChannel CH = mkChannel();
	private static volatile boolean ready = false;
	/** 客户端刚收到状态: 让相机眼高一步到位(原版是 0.5/刻 的插值) */
	public static volatile boolean snapCam = false;

	private static net.minecraftforge.network.simple.SimpleChannel mkChannel() {
		try {
			return net.minecraftforge.network.NetworkRegistry.newSimpleChannel(
					new ResourceLocation("${modid}", "gravity_sync"), () -> PROTO, PROTO::equals, PROTO::equals);
		} catch (Throwable t) {
			return null;
		}
	}

	private static void reg() {
		if (ready)
			return;
		ready = true;
		if (CH != null)
			CH.registerMessage(0, Msg.class, Msg::encode, Msg::new, Msg::handle);
	}

	static {
		reg();
	}

	/** 万一这个类到加载末尾才第一次被初始化(Forge 自动注册事件订阅类时只 load 不 initialize), 这里再补一次 */
	@net.minecraftforge.fml.common.Mod.EventBusSubscriber(bus = net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus.MOD)
	public static class Net {
		@net.minecraftforge.eventbus.api.SubscribeEvent
		public static void init(net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent event) {
			reg();
		}
	}

	static {
		// 每刻把自定义重力"按原版重力属性"补上(生命体), 以及心跳
		net.minecraftforge.common.MinecraftForge.EVENT_BUS.addListener(HxgGravityNet::onLevelTick);
		net.minecraftforge.common.MinecraftForge.EVENT_BUS.addListener(HxgGravityNet::onEntityJoin);
	}

	// ===== 对外 API(积木调的就是这几个) =====

	/** 设置重力方向(自动归一化, 0 -10 0 等价于 0 -1 0)与强度倍数; 方向填 0 0 0 = 取消 */
	public static void set(Entity e, double x, double y, double z, double strength) {
		if (e == null)
			return;
		double len = Math.sqrt(x * x + y * y + z * z);
		if (len < 1.0E-6D) {
			reset(e);
			return;
		}
		if (!(e.level() instanceof ServerLevel))
			return;
		double nx = x / len;
		double ny = y / len;
		double nz = z / len;
		double s = strength < 0.0D ? 0.0D : strength;

		HxgGravity.G old = HxgGravity.ofServer(e);
		HxgGravity.G g = make(e, nx, ny, nz, s, old);
		boolean changed = old == null || old.x != nx || old.y != ny || old.z != nz;
		HxgGravity.putServer(e, g);
		save(e, g);
		if (changed)
			change(e, old, g, true);
		bcast(e, nx, ny, nz, s, true);
	}

	/** 重力颠倒: 设过就把方向整个取反; 没设过就当成"原版反过来" = (0,1,0) 强度 1 */
	public static void invert(Entity e) {
		if (e == null)
			return;
		HxgGravity.G g = HxgGravity.ofServer(e);
		if (g == null) {
			set(e, 0.0D, 1.0D, 0.0D, 1.0D);
			return;
		}
		set(e, -g.x, -g.y, -g.z, g.strength);
	}

	/** 恢复默认重力 */
	public static void reset(Entity e) {
		if (e == null)
			return;
		if (!(e.level() instanceof ServerLevel))
			return;
		HxgGravity.G g = HxgGravity.removeServer(e);
		if (g == null)
			g = load(e);
		if (g == null)
			return;
		e.getPersistentData().remove(KEY);
		restore(e, g);
		change(e, g, null, true);
		bcast(e, 0.0D, 0.0D, 0.0D, 0.0D, true);
	}

	/** 把所有实体恢复默认重力 */
	public static void clear() {
		for (Entity e : new ArrayList<>(HxgGravity.serverKeys()))
			reset(e);
	}

	public static boolean has(Entity e) {
		return HxgGravity.has(e);
	}

	public static double dirX(Entity e) {
		HxgGravity.G g = HxgGravity.of(e);
		return g == null ? 0.0D : g.x;
	}

	public static double dirY(Entity e) {
		HxgGravity.G g = HxgGravity.of(e);
		return g == null ? -1.0D : g.y;
	}

	public static double dirZ(Entity e) {
		HxgGravity.G g = HxgGravity.of(e);
		return g == null ? 0.0D : g.z;
	}

	/** 强度倍数(没设过返回 1) */
	public static double strengthOf(Entity e) {
		HxgGravity.G g = HxgGravity.of(e);
		return g == null ? 1.0D : g.strength;
	}

	// ===== 一份重力的建立/恢复 =====

	private static HxgGravity.G make(Entity e, double x, double y, double z, double s, HxgGravity.G old) {
		return make(e, x, y, z, s, old, Double.NaN, null);
	}

	/** oldAttrOverride / oldNgOverride 用于"从存档读回来"那条路(那份原状也一起存着) */
	private static HxgGravity.G make(Entity e, double x, double y, double z, double s, HxgGravity.G old,
			double oldAttrOverride, Boolean oldNgOverride) {
		Vec3 n = new Vec3(x, y, z);
		Direction d = HxgGravity.nearest(n, true);
		boolean vanilla = d == Direction.DOWN;
		double oldAttr = old != null ? old.oldAttr
				: (oldAttrOverride == oldAttrOverride && oldAttrOverride > 0.0D ? oldAttrOverride : attrOf(e));
		boolean oldNg = old != null ? old.oldNoGravity : (oldNgOverride != null ? oldNgOverride.booleanValue() : e.isNoGravity());
		return new HxgGravity.G(x, y, z, s, HxgGravity.rotFor(n), vanilla, d != null, d == null ? Direction.DOWN : d,
				oldAttr, oldNg);
	}

	private static double attrOf(Entity e) {
		if (e instanceof LivingEntity le) {
			net.minecraft.world.entity.ai.attributes.AttributeInstance ai = le
					.getAttribute(net.minecraftforge.common.ForgeMod.ENTITY_GRAVITY.get());
			if (ai != null)
				return ai.getBaseValue();
		}
		return BASE_G;
	}

	private static void restore(Entity e, HxgGravity.G g) {
		e.setNoGravity(g.oldNoGravity);
		if (e instanceof LivingEntity le) {
			net.minecraft.world.entity.ai.attributes.AttributeInstance ai = le
					.getAttribute(net.minecraftforge.common.ForgeMod.ENTITY_GRAVITY.get());
			if (ai != null)
				ai.setBaseValue(g.oldAttr);
		}
		e.hurtMarked = true;
	}

	/** 把这份重力真正接到实体上 */
	public static void apply(Entity e, HxgGravity.G g) {
		if (e instanceof LivingEntity le) {
			if (!g.oldNoGravity) {
				net.minecraft.world.entity.ai.attributes.AttributeInstance ai = le
						.getAttribute(net.minecraftforge.common.ForgeMod.ENTITY_GRAVITY.get());
				if (ai != null && Math.abs(ai.getBaseValue() - BASE_G * g.strength) > 1.0E-9D)
					ai.setBaseValue(BASE_G * g.strength);
			}
			return;
		}
		if (g.oldNoGravity)
			return;
		// 非生命体: 没有重力属性可用, 由 _step 每刻沿重力方向补一份加速度(见下), 这里先关掉原版重力
		e.setNoGravity(true);
	}

	// ===== 换方向那一下: 位置跟着新重力转过去 + 速度重算 + 客户端动画 =====

	/** 相对旋转中心(重力坐标系里): 正好反向时绕碰撞箱中心转, 其它情况绕实体位置转 */
	private static Vec3 rotationCenter(Entity e, HxgGravity.G oldG, HxgGravity.G newG) {
		double ox = oldG == null ? 0.0D : oldG.x;
		double oy = oldG == null ? -1.0D : oldG.y;
		double oz = oldG == null ? 0.0D : oldG.z;
		double nx = newG == null ? 0.0D : newG.x;
		double ny = newG == null ? -1.0D : newG.y;
		double nz = newG == null ? 0.0D : newG.z;
		if (ox == -nx && oy == -ny && oz == -nz) {
			// 正好反向(重力颠倒/恢复): 绕碰撞箱中心转, 身体就不会整体"沉下去"
			return new Vec3(0.0D, e.getBbHeight() / 2.0D, 0.0D);
		}
		return Vec3.ZERO;
	}

	private static Vec3 realWorldVelocity(Entity e, HxgGravity.G oldG) {
		if (e.isControlledByLocalInstance())
			return new Vec3(e.getX() - e.xo, e.getY() - e.yo, e.getZ() - e.zo);
		return HxgGravity.l2w(oldG, e.getDeltaMovement());
	}

	/** 位置/上一刻位置/速度 一起按新重力重算; 客户端还会起一段过渡动画 */
	public static void change(Entity e, HxgGravity.G oldG, HxgGravity.G newG, boolean animate) {
		if (e == null)
			return;
		boolean oldVanilla = oldG == null || oldG.vanilla;
		boolean newVanilla = newG == null || newG.vanilla;
		if (oldVanilla && newVanilla)
			return; // 原版 <-> 原版(只改了强度): 位置一格都不用动

		// 1) 箱子先按新重力重算(原版 makeBoundingBox 会被 mixin 接手)
		refreshBox(e);

		// 2) 绕旋转中心把位置转过去, 上一刻位置一起挪(否则这一帧的速度会被算成"瞬移")
		Vec3 center = rotationCenter(e, oldG, newG);
		Vec3 oldPos = e.position();
		Vec3 pivot = oldPos.add(HxgGravity.l2w(oldG, center));
		Vec3 newPos = pivot.subtract(HxgGravity.l2w(newG, center));
		Vec3 move = newPos.subtract(oldPos);
		if (move.lengthSqr() > 1.0E-12D) {
			e.setPos(newPos);
			e.xo += move.x;
			e.yo += move.y;
			e.zo += move.z;
			e.xOld += move.x;
			e.yOld += move.y;
			e.zOld += move.z;
		}
		e.fallDistance = 0.0F;

		// 3) 卡进方块里的话沿"旧的上"推出去, 再把剩下的重合按"最浅的一根轴"挪干净
		pushOut(e, oldG);
		unstick(e, newG);

		// 4) 速度按新坐标系重算(世界速度守恒, 于是看着像"世界没动、坐标系转了")
		Vec3 v = realWorldVelocity(e, oldG);
		e.setDeltaMovement(HxgGravity.w2l(newG, v));
		e.hurtMarked = true;

		// 5) 客户端: 起一段过渡动画
		if (e.level() != null && e.level().isClientSide()) {
			HxgGravityAnim.start(e, newG, oldG, ANIM_MS, nowMs(e), true, center);
			snapCam = true;
		}
	}

	private static void refreshBox(Entity e) {
		try {
			e.refreshDimensions();
		} catch (Throwable t) {
			// 有些实体在构造期/被移除时不让刷; 忽略, 下一 tick 的 makeBoundingBox 会兜住
		}
	}

	/**
	 * 沿"旧的上"把实体从方块里推出来(换重力后别卡墙). 只处理"压在脚下方块里"的那部分 ——
	 * 并集的取法见下面, 这一条是"被挤到方块上方"的根治点.
	 */
	private static void pushOut(Entity e, HxgGravity.G oldG) {
		try {
			if (e instanceof net.minecraft.world.entity.AreaEffectCloud
					|| e instanceof net.minecraft.world.entity.projectile.AbstractArrow)
				return;
			Vec3 up = oldG == null ? new Vec3(0.0D, 1.0D, 0.0D) : new Vec3(-oldG.x, -oldG.y, -oldG.z);
			Direction md = Direction.getNearest(up.x, up.y, up.z);
			if (md == null)
				return;
			AABB box = e.getBoundingBox().inflate(-0.01D);
			List<VoxelShape> shapes = new ArrayList<>();
			for (VoxelShape s : e.level().getCollisions(e, box))
				if (!s.isEmpty())
					shapes.add(s);
			AABB b = e.getBoundingBox();
			Direction.Axis axis = md.getAxis();
			boolean positive = md.getAxisDirection() == Direction.AxisDirection.POSITIVE;
			double mid = (b.min(axis) + b.max(axis)) / 2.0D;
			// 只把"整个都在推的那一侧"的方块并进来: 换重力那一下真正要处理的, 是箱子压进了脚下方块
			// (支撑面)里, 沿"旧的上"把它抬出来. 可箱子摆成新姿态后往往同时罩住墙/柱子/天花板, 若把
			// 它们的顶面也并进来, 偏移量就得从"箱子的底面"量起 —— 于是实体被整个抬到那些方块的顶上,
			// 也就是那条"被挤到方块上方". 越过箱子中线的方块不参与并集: 那部分重合交给原版自己的
			// 碰撞去解(往外走本来就不挡).
			AABB union = null;
			for (VoxelShape s : shapes) {
				AABB sb = s.bounds();
				if (positive ? sb.max(axis) > mid : sb.min(axis) < mid)
					continue;
				union = union == null ? sb : union.minmax(sb);
			}
			if (union == null)
				return;
			double offset = 0.0D;
			if (positive) {
				double pushing = union.max(axis);
				double pushed = b.min(axis);
				if (pushing > pushed)
					offset = pushing - pushed;
			} else {
				double pushing = union.min(axis);
				double pushed = b.max(axis);
				if (pushing < pushed)
					offset = pushed - pushing;
			}
			if (offset > 0.0D)
				e.setPos(e.position().add(Vec3.atLowerCornerOf(md.getNormal()).scale(offset)));
		} catch (Throwable t) {
			// 推不出来就算了, 别把 tick 弄崩
		}
	}

	/**
	 * 把"换完姿态之后仍然插在方块里"的那一份挪出来 —— 就是"把实体挪挪位置, 别让碰撞箱卡进方块".
	 *
	 * 上面那条 pushOut 只管"压在脚下方块里"的那一份(沿旧的上抬出来). 可换向时箱子是绕着实体位置
	 * 转过去的: 侧躺那一下, 原来 0.6×1.8×0.6 的竖箱子会变成沿世界轴横躺 1.8 格的箱子, 于是有一整段
	 * 捅进旁边的墙/柱子/天花板里 —— 而原版碰撞只在 move() 里解算, 不 move 就永远不解, 表现就是
	 * "人卡在方块里"(第一人称的相机本来就在箱子内部, 于是跟着一起埋进方块).
	 *
	 * 做法: 反复问"现在箱子和哪些方块真的重合", 每一轮挑**穿透最浅的那一根轴**挪出去(平手时优先沿
	 * 新重力的"上"抬, 也就是正常站上去), 最多 8 轮. 取最浅的那一根是为了挪得最少; 每轮都重新算,
	 * 所以挪完又蹭到别的东西也会被下一轮收拾. 挪不动(整段都在方块里)就放弃, 交给原版碰撞去解.
	 */
	private static void unstick(Entity e, HxgGravity.G newG) {
		try {
			if (e.level() == null)
				return;
			if (e instanceof net.minecraft.world.entity.AreaEffectCloud
					|| e instanceof net.minecraft.world.entity.projectile.AbstractArrow)
				return;
			// 平手时优先沿新重力的"上"抬(那才是"站上去"); 取最近的那根世界轴
			Direction up = newG == null ? Direction.UP : Direction.getNearest(-newG.x, -newG.y, -newG.z);
			Direction[] dirs = new Direction[6];
			dirs[0] = up;
			int n = 1;
			for (Direction d : new Direction[] { Direction.UP, Direction.DOWN, Direction.NORTH, Direction.SOUTH,
					Direction.WEST, Direction.EAST }) {
				if (d != up)
					dirs[n++] = d;
			}
			for (int pass = 0; pass < 8; pass++) {
				AABB b = e.getBoundingBox();
				// 只认"真的插进去"的重合: 贴面(浮点误差)不算, 否则每轮都会白挪一点
				AABB probe = b.inflate(-1.0E-4D);
				if (probe.getXsize() <= 0.0D || probe.getYsize() <= 0.0D || probe.getZsize() <= 0.0D)
					return;
				Direction best = null;
				double bestPen = Double.MAX_VALUE;
				for (VoxelShape s : e.level().getBlockCollisions(e, probe)) {
					if (s.isEmpty())
						continue;
					AABB sb = s.bounds();
					for (int i = 0; i < dirs.length; i++) {
						double pen = penetration(b, sb, dirs[i]);
						if (pen > 1.0E-4D && pen < bestPen) {
							bestPen = pen;
							best = dirs[i];
						}
					}
				}
				if (best == null)
					return;
				e.setPos(e.position().add(Vec3.atLowerCornerOf(best.getNormal()).scale(bestPen + 1.0E-3D)));
			}
		} catch (Throwable t) {
			// 挪不出来就算了, 别把 tick 弄崩
		}
	}

	/**
	 * 沿 d 把箱子 b 挪出方块 s 需要多长(先要求"另外两根轴也真的重合", 否则这个方向推了也解不开).
	 * 不重合(或已经分开)时返回负数.
	 */
	private static double penetration(AABB b, AABB s, Direction d) {
		Direction.Axis axis = d.getAxis();
		if (axis == Direction.Axis.Y) {
			if (!rangesOverlap(b.minX, b.maxX, s.minX, s.maxX) || !rangesOverlap(b.minZ, b.maxZ, s.minZ, s.maxZ))
				return -1.0D;
		} else if (axis == Direction.Axis.Z) {
			if (!rangesOverlap(b.minX, b.maxX, s.minX, s.maxX) || !rangesOverlap(b.minY, b.maxY, s.minY, s.maxY))
				return -1.0D;
		} else {
			if (!rangesOverlap(b.minY, b.maxY, s.minY, s.maxY) || !rangesOverlap(b.minZ, b.maxZ, s.minZ, s.maxZ))
				return -1.0D;
		}
		if (d.getAxisDirection() == Direction.AxisDirection.POSITIVE)
			return s.max(axis) - b.min(axis);
		return b.max(axis) - s.min(axis);
	}

	/** 两根区间有没有"真的"重合(贴面不算) */
	private static boolean rangesOverlap(double a0, double a1, double b0, double b1) {
		return Math.min(a1, b1) - Math.max(a0, b0) > 1.0E-4D;
	}

	private static long nowMs(Entity e) {
		try {
			return e.level().getGameTime() * 50L;
		} catch (Throwable t) {
			return System.currentTimeMillis();
		}
	}

	// ===== 持久化(跟着存档走: 区块重载/跨维度/服务器重启都能接上) =====

	private static void save(Entity e, HxgGravity.G g) {
		CompoundTag t = new CompoundTag();
		t.putDouble("x", g.x);
		t.putDouble("y", g.y);
		t.putDouble("z", g.z);
		t.putDouble("s", g.strength);
		t.putDouble("oa", g.oldAttr);
		t.putBoolean("ng", g.oldNoGravity);
		e.getPersistentData().put(KEY, t);
	}

	private static HxgGravity.G load(Entity e) {
		CompoundTag t = e.getPersistentData().getCompound(KEY);
		if (t == null || !t.contains("x"))
			return null;
		double x = t.getDouble("x"), y = t.getDouble("y"), z = t.getDouble("z");
		double len = Math.sqrt(x * x + y * y + z * z);
		if (len < 1.0E-6D)
			return null;
		return make(e, x / len, y / len, z / len, t.getDouble("s"), null,
				t.contains("oa") ? t.getDouble("oa") : Double.NaN, t.contains("ng") ? t.getBoolean("ng") : null);
	}

	// ===== 服务端每刻: 维持 + 心跳 =====

	public static void onLevelTick(net.minecraftforge.event.TickEvent.LevelTickEvent event) {
		if (event.phase != net.minecraftforge.event.TickEvent.Phase.END)
			return;
		Level level = event.level;
		if (!(level instanceof ServerLevel))
			return;
		for (Entity e : new ArrayList<>(HxgGravity.serverKeys())) {
			HxgGravity.G g = HxgGravity.ofServer(e);
			if (g == null)
				continue;
			if (e.level() != level)
				continue;
			if (e.isRemoved()) {
				HxgGravity.removeServer(e);
				continue;
			}
			if (!e.isAlive()) {
				reset(e);
				continue;
			}
			apply(e, g);
			if (level.getGameTime() % 20L == 0L)
				bcast(e, g.x, g.y, g.z, g.strength, false);
			if (e instanceof LivingEntity)
				continue; // 生命体: 大小交给重力属性, 方向交给坐标系
			if (g.oldNoGravity)
				continue;
			// 非生命体: 每刻沿重力方向补一份加速度(重力坐标系里就是 -Y, 所以直接减 y)
			Vec3 v = e.getDeltaMovement();
			e.setDeltaMovement(v.x, v.y - BASE_G * g.strength, v.z);
			e.hurtMarked = true;
		}
	}

	/** 实体从存档读回来(区块重载/跨维度/重启): 身上还记着重力就自动接上 */
	public static void onEntityJoin(net.minecraftforge.event.entity.EntityJoinLevelEvent event) {
		Entity e = event.getEntity();
		if (e == null || !(e.level() instanceof ServerLevel) || HxgGravity.ofServer(e) != null)
			return;
		HxgGravity.G g = load(e);
		if (g == null)
			return;
		HxgGravity.putServer(e, g);
		apply(e, g);
		bcast(e, g.x, g.y, g.z, g.strength, false);
	}

	// ===== 同步: 服务端 -> 同维度所有玩家 =====

	private static void bcast(Entity e, double x, double y, double z, double s, boolean anim) {
		if (CH == null || e == null || !(e.level() instanceof ServerLevel sl))
			return;
		for (ServerPlayer p : sl.players())
			CH.send(net.minecraftforge.network.PacketDistributor.PLAYER.with(() -> p), new Msg(e.getId(), x, y, z, s, anim));
	}

	/** 收到服务端广播: 记下来(0 0 0 = 恢复原版), 并让客户端自己算一遍同样的位置改动 + 起动画 */
	public static void recv(int id, double x, double y, double z, double s, boolean anim) {
		net.minecraft.client.multiplayer.ClientLevel cl = net.minecraft.client.Minecraft.getInstance().level;
		if (cl == null)
			return;
		Entity e = cl.getEntity(id);
		HxgGravity.G old = HxgGravity.ofClient(id);
		boolean zero = x == 0.0D && y == 0.0D && z == 0.0D;
		if (zero) {
			HxgGravity.removeClient(id);
			// 这里**不要**先 HxgGravityAnim.remove(id): change() 要拿上一段动画的中间值当新动画的起点
			// (连着换两次重力时, 第二段才不会从"上一段的目标"跳一下). 实体不在场时才清掉, 免得泄漏.
			if (e != null)
				change(e, old, null, anim);
			else
				HxgGravityAnim.remove(id);
			return;
		}
		double len = Math.sqrt(x * x + y * y + z * z);
		if (len < 1.0E-6D)
			return;
		HxgGravity.G g = make(e, x / len, y / len, z / len, s, old);
		HxgGravity.putClient(id, g);
		// old == null 表示"客户端此前记的是原版重力"(默认重力下换过去就是这一档): 也要照常走一遍
		// 位置改动 + 起过渡动画, 否则从默认重力切过去 / 恢复默认重力这两档会一下跳到位.
		if (e != null && anim && (old == null || old.x != g.x || old.y != g.y || old.z != g.z))
			change(e, old, g, true);
		else
			snapCam = true;
	}

	public static class Msg {
		private final int id;
		private final double x, y, z, s;
		private final boolean anim;

		public Msg(int id, double x, double y, double z, double s, boolean anim) {
			this.id = id;
			this.x = x;
			this.y = y;
			this.z = z;
			this.s = s;
			this.anim = anim;
		}

		public static void encode(Msg m, net.minecraft.network.FriendlyByteBuf b) {
			b.writeVarInt(m.id);
			b.writeDouble(m.x);
			b.writeDouble(m.y);
			b.writeDouble(m.z);
			b.writeDouble(m.s);
			b.writeBoolean(m.anim);
		}

		public Msg(net.minecraft.network.FriendlyByteBuf b) {
			this.id = b.readVarInt();
			this.x = b.readDouble();
			this.y = b.readDouble();
			this.z = b.readDouble();
			this.s = b.readDouble();
			this.anim = b.readBoolean();
		}

		public void handle(Supplier<net.minecraftforge.network.NetworkEvent.Context> ctx) {
			net.minecraftforge.network.NetworkEvent.Context c = ctx.get();
			c.enqueueWork(() -> recv(id, x, y, z, s, anim));
			c.setPacketHandled(true);
		}
	}
}
