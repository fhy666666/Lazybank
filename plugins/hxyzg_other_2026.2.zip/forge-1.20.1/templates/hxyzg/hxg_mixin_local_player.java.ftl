package ${package}.mixin;

/*
 * 本地玩家这一层的重力改造: 把原版"把卡在方块里的玩家顶出去"的那套搬进重力坐标系.
 *
 * 原版 LocalPlayer.aiStep 每刻拿碰撞箱的四个角调 4 次 moveTowardsClosestSpace(x, z):
 * 它先在"玩家自己所在的那一格"上判一次"会不会窒息"(suffocatesAt), 一旦成立就挑一个最近的
 * 水平方向, 把 deltaMovement 整个换成 0.1 —— 也就是"把卡进方块里的玩家顶出去".
 *
 * 这两个方法整套都按"世界轴 = 身体轴"写:
 *   - moveTowardsClosestSpace 的方向候选只有世界水平的 WEST/EAST/NORTH/SOUTH, 没有 UP/DOWN;
 *   - suffocatesAt 拿玩家的 minY..maxY 去配方块那一格的 X/Z —— 只有"世界 Y 就是身体的上"时才成立.
 * 重力一旦不是原版的 (0,-1,0)(尤其是侧躺), 支撑面就落在玩家的侧面: 采样格正好是玩家踩着的那块
 * 方块, suffocatesAt 于是恒为真, 每刻都把玩家的水平速度整个改写成 0.1 格/刻 ⇒ 站在方块上不能
 * 正常行走, 而且一直被方块挤走(这就是"被方块挤走"的来源).
 *
 * 修法与参考实现(GravityChanger 的 ClientPlayerEntityMixin)同一套几何:
 *   - 采样点按"身体平面"解释, 方向候选取重力坐标系里的 WEST/EAST/NORTH/SOUTH 再换回世界;
 *   - "会不会窒息"用重力感知的箱子: 沿身体上方向那一根**世界轴**取玩家箱子的范围,
 *     另外两根轴取方块那一格(这正是原版那个箱子在重力坐标系里的意思).
 * 原版重力下第一行就返回, 一格都不碰(与装插件之前逐位一致).
 */

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import ${package}.gravity.HxgGravity;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

@Mixin(LocalPlayer.class)
public abstract class HxgLocalPlayerMixin {
	@Inject(method = "moveTowardsClosestSpace(DD)V", at = @At("HEAD"), cancellable = true)
	private void hxg$pushOut(double x, double z, CallbackInfo ci) {
		Entity self = (Entity) (Object) this;
		HxgGravity.G g = HxgGravity.of(self);
		if (g == null || g.vanilla)
			return;
		ci.cancel();
		// 采样点 x/z 是碰撞箱"四个角"的位置; 当成身体平面里的偏移换到世界, 再落到方块坐标上
		Vec3 p = HxgGravity.l2w(g, x - self.getX(), 0.0D, z - self.getZ()).add(self.position());
		BlockPos bp = BlockPos.containing(p);
		if (!hxg$suffocates(self, g, bp))
			return;
		double dx = p.x - (double) bp.getX();
		double dy = p.y - (double) bp.getY();
		double dz = p.z - (double) bp.getZ();
		Direction dir = null;
		double best = Double.MAX_VALUE;
		for (Direction ld : new Direction[] { Direction.WEST, Direction.EAST, Direction.NORTH, Direction.SOUTH }) {
			Direction wd = HxgGravity.dirL2W(g, ld);
			double c = wd.getAxis().choose(dx, dy, dz);
			double edge = wd.getAxisDirection() == Direction.AxisDirection.POSITIVE ? 1.0D - c : c;
			if (edge < best && !hxg$suffocates(self, g, bp.relative(wd))) {
				best = edge;
				dir = ld;
			}
		}
		if (dir == null)
			return;
		// 速度存的是重力坐标系里的量, 所以推的也是重力坐标系里的那一根水平轴
		Vec3 v = self.getDeltaMovement();
		if (dir.getAxis() == Direction.Axis.X)
			self.setDeltaMovement(0.1D * (double) dir.getStepX(), v.y, v.z);
		else if (dir.getAxis() == Direction.Axis.Z)
			self.setDeltaMovement(v.x, v.y, 0.1D * (double) dir.getStepZ());
	}

	/**
	 * 重力感知版的"这一格会不会窒息": 沿身体上方向那一根世界轴取玩家箱子的范围, 另外两根轴取方块那一格.
	 * 原版那个箱子(方块格的 X/Z + 玩家的 minY..maxY)只在"世界 Y 就是身体的上"时才与它等价.
	 */
	private static boolean hxg$suffocates(Entity self, HxgGravity.G g, BlockPos pos) {
		AABB bb = self.getBoundingBox();
		Direction up = Direction.getNearest(-g.x, -g.y, -g.z);
		double x0 = (double) pos.getX();
		double y0 = (double) pos.getY();
		double z0 = (double) pos.getZ();
		AABB region;
		if (up.getAxis() == Direction.Axis.Y) {
			region = new AABB(x0, bb.minY, z0, x0 + 1.0D, bb.maxY, z0 + 1.0D);
		} else if (up.getAxis() == Direction.Axis.X) {
			region = new AABB(bb.minX, y0, z0, bb.maxX, y0 + 1.0D, z0 + 1.0D);
		} else {
			region = new AABB(x0, y0, bb.minZ, x0 + 1.0D, y0 + 1.0D, bb.maxZ);
		}
		return self.level().collidesWithSuffocatingBlock(self, region.deflate(1.0E-7D));
	}
}
