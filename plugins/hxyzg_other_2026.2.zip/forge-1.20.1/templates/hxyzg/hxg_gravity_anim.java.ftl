package ${package}.gravity;

/*
 * 换重力时的过渡动画(客户端): 把"画面的世界旋转"从一个四元数线性地转到另一个, 于是画面是"转过去"的,
 * 而不是一下跳过去. 做法与成熟实现一致:
 *   1) 换方向时先把实体的 yaw/pitch 改成"用新重力看同一个世界方向"需要的角度(所以视线方向不会跳);
 *   2) 再反推出一个"等效的起点旋转", 让它跟这一刻画面上的样子一致, 然后从这里 slerp 到新重力的旋转.
 * 所以动画期间实体角度已经是终值了, 只有画面的旋转还在路上 —— 这也让相机不会跟实体打架.
 */

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.joml.Quaternionf;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;

public final class HxgGravityAnim {
	private HxgGravityAnim() {
	}

	/** 一段时间 ms 的过渡 */
	public static final class A {
		public boolean inAnimation = false;
		public Quaternionf startRot = new Quaternionf();
		public Quaternionf endRot = new Quaternionf();
		/** 相对旋转中心(重力坐标系里); 零 = 绕实体位置转 */
		public Vec3 center = Vec3.ZERO;
		public long startMs = 0L;
		public long endMs = 0L;

		public void update(long timeMs) {
			if (timeMs > endMs)
				inAnimation = false;
		}
	}

	private static final Map<Integer, A> ANIM = new ConcurrentHashMap<>();

	/** 现在是什么时刻(毫秒): 用实体所在世界的时间 * 50 + 帧内插值, 这样动画与游戏时间同步 */
	public static long timeMs(Entity e, float partial) {
		try {
			return e.level().getGameTime() * 50L + (long) ((double) partial * 50.0D);
		} catch (Throwable t) {
			return System.currentTimeMillis();
		}
	}

	public static A of(int id) {
		return ANIM.get(Integer.valueOf(id));
	}

	public static A of(Entity e) {
		return e == null ? null : ANIM.get(Integer.valueOf(e.getId()));
	}

	public static void remove(int id) {
		ANIM.remove(Integer.valueOf(id));
	}

	/** 现在的"世界旋转"(即 view 前面要乘的那个); g 为空 = 原版 */
	public static Quaternionf worldRotOf(HxgGravity.G g) {
		return g == null ? new Quaternionf() : new Quaternionf(g.w2l);
	}

	/** 画面这一刻该用的世界旋转(有动画就是插值出来的) */
	public static Quaternionf renderRot(Entity e, HxgGravity.G g, long timeMs) {
		A a = of(e);
		Quaternionf target = worldRotOf(g);
		if (a == null || !a.inAnimation)
			return target;
		return current(a, timeMs);
	}

	/**
	 * 现在有没有在跑的过渡动画.
	 *
	 * **故意不改状态**: 模型的 push/pop 是两次独立调用, 必须拿到同一个答案; 而 current()/update()
	 * 会把已经过期的动画就地标成结束, 两次调用就可能一次说"在动画"、一次说"不在", push 了却没 pop.
	 * 另外这也是"从默认重力换过去 / 恢复默认重力"那两档能播动画的关键: 那两档里 g 是空的(或 vanilla),
	 * 只看 HxgGravity 的话会把它当成"原版、什么都不用做", 动画就被吃掉了.
	 */
	public static boolean animating(Entity e, long timeMs) {
		A a = of(e);
		return a != null && a.inAnimation && timeMs <= a.endMs;
	}

	/** 一份重力的"下"方向(空 = 原版向下) */
	private static Vec3 downOf(HxgGravity.G g) {
		return g == null ? new Vec3(0.0D, -1.0D, 0.0D) : new Vec3(g.x, g.y, g.z);
	}

	public static Quaternionf current(A a, long timeMs) {
		a.update(timeMs);
		if (!a.inAnimation)
			return new Quaternionf(a.endRot);
		double d = (double) (timeMs - a.startMs) / (double) (a.endMs - a.startMs);
		return new Quaternionf(a.startRot).slerp(a.endRot, (float) mapProgress((float) d));
	}

	private static float mapProgress(float delta) {
		float d = delta < 0.0F ? 0.0F : (delta > 1.0F ? 1.0F : delta);
		return d * d * (3.0F - 2.0F * d);
	}

	/**
	 * 起一段过渡.
	 *
	 * @param entity     换重力的实体
	 * @param newG       新的重力(已经生效, 用它换算)
	 * @param oldG       旧的重力(可能为空 = 原版向下)
	 * @param durationMs 时长
	 * @param timeMs     现在(毫秒; 用实体世界时间 * 50 + 帧内插值)
	 * @param rotateView 视线方向要不要跟着重力一起转过去(通常要)
	 * @param center     相对旋转中心(重力坐标系里)
	 */
	public static void start(Entity entity, HxgGravity.G newG, HxgGravity.G oldG, int durationMs, long timeMs,
			boolean rotateView, Vec3 center) {
		if (entity == null)
			return;
		int id = entity.getId();
		if (durationMs <= 0) {
			ANIM.remove(Integer.valueOf(id));
			return;
		}

		// 换完之后要看的那个世界方向
		Vec3 oldLook = HxgGravity.l2w(oldG, HxgGravity.viewVec(entity.getYRot(), entity.getXRot()));
		Vec3 newLook;
		Vec3 od = downOf(oldG);
		Vec3 nd = downOf(newG);
		if (!rotateView) {
			newLook = oldLook;
		} else if (od.x == -nd.x && od.y == -nd.y && od.z == -nd.z) {
			// 正好反向: 最短弧有无数解, 直接按"朝反方向看"处理(与参考实现一致).
			// 注意 oldG/newG 有一个是空(原版)时也要走这一档 —— "重力颠倒 -> 恢复默认" 就是正好反向.
			newLook = oldLook.scale(-1.0D);
		} else {
			Quaternionf delta = HxgGravity.rotBetween(od, nd);
			newLook = HxgGravity.rot(oldLook.x, oldLook.y, oldLook.z, delta);
		}

		// 这一刻画面上的相机旋转 = 当前角度 * 当前(可能还在动画中的)重力旋转
		Quaternionf oldView = HxgGravity.viewRot(entity.getXRot(), entity.getYRot());
		A old = ANIM.get(Integer.valueOf(id));
		Quaternionf curRot = (old != null && old.inAnimation) ? current(old, timeMs) : worldRotOf(oldG);
		Quaternionf curCam = new Quaternionf(oldView).mul(curRot);

		// 把角度改成"用新重力看 newLook"需要的角度(视线一点不跳)
		Vec2 np = HxgGravity.viewAngles(HxgGravity.w2l(newG, newLook));
		float dYaw = np.x - entity.getYRot();
		float dPitch = np.y - entity.getXRot();
		entity.setYRot(entity.getYRot() + dYaw);
		entity.setXRot(entity.getXRot() + dPitch);
		entity.yRotO += dYaw;
		entity.xRotO += dPitch;
		if (entity instanceof LivingEntity le) {
			le.yBodyRot += dYaw;
			le.yBodyRotO += dYaw;
			le.yHeadRot += dYaw;
			le.yHeadRotO += dYaw;
		}

		// 起点旋转: 让画面保持现在这个样子
		Quaternionf newView = HxgGravity.viewRot(entity.getXRot(), entity.getYRot());
		Quaternionf startRot = new Quaternionf(newView).conjugate().mul(curCam);

		A a = old == null ? new A() : old;
		a.startRot = startRot;
		a.endRot = worldRotOf(newG);
		a.center = center == null ? Vec3.ZERO : center;
		a.startMs = timeMs;
		a.endMs = timeMs + durationMs;
		a.inAnimation = true;
		ANIM.put(Integer.valueOf(id), a);
	}

	/** 眼睛位置该怎么偏移: 把"身体坐标系里的 (0, eyeHeight, 0)"转到世界, 带旋转中心处理 */
	public static Vec3 eyeOffset(A a, Quaternionf gravityRot, Vec3 localEye, HxgGravity.G newG) {
		Quaternionf l2w = new Quaternionf(gravityRot).conjugate();
		if (a == null || !a.inAnimation || a.center.equals(Vec3.ZERO))
			return HxgGravity.rot(localEye.x, localEye.y, localEye.z, l2w);

		Vec3 centerWorld = HxgGravity.l2w(newG, a.center);
		Vec3 rel = localEye.subtract(a.center);
		Vec3 rotated = HxgGravity.rot(rel.x, rel.y, rel.z, l2w);
		return centerWorld.add(rotated);
	}
}
