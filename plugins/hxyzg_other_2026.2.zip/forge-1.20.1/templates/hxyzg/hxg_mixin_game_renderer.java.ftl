package ${package}.mixin;

/*
 * 世界画面: 1.20.1 的 GameRenderer 是用三个 Axis 旋转拼出世界矩阵的
 * (先 roll, 再 pitch, 最后 yaw+180), 所以"世界旋转"必须在最后一个旋转之后乘进去.
 * 注入点就是 renderLevel 里第 5 个 PoseStack.mulPose(Quaternionf) —— 前面两个是反胃效果的旋转,
 * 第 3/4/5 个分别是 roll / pitch / yaw + 180.
 *
 * 换重力时乘的是过渡动画插值出来的那个旋转.
 */

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.mojang.blaze3d.vertex.PoseStack;

import ${package}.gravity.HxgGravity;
import ${package}.gravity.HxgGravityAnim;

import net.minecraft.client.Camera;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.entity.Entity;

@Mixin(GameRenderer.class)
public abstract class HxgGameRendererMixin {
	@Shadow
	@Final
	private Camera mainCamera;

	@Inject(method = "renderLevel(FJLcom/mojang/blaze3d/vertex/PoseStack;)V", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;mulPose(Lorg/joml/Quaternionf;)V", ordinal = 4, shift = At.Shift.AFTER))
	private void hxg$worldRot(float partialTick, long nanoTime, PoseStack pose, CallbackInfo ci) {
		Entity e = this.mainCamera.getEntity();
		if (e == null)
			return;
		HxgGravity.G g = HxgGravity.of(e);
		long timeMs = HxgGravityAnim.timeMs(e, partialTick);
		// "恢复默认重力"那一档 g 已经是空的, 但动画还在跑: 这时候也得把世界转回去, 否则画面会一下跳正
		if ((g == null || g.vanilla) && !HxgGravityAnim.animating(e, timeMs))
			return;
		pose.mulPose(HxgGravityAnim.renderRot(e, g, timeMs));
	}
}
