package ${package}.gravity;

/*
 * 重力工具的核心(参照成熟实现 GravityChanger 的做法重做).
 *
 * 关键思想: 把"速度"和"朝向角度"全都当成**重力坐标系**里的量, 方向沿重力方向的那根轴
 * 就是重力坐标系里的 -Y. 于是原版的 travel()/摩擦/跳跃/游泳/鞘翅 一行都不用改, 它们本来就
 * 是按"上 = +Y"写的, 现在是按"上 = 身体的上"在算. 我们要做的只有两件事:
 *   1) 世界 -> 重力坐标系 / 重力坐标系 -> 世界 的换算(本类);
 *   2) 在那些"拿世界轴当上"的原版逻辑里把这套换算接上去(见 mixin 包).
 *
 * 6 个轴方向走的是"整数置换", 与参考实现逐位一致(所以上下前后左右这 6 档手感/几何完全一致);
 * 其它方向走四元数旋转, 盒子取"旋转后的盒子的世界轴向包围盒".
 */

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.joml.Quaternionf;
import org.joml.Vector3f;

import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

public final class HxgGravity {
	private HxgGravity() {
	}

	private static final float R90 = (float) Math.toRadians(-90.0D);
	private static final float R180 = (float) Math.toRadians(-180.0D);
	private static final float R270 = (float) Math.toRadians(-270.0D);

	/** 一份重力: 方向(单位向量, 指向"下"), 强度倍数, 预先算好的四元数, 以及恢复时要还回去的原状. */
	public static final class G {
		public final double x, y, z;
		public final double strength;
		/** 世界 -> 重力坐标系(把重力方向转到 (0,-1,0)) */
		public final Quaternionf w2l;
		/** 重力坐标系 -> 世界 */
		public final Quaternionf l2w;
		/** 方向就是原版的 (0,-1,0): 所有换算都返回原值, 一格都不碰 */
		public final boolean vanilla;
		/** 方向正好落在 6 个轴上: 盒子与碰撞走整数置换(精确) */
		public final boolean axis;
		/** 轴方向时是哪一根(axis 为假时是最近的那一根) */
		public final Direction dir;
		/** 设重力之前这个实体的重力属性基础值(恢复时还回去) */
		public final double oldAttr;
		/** 设重力之前是不是 noGravity */
		public final boolean oldNoGravity;

		G(double x, double y, double z, double strength, Quaternionf w2l, boolean vanilla, boolean axis, Direction dir,
				double oldAttr, boolean oldNoGravity) {
			this.x = x;
			this.y = y;
			this.z = z;
			this.strength = strength;
			this.w2l = w2l;
			this.l2w = new Quaternionf(w2l).conjugate();
			this.vanilla = vanilla;
			this.axis = axis;
			this.dir = dir;
			this.oldAttr = oldAttr;
			this.oldNoGravity = oldNoGravity;
		}
	}

	/** 服务端那份(权威): 实体 -> 重力 */
	private static final Map<Entity, G> SRV = new ConcurrentHashMap<>();
	/** 客户端那份(只用于画面/客户端物理): 实体 id -> 重力 */
	private static final Map<Integer, G> CLI = new ConcurrentHashMap<>();

	/**
	 * 快路径开关: 一个实体都没设过重力时, 所有钩子第一行就返回. 混入的钩子跑在原版最热的路径上
	 * (每刻每实体好几次), 所以这次 volatile 读就是全部开销.
	 */
	public static volatile boolean any = false;

	private static void refresh() {
		any = !SRV.isEmpty() || !CLI.isEmpty();
	}

	/** 查这个实体的重力(按当前是哪一侧选表); 没设过返回 null */
	public static G of(Entity e) {
		if (e == null || !any)
			return null;
		Level lv = e.level();
		if (lv == null) // 实体还在构造里(构造期就会算碰撞箱), 这时候还没有世界
			return null;
		if (lv.isClientSide())
			return CLI.get(Integer.valueOf(e.getId()));
		return SRV.get(e);
	}

	/** 服务端那份(不按侧判断, 服务端自己用) */
	public static G ofServer(Entity e) {
		return e == null ? null : SRV.get(e);
	}

	/** 客户端那份 */
	public static G ofClient(int id) {
		return CLI.get(Integer.valueOf(id));
	}

	public static boolean has(Entity e) {
		if (e == null)
			return false;
		Level lv = e.level();
		if (lv != null && lv.isClientSide())
			return CLI.containsKey(Integer.valueOf(e.getId()));
		return SRV.containsKey(e);
	}

	public static void putServer(Entity e, G g) {
		SRV.put(e, g);
		refresh();
	}

	public static G removeServer(Entity e) {
		G g = SRV.remove(e);
		refresh();
		return g;
	}

	public static void putClient(int id, G g) {
		CLI.put(Integer.valueOf(id), g);
		refresh();
	}

	public static void removeClient(int id) {
		CLI.remove(Integer.valueOf(id));
		refresh();
	}

	public static java.util.Set<Entity> serverKeys() {
		return SRV.keySet();
	}

	// ===== 换算: 世界 <-> 重力坐标系 =====

	/** 6 个轴方向: 整数置换(与参考实现逐位一致, double 精确) */
	private static Vec3 permW2L(double x, double y, double z, Direction d) {
		switch (d) {
		case UP:
			return new Vec3(-x, -y, z);
		case NORTH:
			return new Vec3(x, z, -y);
		case SOUTH:
			return new Vec3(-x, -z, -y);
		case WEST:
			return new Vec3(-z, x, -y);
		case EAST:
			return new Vec3(z, -x, -y);
		case DOWN:
		default:
			return new Vec3(x, y, z);
		}
	}

	private static Vec3 permL2W(double x, double y, double z, Direction d) {
		switch (d) {
		case UP:
			return new Vec3(-x, -y, z);
		case NORTH:
			return new Vec3(x, -z, y);
		case SOUTH:
			return new Vec3(-x, -z, -y);
		case WEST:
			return new Vec3(y, -z, -x);
		case EAST:
			return new Vec3(-y, -z, x);
		case DOWN:
		default:
			return new Vec3(x, y, z);
		}
	}

	/** double 精度的四元数旋转(斜向重力用; float 会带来每刻约 1e-7 的抖动) */
	public static Vec3 rot(double x, double y, double z, Quaternionf q) {
		double qx = q.x, qy = q.y, qz = q.z, qw = q.w;
		double tx = 2.0D * (qy * z - qz * y);
		double ty = 2.0D * (qz * x - qx * z);
		double tz = 2.0D * (qx * y - qy * x);
		return new Vec3(x + qw * tx + (qy * tz - qz * ty), y + qw * ty + (qz * tx - qx * tz),
				z + qw * tz + (qx * ty - qy * tx));
	}

	/** 世界 -> 重力坐标系 */
	public static Vec3 w2l(G g, Vec3 v) {
		if (g == null || g.vanilla)
			return v;
		if (g.axis)
			return permW2L(v.x, v.y, v.z, g.dir);
		return rot(v.x, v.y, v.z, g.w2l);
	}

	public static Vec3 w2l(G g, double x, double y, double z) {
		if (g == null || g.vanilla)
			return new Vec3(x, y, z);
		if (g.axis)
			return permW2L(x, y, z, g.dir);
		return rot(x, y, z, g.w2l);
	}

	/** 重力坐标系 -> 世界 */
	public static Vec3 l2w(G g, Vec3 v) {
		if (g == null || g.vanilla)
			return v;
		if (g.axis)
			return permL2W(v.x, v.y, v.z, g.dir);
		return rot(v.x, v.y, v.z, g.l2w);
	}

	public static Vec3 l2w(G g, double x, double y, double z) {
		if (g == null || g.vanilla)
			return new Vec3(x, y, z);
		if (g.axis)
			return permL2W(x, y, z, g.dir);
		return rot(x, y, z, g.l2w);
	}

	/** 重力坐标系里的一根轴方向 -> 世界上最近的方向 */
	public static Direction dirL2W(G g, Direction d) {
		if (g == null || g.vanilla)
			return d;
		Vec3 v = l2w(g, Vec3.atLowerCornerOf(d.getNormal()));
		return Direction.getNearest(v.x, v.y, v.z);
	}

	/** 世界上的一根轴方向 -> 重力坐标系里最近的方向 */
	public static Direction dirW2L(G g, Direction d) {
		if (g == null || g.vanilla)
			return d;
		Vec3 v = w2l(g, Vec3.atLowerCornerOf(d.getNormal()));
		return Direction.getNearest(v.x, v.y, v.z);
	}

	/**
	 * 碰撞箱"脚"那一面往身体内侧收的距离(格).
	 *
	 * 原版所有碰撞解算都是按世界轴做的: 箱子一旦和"脚下方块"贴死, 甚至在浮点误差里压进去一点
	 * (重合), 那些拿世界 Y 当"上"的代码就会把它当成"卡在方块里", 再把实体整个挤出去 —— 表现出来
	 * 就是"实体被挤到方块上方". 这里给脚那一面留一个明确的空隙: 0.01 比引擎自己的浮点容差
	 * (AABB / VoxelShape / Shapes 一律用 1.0E-7) 大五个数量级, 足够摆脱这种判定, 又远小于一个
	 * 方块, 画面看不出沉下去. 只收脚这一面(头那一面不动), 免得头穿进天花板里.
	 */
	public static final double FOOT_GAP = 0.01D;

	/** 盒子: 重力坐标系 -> 世界 */
	public static AABB boxL2W(G g, AABB b) {
		if (g == null || g.vanilla)
			return b;
		if (g.axis) {
			Vec3 a = permL2W(b.minX, b.minY, b.minZ, g.dir);
			Vec3 c = permL2W(b.maxX, b.maxY, b.maxZ, g.dir);
			return new AABB(a, c);
		}
		return corners(b, g.l2w);
	}

	/** 盒子: 世界 -> 重力坐标系 */
	public static AABB boxW2L(G g, AABB b) {
		if (g == null || g.vanilla)
			return b;
		if (g.axis) {
			Vec3 a = permW2L(b.minX, b.minY, b.minZ, g.dir);
			Vec3 c = permW2L(b.maxX, b.maxY, b.maxZ, g.dir);
			return new AABB(a, c);
		}
		return corners(b, g.w2l);
	}

	/** 把盒子的 8 个角转过去, 取能包住它们的最小轴对齐盒子(斜向重力用) */
	private static AABB corners(AABB b, Quaternionf q) {
		double x0 = Double.MAX_VALUE, y0 = Double.MAX_VALUE, z0 = Double.MAX_VALUE;
		double x1 = -Double.MAX_VALUE, y1 = -Double.MAX_VALUE, z1 = -Double.MAX_VALUE;
		for (int i = 0; i < 8; i++) {
			Vec3 p = rot((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ, q);
			if (p.x < x0) x0 = p.x;
			if (p.y < y0) y0 = p.y;
			if (p.z < z0) z0 = p.z;
			if (p.x > x1) x1 = p.x;
			if (p.y > y1) y1 = p.y;
			if (p.z > z1) z1 = p.z;
		}
		return new AABB(x0, y0, z0, x1, y1, z1);
	}

	// ===== 由方向造一份重力 =====

	/** 6 个轴方向用参考实现那张表(保证逐位一致); 其它方向用"最短弧" */
	public static Quaternionf rotFor(Vec3 n) {
		Direction d = nearest(n, true);
		if (d == null)
			return new Quaternionf().rotationTo(new Vector3f((float) n.x, (float) n.y, (float) n.z), new Vector3f(0.0F, -1.0F, 0.0F));
		switch (d) {
		case UP:
			return new Quaternionf().rotationZ(R180);
		case NORTH:
			return new Quaternionf().rotationX(R90);
		case SOUTH:
			return new Quaternionf().rotationX(R90).rotateY(R180);
		case WEST:
			return new Quaternionf().rotationX(R90).rotateY(R90);
		case EAST:
			return new Quaternionf().rotationX(R90).rotateY(R270);
		case DOWN:
		default:
			return new Quaternionf();
		}
	}

	/** 单位化后是不是正好落在一根轴上; 是就返回那根轴, 否则返回 null */
	public static Direction nearest(Vec3 n, boolean strict) {
		for (Direction d : Direction.values()) {
			double dx = d.getStepX(), dy = d.getStepY(), dz = d.getStepZ();
			if (n.x * dx + n.y * dy + n.z * dz > (strict ? 0.999999D : 0.9999D))
				return d;
		}
		return null;
	}

	// ===== 视角用的两个小工具(过渡动画和相机共用) =====

	/** 原版视矩阵的那份旋转: Rx(pitch) * Ry(yaw + 180) */
	public static Quaternionf viewRot(float pitch, float yaw) {
		return new Quaternionf().rotationX((float) Math.toRadians(pitch)).rotateY((float) Math.toRadians(yaw + 180.0F));
	}

	/** yaw/pitch -> 视线方向(与原版 Vec3.directionFromRotation 一致) */
	public static Vec3 viewVec(float yaw, float pitch) {
		double rp = Math.toRadians(pitch);
		double ry = Math.toRadians(-yaw);
		double cp = Math.cos(rp);
		return new Vec3(Math.sin(ry) * cp, -Math.sin(rp), Math.cos(ry) * cp);
	}

	/** 视线方向 -> yaw/pitch(与 viewVec 互逆; 返回值 x = yaw, y = pitch) */
	public static net.minecraft.world.phys.Vec2 viewAngles(Vec3 v) {
		double sinPitch = -v.y;
		if (sinPitch > 1.0D)
			sinPitch = 1.0D;
		if (sinPitch < -1.0D)
			sinPitch = -1.0D;
		double radPitch = Math.asin(sinPitch);
		double cosPitch = Math.cos(radPitch);
		double radNegYaw;
		if (Math.abs(cosPitch) < 1.0E-9D) {
			radNegYaw = 0.0D;
		} else {
			double sinNegYaw = v.x / cosPitch;
			double cosNegYaw = Math.max(-1.0D, Math.min(1.0D, v.z / cosPitch));
			radNegYaw = Math.acos(cosNegYaw);
			if (sinNegYaw < 0.0D)
				radNegYaw = Math.PI * 2.0D - radNegYaw;
		}
		return new net.minecraft.world.phys.Vec2((float) Math.toDegrees(-radNegYaw), (float) Math.toDegrees(radPitch));
	}

	// ===== 第一人称的相机: 别落在方块里, 也别贴在方块面上 =====

	/**
	 * "相机贴到方块上了"的触发阈值(格): 相机点周围 EYE_MARGIN 内有方块的碰撞形状时才动它.
	 *
	 * 站得好好的时候这一档不会触发: 眼睛在重力坐标系里永远落在碰撞箱内部(离头那一面 0.18~0.2,
	 * 离四个侧面 0.3), 而箱子不会与方块重合 ⇒ 眼睛离最近的方块至少 0.18 格. 会贴到的只有三种时候:
	 *   1) 换重力那一下箱子转到新姿态时有一小块插进旁边的方块(`HxgGravityNet` 的 `unstick` 负责挪人,
	 *      挪不动的就留在这儿);
	 *   2) **换重力的过渡动画中间** —— 眼睛是绕"实体位置 / 箱子中心"转过去的, 中途会甩到箱子外面
	 *      (半径最大 1.62 格, 而身体半宽只有 0.3), 旁边正好有方块时整段动画都贴着 / 埋在方块里;
	 *   3) **四周都被方块包住**时换重力: 横过来的身体(局部 1.79 格长)塞不进那条缝, `unstick` 挪不动人,
	 *      箱子于是整段插在墙/地板里; 眼睛本来就在箱子内部(离头那一面才 0.17 格), 跟着一起埋进去.
	 */
	public static final double EYE_MARGIN = 0.08D;

	/**
	 * 相机点离方块碰撞形状的**最低可接受余量**(格).
	 *
	 * 只保证"眼睛不在方块里"是不够的: 原版 `GameRenderer` 的透视矩阵**近裁剪面是 0.05**, 相机离墙面
	 * 比这还近时那一面会被裁掉 —— 画面上就是"看穿了墙 / 像埋在方块内壁里". 0.07 比近裁剪面大一截,
	 * 又比"正常站着时眼睛到最近方块"的最小余量(0.18)小得多, 所以它只在相机真的贴上去时才起作用.
	 */
	public static final double EYE_MIN = 0.07D;

	/**
	 * 想把相机退到的**舒适余量**(格): 能办到就退到离方块这么远的地方再停.
	 *
	 * 2.62.8 只退到"最低余量"就停, 于是相机停在离墙面 0.08 格的位置上 —— 那一面墙的贴图照样糊满整个
	 * 画面, 看上去与"埋在方块里"没有区别(用户报的正是这个; `_test\eyeescape` 的输出里走廊那一档退到
	 * x = 0.087, 正好贴住 x = 0 那面墙). 一格宽的缝里也办得到 0.40(缝中心离两侧各 0.5), 所以这个目标
	 * 在"身体塞不进那条缝"的场合照样能达到.
	 */
	public static final double EYE_GOOD = 0.40D;

	/** 余量判定的档位(从大到小): 取第一个"这个半径内没有方块"的档位当余量值 */
	private static final double[] EYE_LADDER = { EYE_GOOD, 0.30D, 0.20D, 0.12D, EYE_MIN, 0.04D, 0.02D };
	/** 沿回退线采样时的步长(格) */
	private static final double EYE_LINE_STEP = 0.1D;
	/** 在候选点周围往外探时的步长(格)与最多步数(合起来 0.4 格) */
	private static final double EYE_STEP = 0.1D;
	private static final int EYE_REACH = 4;
	/** 一次兜底最多试多少个候选点(挡住"卡在很小的空腔里"时的开销; 到量就用手上最好的那个) */
	private static final int EYE_BUDGET = 300;
	/** 相机最多挪出去多远(格): 比"眼睛到脚"的距离(1.62)再留一点余量; 超过就不考虑(宁可不动也不乱甩) */
	private static final double EYE_MAX = 2.1D;
	/** "这个点在不在实心方块里"的探测半径: 贴面也算在里面, 免得把相机留在方块表面那一层上 */
	private static final double EYE_SOLID = 1.0E-4D;
	/** 往外探的方向: 6 根世界轴 + 12 个棱方向 + 8 个角方向(都归一化) */
	private static final Vec3[] EYE_DIRS = { new Vec3(1.0D, 0.0D, 0.0D), new Vec3(-1.0D, 0.0D, 0.0D),
			new Vec3(0.0D, 1.0D, 0.0D), new Vec3(0.0D, -1.0D, 0.0D), new Vec3(0.0D, 0.0D, 1.0D),
			new Vec3(0.0D, 0.0D, -1.0D), new Vec3(1.0D, 1.0D, 0.0D).normalize(),
			new Vec3(1.0D, -1.0D, 0.0D).normalize(), new Vec3(-1.0D, 1.0D, 0.0D).normalize(),
			new Vec3(-1.0D, -1.0D, 0.0D).normalize(), new Vec3(1.0D, 0.0D, 1.0D).normalize(),
			new Vec3(1.0D, 0.0D, -1.0D).normalize(), new Vec3(-1.0D, 0.0D, 1.0D).normalize(),
			new Vec3(-1.0D, 0.0D, -1.0D).normalize(), new Vec3(0.0D, 1.0D, 1.0D).normalize(),
			new Vec3(0.0D, 1.0D, -1.0D).normalize(), new Vec3(0.0D, -1.0D, 1.0D).normalize(),
			new Vec3(0.0D, -1.0D, -1.0D).normalize(), new Vec3(1.0D, 1.0D, 1.0D).normalize(),
			new Vec3(1.0D, 1.0D, -1.0D).normalize(), new Vec3(1.0D, -1.0D, 1.0D).normalize(),
			new Vec3(1.0D, -1.0D, -1.0D).normalize(), new Vec3(-1.0D, 1.0D, 1.0D).normalize(),
			new Vec3(-1.0D, 1.0D, -1.0D).normalize(), new Vec3(-1.0D, -1.0D, 1.0D).normalize(),
			new Vec3(-1.0D, -1.0D, -1.0D).normalize() };

	/**
	 * 相机位置兜底: 相机贴到方块上(甚至埋在方块里)时, 把它挪到"玩家自己那块空腔"里**余量最大**的点.
	 *
	 * 候选点怎么来(全都只在触发之后才跑; 正常帧第一行就返回):
	 *   1) 先沿"眼睛 -> 碰撞箱中心"与"眼睛 -> 落脚点(实体位置)"这两条线采样 —— 身体横躺时箱子中心可能
	 *      也在墙里(2.62.8 的注释里分析过), 但"脚"那一头一定是玩家自己那块空腔;
	 *   2) 再从上一步最好的那个点(两条线都没算出东西时用落脚点)沿 26 个方向往外探最多 0.4 格; 还不够就从
	 *      探出来的那个点再爬一两轮 —— 身体整只箱子撑在地板那一层时, 只有"拐个弯"才出得来.
	 *
	 * 打分规则是**余量大者优先**(最高到 EYE_GOOD), 余量差不多的才比"离眼睛近". 这是本轮与 2.62.8 的
	 * 唯一区别, 也正是"画面被方块贴图填满"的解法: 2.62.8 取"第一个够用的点", 于是相机永远停在离墙面
	 * 0.08 格的地方; 现在会一路退到那条缝的中间(余量 0.40).
	 *
	 * 实在找不到"有余量"的点时, 退一步接受"至少不在实心方块里"的点; 连这种点都没有才原样返回.
	 * 注意这里**只挪相机**, 不动 `Entity.getEyePosition` —— 那会一起改掉准星射线 / 音源 / 弹射物起点;
	 * 而这条只在"相机已经贴上去了"时触发, 那种状态下准星本来就已经穿进方块了.
	 */
	public static Vec3 clampEye(Entity e, Vec3 eye) {
		try {
			if (e == null || eye == null)
				return eye;
			Level lv = e.level();
			if (lv == null)
				return eye;
			// 快路径: 相机离方块还有 EYE_MARGIN 以上的余量 —— 正常站着 / 贴墙走着都是这一档, 一格都不碰
			if (!eyeNearBlock(lv, e, eye, EYE_MARGIN))
				return eye;
			Vec3 center = e.getBoundingBox().getCenter();
			Vec3 feet = e.position();
			EyeBest best = new EyeBest(lv, e, eye);
			// 1) 两条回退线上的采样
			eyeLine(best, eye, center);
			eyeLine(best, eye, feet);
			// 2) 从"线上最好的那个点"(两条线都没算出东西时就用落脚点)往外探: 先 6 根轴, 不够再 18 个斜方向
			Vec3 from = best.point != null ? best.point : feet;
			eyeProbe(best, from, 0, 6);
			if (best.clearance < EYE_GOOD)
				eyeProbe(best, from, 6, EYE_DIRS.length);
			// 3) 相机正好压在方块表面那一层时(两条回退线整条都落在那一层上 ⇒ 上面的采样全被"在方块里"筛掉),
			//    单个方向 0.4 格不够用: 从探出来的最好的那个点再爬一两轮, 于是能拐着弯继续往外走.
			for (int it = 0; it < 2 && best.clearance < EYE_GOOD; it++) {
				if (best.point == null || best.point.distanceToSqr(from) < 1.0E-12D)
					break;
				from = best.point;
				eyeProbe(best, from, 0, EYE_DIRS.length);
			}
			return best.point != null ? best.point : eye;
		} catch (Throwable t) {
			return eye;
		}
	}

	/** 相机兜底时给候选点打分: 先比"离方块还有多少余量", 再比"离眼睛近" */
	private static final class EyeBest {
		private final Level lv;
		private final Entity e;
		private final Vec3 eye;
		private Vec3 point = null;
		private int tier = 0;
		private double clearance = 0.0D;
		private double dist = 0.0D;
		private int budget = EYE_BUDGET;

		private EyeBest(Level lv, Entity e, Vec3 eye) {
			this.lv = lv;
			this.e = e;
			this.eye = eye;
		}

		private void consider(Vec3 p) {
			if (this.budget-- <= 0)
				return;
			double d = p.distanceTo(this.eye);
			if (d > EYE_MAX)
				return;
			double c = eyeClearance(this.lv, this.e, p);
			int t;
			if (c >= EYE_MIN)
				t = 2; // 离方块有最低余量: 合格
			else if (!eyeNearBlock(this.lv, this.e, p, EYE_SOLID))
				t = 1; // 不在实心方块里, 但贴得很近: 只当最后手段
			else
				return; // 真的在实心方块里(或正好停在它表面上): 不用
			if (this.point == null || t > this.tier || (t == this.tier && (c > this.clearance + 0.02D
					|| (c > this.clearance - 0.02D && d < this.dist)))) {
				this.point = p;
				this.tier = t;
				this.clearance = c;
				this.dist = d;
			}
		}
	}

	/** 沿 from -> to 采样(不采 from 自己; to 那一头会采到), 每个点都交给 best 打分 */
	private static void eyeLine(EyeBest best, Vec3 from, Vec3 to) {
		double len = from.distanceTo(to);
		if (len < 1.0E-6D)
			return;
		int n = (int) Math.ceil(len / EYE_LINE_STEP);
		if (n < 1)
			n = 1;
		for (int i = 1; i <= n; i++)
			best.consider(from.lerp(to, (double) i / (double) n));
	}

	/** 从 from 出发, 沿 EYE_DIRS[fromIdx, toIdx) 的每个方向走 1..EYE_REACH 步(0.1 一格); 余量到顶就提前收工 */
	private static void eyeProbe(EyeBest best, Vec3 from, int fromIdx, int toIdx) {
		for (int i = fromIdx; i < toIdx; i++) {
			if (best.budget <= 0)
				return;
			Vec3 d = EYE_DIRS[i];
			for (int k = 1; k <= EYE_REACH; k++) {
				best.consider(from.add(d.scale(EYE_STEP * (double) k)));
				if (best.tier == 2 && best.clearance >= EYE_GOOD)
					return;
			}
		}
	}

	/** 这个点离最近的方块碰撞形状有多远(按 EYE_LADDER 取档; 连 0.02 都不到就是 0) */
	private static double eyeClearance(Level lv, Entity e, Vec3 p) {
		for (int i = 0; i < EYE_LADDER.length; i++)
			if (!eyeNearBlock(lv, e, p, EYE_LADDER[i]))
				return EYE_LADDER[i];
		return 0.0D;
	}

	/**
	 * 这个点周围 r 内有没有方块的碰撞形状(不是"方块那一格"级别的判定, 是真的拿碰撞形状问一次).
	 *
	 * **故意不做"眼睛那一格是不是空气"的快路径**(2.62.5 / 2.62.6 有这一步): 眼睛那一格是空气、但旁边
	 * 方块(楼梯 / 台阶 / 栅栏 / 箱子 / 告示牌…)的碰撞形状伸过来, 或者眼睛离墙面只差 0.01 格时, 那一步
	 * 会把判定整个跳过 ⇒ 相机停在"贴面往外一根头发"的位置 ⇒ 近裁剪面把那一面裁掉 = 看穿方块 / 埋在
	 * 方块内壁. 相机这条路径一帧只走一次, 而且正常帧只有这一次查询, 开销可以忽略(只在"相机已经贴上
	 * 去了"那种状态下才会多问几次).
	 */
	private static boolean eyeNearBlock(Level lv, Entity e, Vec3 p, double r) {
		AABB box = new AABB(p.x - r, p.y - r, p.z - r, p.x + r, p.y + r, p.z + r);
		for (VoxelShape s : lv.getBlockCollisions(e, box)) {
			if (!s.isEmpty())
				return true;
		}
		return false;
	}

	/** from -> to 的最短弧(注意两者不能正好反向) */
	public static Quaternionf rotBetween(Vec3 from, Vec3 to) {
		Vec3 f = from.normalize();
		Vec3 t = to.normalize();
		Vec3 axis = f.cross(t);
		double len = axis.length();
		double cos = f.dot(t);
		if (len < 1.0E-9D)
			return cos > 0.0D ? new Quaternionf() : new Quaternionf().rotationZ(R180);
		double angle = Math.acos(Math.max(-1.0D, Math.min(1.0D, cos)));
		return new Quaternionf().fromAxisAngleRad(new Vector3f((float) (axis.x / len), (float) (axis.y / len), (float) (axis.z / len)),
				(float) angle);
	}
}
