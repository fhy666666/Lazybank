<#include "procedures.java.ftl">
<#--
  「重力颠倒」工具类(门面). 真正干活的是本插件生成的那套 Hxg* 类(见 forge-1.20.1/generator.yaml):
    gravity.HxgGravity      —— 重力坐标系换算 + 每个实体那份重力
    gravity.HxgGravityNet   —— 状态/同步/持久化/每刻维持
    gravity.HxgGravityAnim  —— 换重力时的过渡动画(客户端)
    mixin.Hxg*Mixin         —— 接管原版那些"把世界 +Y 当上"的地方(碰撞箱/眼睛/视线/位移/相机/模型)
  用法还是老样子: 在工作区里建一个代码名为 GravityUtils 的「全局触发器」流程, 此流程内不要放积木,
  7 个重力积木生成的代码就会调用下面的方法.
-->
public class ${name}Procedure {
	/** 设置重力方向(自动归一化, 0 -10 0 和 0 -1 0 等价)与强度倍数; 方向填 0 0 0 等于取消 */
	public static void set(Entity _e, double _x, double _y, double _z, double _strength) {
		${package}.gravity.HxgGravityNet.set(_e, _x, _y, _z, _strength);
	}

	/** 重力颠倒 */
	public static void invert(Entity _e) {
		${package}.gravity.HxgGravityNet.invert(_e);
	}

	/** 恢复默认重力 */
	public static void reset(Entity _e) {
		${package}.gravity.HxgGravityNet.reset(_e);
	}

	/** 把所有实体一次性恢复默认重力 */
	public static void clear() {
		${package}.gravity.HxgGravityNet.clear();
	}

	/** 这个实体有没有被设过自定义重力 */
	public static boolean has(Entity _e) {
		return ${package}.gravity.HxgGravityNet.has(_e);
	}

	/** 当前重力方向的 X 分量(没设过就按原版方向算) */
	public static double dirX(Entity _e) {
		return ${package}.gravity.HxgGravityNet.dirX(_e);
	}

	/** 当前重力方向的 Y 分量(-1 = 原版向下, 1 = 完全颠倒) */
	public static double dirY(Entity _e) {
		return ${package}.gravity.HxgGravityNet.dirY(_e);
	}

	/** 当前重力方向的 Z 分量 */
	public static double dirZ(Entity _e) {
		return ${package}.gravity.HxgGravityNet.dirZ(_e);
	}

	/** 当前重力强度倍数(没设过返回 1) */
	public static double strength(Entity _e) {
		return ${package}.gravity.HxgGravityNet.strengthOf(_e);
	}
