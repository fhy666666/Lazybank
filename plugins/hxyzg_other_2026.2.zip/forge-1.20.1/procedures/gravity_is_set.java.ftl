(GravityUtilsProcedure.has(${input$entity}))
