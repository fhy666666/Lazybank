GravityUtilsProcedure.set(${input$entity}, ${input$x}, ${input$y}, ${input$z}, ${input$strength});
