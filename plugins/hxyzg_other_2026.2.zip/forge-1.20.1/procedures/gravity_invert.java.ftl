GravityUtilsProcedure.invert(${input$entity});
