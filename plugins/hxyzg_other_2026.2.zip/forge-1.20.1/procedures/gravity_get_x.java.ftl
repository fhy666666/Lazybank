(GravityUtilsProcedure.dirX(${input$entity}))
