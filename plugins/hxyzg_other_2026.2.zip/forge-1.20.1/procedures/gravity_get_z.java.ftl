(GravityUtilsProcedure.dirZ(${input$entity}))
