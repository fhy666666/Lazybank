<#--
  <modid>.mixins.json 的生成 —— 本文件故意放在"共享路径" modbase/mixin.json.ftl 上.

  【归属】2026-11-18 起由 hxyzg_other 独占（权重 5150 > hxyzg_tools 5140）。
  hxyzg_tools 已不再提供这份模板；它那边的 HxgScaleRenderMixin / HxgGhost* 由这里统一登记。
  两份入口（modbase/mixin.json.ftl 与 hxyzg/mixin.json.ftl）内容逐字节一致，互为兜底。

  【为什么必须放 modbase】MCreator 2026.2 里"哪个 base_templates 条目生效"和"哪份模板文件生效"是两套规则：
    * 条目: YamlMerge 按权重升序合并，同一输出文件只保留列表里第一个（= 权重最低那条，通常是内置生成器）
    * 文件: ClassTemplateLoader 按插件权重从高到低取第一个命中（= 权重最高那个插件的文件）
  所以内容由"权重最高的插件"的 modbase/mixin.json.ftl 决定；把同一份放 hxyzg/ 是兜底。
  以后装了别的插件也往这个文件里加 mixin，请把它的条目一起并到下面的列表里。

  neoforge-1.21.1 与 forge-1.20.1 的差别：compatibilityLevel = JAVA_21、没有 refmap、
  没有 HxgGameRendererMixin（1.21.1 的视矩阵从 Camera.rotation() 反推，不需要再插世界旋转）。
-->
<#assign mixins = []>
<#if w.getGElementsOfType('biome')?filter(e -> e.spawnBiome || e.spawnInCaves || e.spawnBiomeNether)?size != 0>
  <#assign mixins = mixins + ['NoiseGeneratorSettingsMixin', 'BiomeSourcePresetMixin']>
</#if>
<#list w.getWorkspace().getModElements() as element>
  <#assign providedmixins = []>
  <#if element.getGeneratableElement().mixins??>
    <#assign providedmixins = element.getGeneratableElement().mixins>
  </#if>
  <#if providedmixins?has_content>
    <#list providedmixins as mixin>
       <#if !mixins?seq_contains(mixin)>
         <#assign mixins += [mixin]>
       </#if>
    </#list>
  </#if>
</#list>
<#assign allmixins = mixins + ['HxgEntityMixin', 'HxgLivingEntityMixin']>
<#assign allclient = ['PlayerAnimationMixin', 'PlayerAnimationRendererMixin', 'ItemInHandLayerMixin', 'CameraAccessor',
  'EntityRenderDispatcherMixin', 'LivingEntityRendererMixin', 'ItemInHandRendererMixin', 'LevelRendererMixin',
  'HxgCameraMixin', 'HxgEntityRenderMixin', 'HxgLocalPlayerMixin', 'HxgOverlayMixin',
  'HxgScaleRenderMixin', 'HxgGhostPoseMixin', 'HxgGhostCameraMixin', 'HxgGhostPickMixin', 'HxgGhostHandMixin',
  'HxgGhostGPickMixin']>
{
  "required": true,
  "package": "${package}.mixin",
  "compatibilityLevel": "JAVA_21",
  "mixins": [
	<#list allmixins as mixin>"${mixin}"<#sep>,</#list>
  ],
  "client": [
	<#list allclient as mixin>"${mixin}"<#sep>,</#list>
  ],
  "injectors": {
    "defaultRequire": 1
  },
  "minVersion": "0.8.4"
}
