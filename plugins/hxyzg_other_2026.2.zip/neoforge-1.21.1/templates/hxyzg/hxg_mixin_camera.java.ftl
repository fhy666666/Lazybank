package ${package}.mixin;

/*
 * 相机(NeoForge 1.21.1): 让"相机自己的朝向"也按重力坐标系来.
 *
 * 相机位置 = 实体位置 + 把 (0, 眼高, 0) 按重力转过去(眼睛落在身体的"头"那一侧);
 * 相机朝向 = 原版 rotationYXZ(...) 前面再乘上"世界旋转的共轭".
 *
 * 1.21.1 里画世界的视矩阵就是从 Camera.rotation() 反推的(`new Matrix4f().rotation(conj(rotation()))`),
 * 所以只改这一个四元数就够, 不需要再往 GameRenderer 里插东西.
 *
 * 说明: 相机位置这一处原来写的是 @ModifyArgs. 那个注入器会让 Mixin 在运行期给每个被改的调用点
 * 生成一个 org.spongepowered.asm.synthetic.args.Args$N 合成类, 而 NeoForge/ModLauncher 的
 * ModuleClassLoader 只把类加载请求交给"已导出包"的加载器 —— 这个合成包既不在 mixin 模块的
 * ModulePackages 里也没有被 export, 于是游戏一启动就
 * NoClassDefFoundError: org/spongepowered/asm/synthetic/args/Args$2.
 * 现在改成 @Redirect(不需要合成类), 语义逐位等价. 参考实现 GravityChanger 的 CameraMixin 也是
 * 这个写法(它用 MixinExtras 的 @WrapOperation, 同样要自己再调一次原方法).
 *
 * 原版 setPosition 是 protected, 而混入类不是 Camera 的子类, 只能用 @Shadow 把它挂出来再调.
 */

import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import ${package}.gravity.HxgGravity;
import ${package}.gravity.HxgGravityAnim;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.phys.Vec3;

@Mixin(value = Camera.class, priority = 1001)
public abstract class HxgCameraMixin {
	@Shadow
	private Entity entity;
	@Shadow
	private float eyeHeight;
	@Shadow
	private float eyeHeightOld;

	/** 原版那个 protected 方法, 挂出来供下面自己再调一次(混入类不是 Camera 的子类, 直接调编译不过) */
	@Shadow
	protected abstract void setPosition(double x, double y, double z);

	/** 相机位置: 把眼高那一份按重力转过去(眼睛跟着身体转到"头"上) */
	@Redirect(method = "setup(Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/world/entity/Entity;ZZF)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Camera;setPosition(DDD)V", ordinal = 0))
	private void hxg$pos(Camera camera, double x, double y, double z, BlockGetter area, Entity focused, boolean thirdPerson,
			boolean inverseView, float partial) {
		HxgGravity.G g = HxgGravity.of(focused);
		long timeMs = HxgGravityAnim.timeMs(focused, partial);
		// 默认重力 + 没有过渡动画在跑 = 一格都不碰(与装插件之前逐位一致).
		// "恢复默认重力"那一档: g 已经是空的(或 vanilla), 但动画还在跑 —— 这时候不能走原版快路径,
		// 否则画面会一下跳回正立, 过渡动画就等于没有.
		if ((g == null || g.vanilla) && !HxgGravityAnim.animating(focused, timeMs)) {
			this.setPosition(x, y, z);
			return;
		}
		Quaternionf rot = HxgGravityAnim.renderRot(focused, g, timeMs);
		double eye = Mth.lerp((double) partial, this.eyeHeightOld, this.eyeHeight);
		Vec3 off = HxgGravityAnim.eyeOffset(HxgGravityAnim.of(focused), rot, new Vec3(0.0D, eye, 0.0D), g);
		Vec3 cam = new Vec3(Mth.lerp((double) partial, focused.xo, focused.getX()) + off.x,
				Mth.lerp((double) partial, focused.yo, focused.getY()) + off.y,
				Mth.lerp((double) partial, focused.zo, focused.getZ()) + off.z);
		// 眼睛在实心方块里时(换向那一下箱子插进方块 / 过渡动画中间甩到箱子外)别让画面埋在方块里
		cam = HxgGravity.clampEye(focused, cam);
		this.setPosition(cam.x, cam.y, cam.z);
	}

	/**
	 * 相机朝向: 原版那个四元数记作 R(视矩阵 = conj(R)), 这里换成 l2w x R —— 视矩阵就从 conj(R)
	 * 变成 conj(R) x w2l, 也就是把世界绕着相机转过去; 相机的 forwards/up/left 也跟着对.
	 * 换重力时用过渡动画里插值出来的旋转, 所以画面是"转过去"的.
	 */
	@Redirect(method = "setRotation(FFF)V", at = @At(value = "INVOKE", target = "Lorg/joml/Quaternionf;rotationYXZ(FFF)Lorg/joml/Quaternionf;", remap = false))
	private Quaternionf hxg$rot(Quaternionf self, float x, float y, float z) {
		Entity e = this.entity;
		HxgGravity.G g = e == null ? null : HxgGravity.of(e);
		Quaternionf base = new Quaternionf().rotationYXZ(x, y, z);
		if (e == null)
			return self.set(base);
		long timeMs = HxgGravityAnim.timeMs(e,
				Minecraft.getInstance().getTimer().getGameTimeDeltaPartialTick(false));
		if ((g == null || g.vanilla) && !HxgGravityAnim.animating(e, timeMs))
			return self.set(base);
		return self.set(new Quaternionf(HxgGravityAnim.renderRot(e, g, timeMs)).conjugate().mul(base));
	}
}
