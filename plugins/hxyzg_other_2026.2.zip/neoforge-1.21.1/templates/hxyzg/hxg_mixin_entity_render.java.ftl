package ${package}.mixin;

/*
 * 实体模型: 渲染的时候把模型也按重力转过去(和世界画面的旋转正好相反).
 *
 * 做法与成熟实现一致: 在 EntityRenderDispatcher.render 里"把渲染位置平移好之后"pushPose 并乘上
 * 世界旋转的共轭(= 把模型立到新的"地面"上), 等模型画完再 popPose.
 * 只对非弹射物/非经验球做(和参考实现一致: 这两类不是"站着"的东西).
 *
 * 另外这一份还顺手把 F3+B(调试碰撞箱)的最后两样也放进重力坐标系(见文件末尾):
 * 原版那层红色"眼睛薄片"和那条蓝色视线都是按**世界 +Y**画的, 重力一旦不竖直, 它们就会跟
 * (已经被 HxgEntityMixin 转过来的)碰撞箱分家 —— 看着就像"视野没和碰撞箱重合", 其实相机/眼睛
 * 一直在箱子里面. 所以这里只改"调试显示怎么画", 不碰任何物理.
 *
 * 1.21.1 与 1.20.1 的差别: renderHitbox 多三个颜色参数(放进方法签名), 蓝线走的是同一个类里的
 * 私有 renderVector(PoseStack, VertexConsumer, Vector3f 起点, Vec3 方向, int 颜色). 混入类调不到
 * 那个私有方法, 所以这里按它的正文原样重画一遍(默认重力那一路逐字照抄, 行为与装插件前一致).
 */

import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import ${package}.gravity.HxgGravity;
import ${package}.gravity.HxgGravityAnim;

import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.Vec3;

@Mixin(EntityRenderDispatcher.class)
public abstract class HxgEntityRenderMixin {
	/**
	 * 要不要给这个实体乘"世界旋转的共轭".
	 *
	 * 默认重力 + 没有过渡动画在跑 = 不动; 但"恢复默认重力"那一档 g 已经是空的而动画还在跑,
	 * 那时候模型也得跟着转回去(世界画面在转, 模型不转就会看着像整个人被甩出去).
	 * 这里用 HxgGravityAnim.animating(不改状态), 保证 push/pop 两次调用拿到同一个答案.
	 */
	private static boolean hxg$skip(Entity entity, float partial) {
		if (entity instanceof Projectile || entity instanceof ExperienceOrb)
			return true;
		HxgGravity.G g = HxgGravity.of(entity);
		if (g != null && !g.vanilla)
			return false;
		return !HxgGravityAnim.animating(entity, HxgGravityAnim.timeMs(entity, partial));
	}

	@Inject(method = "render(Lnet/minecraft/world/entity/Entity;DDDFFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;translate(DDD)V", ordinal = 0, shift = At.Shift.AFTER))
	private void hxg$push(Entity entity, double x, double y, double z, float yaw, float partial, PoseStack pose,
			MultiBufferSource buffer, int light, CallbackInfo ci) {
		if (hxg$skip(entity, partial))
			return;
		try {
			HxgGravity.G g = HxgGravity.of(entity);
			pose.pushPose();
			pose.mulPose(new Quaternionf(HxgGravityAnim.renderRot(entity, g, HxgGravityAnim.timeMs(entity, partial)))
					.conjugate());
		} catch (Throwable t) {
			// 渲染不能因为这里出错就崩
		}
	}

	@Inject(method = "render(Lnet/minecraft/world/entity/Entity;DDDFFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/EntityRenderer;render(Lnet/minecraft/world/entity/Entity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", shift = At.Shift.AFTER))
	private void hxg$pop(Entity entity, double x, double y, double z, float yaw, float partial, PoseStack pose,
			MultiBufferSource buffer, int light, CallbackInfo ci) {
		if (hxg$skip(entity, partial))
			return;
		try {
			pose.popPose();
		} catch (Throwable t) {
			// 同上
		}
	}

	// ===== F3+B 的调试显示: 红色的"眼睛薄片"与蓝色的视线起点也要按重力摆 =====
	//
	// 原版 EntityRenderDispatcher.renderHitbox 画三样东西:
	//   1) 白箱子  = entity.getBoundingBox() 挪到实体原点 —— 这个已经被 HxgEntityMixin 按重力转过来了(正确);
	//   2) 红薄片  = "眼睛那一层": 脚印取箱子的 XZ, 高度直接取**世界 +Y** 上的 getEyeHeight();
	//   3) 蓝线    = 视线方向, 起点也是 (0, getEyeHeight(), 0)(世界 +Y 上的那个点).
	// 后两样完全不知道重力: 侧躺(重力沿世界 X/Z)时它们会沿世界 +Y 横着飘出去 1.62 格, 于是
	// 画面上就是"红框、蓝线跟碰撞箱分家了"(用户截图里那个红框就是这层红薄片, 不是相机的视野).
	//
	// 这里把它们也搬进重力坐标系: 红薄片 = 身体盒子的水平截面摆在眼睛高度上, 蓝线从**真正的眼睛**
	// (重力坐标系里的 (0, 眼高, 0)) 出发. 蓝线的方向本来就对(calculateViewVector 已经被改成
	// 重力坐标系里的角度了), 所以只有起点要挪.
	//
	// 默认重力下一格都不碰: 红薄片走原版那一次调用, 蓝线走下面那份与 renderVector 逐字相同的代码.

	/** 眼睛在"实体本地(世界轴向)坐标"里的位置: 原版写在 (0, 眼高, 0), 这里按重力转过去 */
	private static Vec3 hxg$eyeLocal(Entity entity) {
		return HxgGravity.l2w(HxgGravity.of(entity), 0.0D, (double) entity.getEyeHeight(), 0.0D);
	}

	@Redirect(method = "renderHitbox(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/world/entity/Entity;FFFF)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/LevelRenderer;renderLineBox(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;DDDDDDFFFF)V", ordinal = 0))
	private static void hxg$eyeSlab(PoseStack pose, VertexConsumer buffer, double x1, double y1, double z1, double x2,
			double y2, double z2, float red, float green, float blue, float alpha, PoseStack hostPose,
			VertexConsumer hostBuffer, Entity entity, float c1, float c2, float c3, float c4) {
		HxgGravity.G grav = HxgGravity.of(entity);
		if (grav == null || grav.vanilla) {
			LevelRenderer.renderLineBox(pose, buffer, x1, y1, z1, x2, y2, z2, red, green, blue, alpha);
			return;
		}
		// 在重力坐标系里画: pushPose 之后本地坐标的 +Y 就是"身体的上"
		double half = (double) entity.getBbWidth() / 2.0D;
		double eye = (double) entity.getEyeHeight();
		pose.pushPose();
		pose.mulPose(new Quaternionf(grav.l2w));
		LevelRenderer.renderLineBox(pose, buffer, -half, eye - 0.01D, -half, half, eye + 0.01D, half, red, green, blue,
				alpha);
		pose.popPose();
	}

	@Redirect(method = "renderHitbox(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/world/entity/Entity;FFFF)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;renderVector(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;Lorg/joml/Vector3f;Lnet/minecraft/world/phys/Vec3;I)V"))
	private static void hxg$viewLine(PoseStack pose, VertexConsumer buffer, Vector3f origin, Vec3 dir, int color,
			PoseStack hostPose, VertexConsumer hostBuffer, Entity entity, float c1, float c2, float c3, float c4) {
		// 起点: 有自定义重力时换成"重力坐标系里的眼睛"(原版那个 (0, 眼高, 0) 是世界 +Y 上的点)
		HxgGravity.G grav = HxgGravity.of(entity);
		Vector3f from = origin;
		if (grav != null && !grav.vanilla) {
			Vec3 eye = hxg$eyeLocal(entity);
			from = new Vector3f((float) eye.x, (float) eye.y, (float) eye.z);
		}
		// 以下与 1.21.1 那个私有 renderVector 的正文逐字相同(只把起点换成 from)
		PoseStack.Pose last = pose.last();
		buffer.addVertex(last, from).setColor(color).setNormal(last, (float) dir.x, (float) dir.y, (float) dir.z);
		buffer.addVertex(last, (float) ((double) from.x() + dir.x), (float) ((double) from.y() + dir.y),
				(float) ((double) from.z() + dir.z)).setColor(color)
				.setNormal(last, (float) dir.x, (float) dir.y, (float) dir.z);
	}
}
