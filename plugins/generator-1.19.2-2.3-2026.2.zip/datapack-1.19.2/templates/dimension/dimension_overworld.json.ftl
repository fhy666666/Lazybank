<#-- @formatter:off -->
<#include "../mcitems_json.ftl">
<#import "multi_noise.json.ftl" as ms>
<#import "surface_builder.json.ftl" as sb>
{
  "type": "${modid}:${registryname}",
  "generator": {
    "type": "minecraft:noise",
    "biome_source": <@ms.multiNoiseSource/>,
    "settings": {
      "name": "${modid}:${registryname}",
      "sea_level": ${data.seaLevel},
      "legacy_random_source": false,
      "disable_mob_generation": false,
      "aquifers_enabled": true,
      "ore_veins_enabled": ${data.generateOreVeins},
      "default_block": ${mappedMCItemToBlockStateJSON(data.mainFillerBlock)},
      "default_fluid": ${mappedMCItemToBlockStateJSON(data.fluidBlock)},
      "spawn_target": [],
      "noise": {
        "min_y": -64,
        "height": 384,
        "size_horizontal": ${data.horizontalNoiseSize},
        "size_vertical": ${data.verticalNoiseSize}
      },
      <#include "overworld_noise_router.json.ftl">,
      "surface_rule": {
         "type": "minecraft:sequence",
         "sequence": [
           {
             "type": "minecraft:condition",
             "if_true": {
               "type": "minecraft:vertical_gradient",
               "random_name": "minecraft:bedrock_floor",
               "true_at_and_below": {
                 "above_bottom": 0
               },
               "false_at_and_above": {
                 "above_bottom": 5
               }
             },
             "then_run": {
               "type": "minecraft:block",
               "result_state": {
                 "Name": "minecraft:bedrock"
               }
             }
           },
           <#list w.filterBrokenReferences(data.biomesInDimension) as biome>
             <#if biome.getUnmappedValue().startsWith("CUSTOM:")>
               <#assign ge = w.getWorkspace().getModElementByName(biome.getUnmappedValue().replace("CUSTOM:", "")).getGeneratableElement()/>
               <@sb.default biome ge.groundBlock ge.undergroundBlock ge.getUnderwaterBlock()/>
             <#else>
               <@sb.vanilla biome/>
             </#if>
             <#if biome?has_next>,</#if>
           </#list>
           <#list w.filterBrokenReferences(data.biomesInDimensionCaves) as biome>
		     <#if biome?is_first>,</#if>
		     <#if biome.getUnmappedValue().startsWith("CUSTOM:")>
		       <#assign ge = w.getWorkspace().getModElementByName(biome.getUnmappedValue().replace("CUSTOM:", "")).getGeneratableElement()/>
		       <@sb.defaultAny biome ge.groundBlock ge.undergroundBlock ge.getUnderwaterBlock()/>
		     <#else>
		       <@sb.vanilla biome true/>
		     </#if>
		     <#if biome?has_next>,</#if>
		   </#list>
         ]
      }
    }
  }
}
<#-- @formatter:on -->