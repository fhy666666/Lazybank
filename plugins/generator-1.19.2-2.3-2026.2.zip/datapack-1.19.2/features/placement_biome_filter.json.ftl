{
  "type": "minecraft:biome"
},