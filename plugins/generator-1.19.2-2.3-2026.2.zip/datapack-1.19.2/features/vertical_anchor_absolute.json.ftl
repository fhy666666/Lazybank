{
  "absolute": ${field$value}
}