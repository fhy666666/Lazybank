{
  "state": ${input$block}
}