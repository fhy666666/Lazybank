{
  "probability": ${field$probability}
}