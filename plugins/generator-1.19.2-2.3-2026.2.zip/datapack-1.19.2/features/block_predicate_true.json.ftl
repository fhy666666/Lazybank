{
  "type": "minecraft:true"
}