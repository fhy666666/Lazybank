(${input$entity}.getStringUUID())
