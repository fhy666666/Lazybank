(${input$entity}.isOnGround())
