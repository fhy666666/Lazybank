<#include "mcitems.ftl">
${mappedMCItemToItemStackCode(input$item)}.set(DataComponents.CUSTOM_DATA, CustomData.of(${input$compoundtag}));