<#include "mcitems.ftl">
${mappedMCItemToItemStackCode(input$item)}.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag()