<@addTemplate file="utils/entity_from_compoundtag.java.ftl"/>
spawnEntityFromCompoundTag(${input$compoundtag}, world, ${input$randomize_uuid!"true"})