<#include "nbt_tags_utils.ftl">
<@templateOrFallback "entity_from_compoundtag"/>
spawnEntityFromCompoundTag(${input$compoundtag}, world, ${input$randomize_uuid!"true"})