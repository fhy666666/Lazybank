<#include "nbt_tags_utils.ftl">
BlockPos _blockPos${index} = BlockPos.containing(${opt.toInt(input$x)}, ${opt.toInt(input$y)}, ${opt.toInt(input$z)});
BlockState _blockState${index} = world.getBlockState(_blockPos${index});
BlockEntity _blockEnt${index} = world.getBlockEntity(_blockPos${index});
if (_blockEnt${index} != null)
    _blockEnt${index}.setChanged();
((Level) world).sendBlockUpdated(_blockPos${index}, _blockState${index}, _blockState${index}, 3);