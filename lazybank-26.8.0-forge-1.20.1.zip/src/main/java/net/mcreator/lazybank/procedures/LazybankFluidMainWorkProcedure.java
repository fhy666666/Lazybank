package net.mcreator.lazybank.procedures;

import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.common.capabilities.ForgeCapabilities;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import net.mcreator.lazybank.network.LazybankModVariables;

public class LazybankFluidMainWorkProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double lazybankFluidBalance = 0;
		double lazybankTimer = 0;
		lazybankFluidBalance = getBlockNBTNumber(world, BlockPos.containing(x, y, z), "lazybankFluidBalance");
		lazybankTimer = LazybankModVariables.MapVariables.get(world).lazybankTicker + Math.abs((int) (x * 31) ^ (int) (y * 17) ^ (int) z);
		if ((getBlockNBTString(world, BlockPos.containing(x, y, z), "lazybankFluidName")).isEmpty() && !(new Object() {
			public int getAmountInTank(LevelAccessor level, BlockPos pos, int tank) {
				BlockEntity blockEntity = level.getBlockEntity(pos);
				if (blockEntity != null) {
					return blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, null).map(fluidHandler -> fluidHandler.getFluidInTank(tank).getAmount()).orElse(0);
				}
				return 0;
			}
		}.getAmountInTank(world, BlockPos.containing(x, y, z), (int) 0) == 0)) {
			if (LazybankModVariables.MapVariables.get(world).isLazybankFluidRebalancedMode) {
				if (!((getBlockNBTString(world, BlockPos.containing(x, y, z), "lazybankFluidName")).substring((getBlockNBTString(world, BlockPos.containing(x, y, z), "lazybankFluidName")).indexOf(":", 0))).contains("_")) {
					if (!world.isClientSide()) {
						BlockPos _bp = BlockPos.containing(x, y, z);
						BlockEntity _blockEntity = world.getBlockEntity(_bp);
						BlockState _bs = world.getBlockState(_bp);
						if (_blockEntity != null) {
							_blockEntity.getPersistentData().putString("lazybankFluidName", (BuiltInRegistries.FLUID.getKey((new Object() {
								public FluidStack getFluidInTank(LevelAccessor level, BlockPos pos, int tank) {
									BlockEntity blockEntity = level.getBlockEntity(pos);
									if (blockEntity != null) {
										return blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, null).map(fluidHandler -> fluidHandler.getFluidInTank(tank).copy()).orElse(FluidStack.EMPTY);
									}
									return FluidStack.EMPTY;
								}
							}.getFluidInTank(world, BlockPos.containing(x, y, z), (int) 0)).getFluid()).toString()));
						}
						if (world instanceof Level _level)
							_level.sendBlockUpdated(_bp, _bs, _bs, 3);
					}
				}
			} else {
				if (!world.isClientSide()) {
					BlockPos _bp = BlockPos.containing(x, y, z);
					BlockEntity _blockEntity = world.getBlockEntity(_bp);
					BlockState _bs = world.getBlockState(_bp);
					if (_blockEntity != null) {
						_blockEntity.getPersistentData().putString("lazybankFluidName", (BuiltInRegistries.FLUID.getKey((new Object() {
							public FluidStack getFluidInTank(LevelAccessor level, BlockPos pos, int tank) {
								BlockEntity blockEntity = level.getBlockEntity(pos);
								if (blockEntity != null) {
									return blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, null).map(fluidHandler -> fluidHandler.getFluidInTank(tank).copy()).orElse(FluidStack.EMPTY);
								}
								return FluidStack.EMPTY;
							}
						}.getFluidInTank(world, BlockPos.containing(x, y, z), (int) 0)).getFluid()).toString()));
					}
					if (world instanceof Level _level)
						_level.sendBlockUpdated(_bp, _bs, _bs, 3);
				}
			}
		}
		if (new Object() {
			public int getAmountInTank(LevelAccessor level, BlockPos pos, int tank) {
				BlockEntity blockEntity = level.getBlockEntity(pos);
				if (blockEntity != null) {
					return blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, null).map(fluidHandler -> fluidHandler.getFluidInTank(tank).getAmount()).orElse(0);
				}
				return 0;
			}
		}.getAmountInTank(world, BlockPos.containing(x, y, z), (int) 0) < 1) {
			{
				int _fill = 1;
				BlockEntity blockEntity = world.getBlockEntity(BlockPos.containing(x, y, z));
				if (blockEntity != null) {
					blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, null)
							.ifPresent(capability -> capability.fill(
									new FluidStack((new FluidStack(BuiltInRegistries.FLUID.get(ResourceLocation.tryParse((getBlockNBTString(world, BlockPos.containing(x, y, z), "lazybankFluidName")))), 1)).getFluid(), _fill),
									IFluidHandler.FluidAction.EXECUTE));
				}
			}
			lazybankFluidBalance = lazybankFluidBalance - 1;
			if (lazybankFluidBalance <= 0) {
				if (!world.isClientSide()) {
					BlockPos _bp = BlockPos.containing(x, y, z);
					BlockEntity _blockEntity = world.getBlockEntity(_bp);
					BlockState _bs = world.getBlockState(_bp);
					if (_blockEntity != null) {
						_blockEntity.getPersistentData().putString("lazybankFluidName", "");
					}
					if (world instanceof Level _level)
						_level.sendBlockUpdated(_bp, _bs, _bs, 3);
				}
				lazybankFluidBalance = 0;
			}
		}
		if ((getBlockNBTString(world, BlockPos.containing(x, y, z), "lazybankFluidName")).equals(BuiltInRegistries.FLUID.getKey((new Object() {
			public FluidStack getFluidInTank(LevelAccessor level, BlockPos pos, int tank) {
				BlockEntity blockEntity = level.getBlockEntity(pos);
				if (blockEntity != null) {
					return blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, null).map(fluidHandler -> fluidHandler.getFluidInTank(tank).copy()).orElse(FluidStack.EMPTY);
				}
				return FluidStack.EMPTY;
			}
		}.getFluidInTank(world, BlockPos.containing(x, y, z), (int) 0)).getFluid()).toString())) {
			while (new Object() {
				public int getAmountInTank(LevelAccessor level, BlockPos pos, int tank) {
					BlockEntity blockEntity = level.getBlockEntity(pos);
					if (blockEntity != null) {
						return blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, null).map(fluidHandler -> fluidHandler.getFluidInTank(tank).getAmount()).orElse(0);
					}
					return 0;
				}
			}.getAmountInTank(world, BlockPos.containing(x, y, z), (int) 0) >= 128000) {
				{
					int _drain = 127999;
					BlockEntity blockEntity = world.getBlockEntity(BlockPos.containing(x, y, z));
					if (blockEntity != null) {
						blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, null).ifPresent(capability -> capability.drain(_drain, IFluidHandler.FluidAction.EXECUTE));
					}
				}
				lazybankFluidBalance = lazybankFluidBalance + 127999;
			}
			while (new Object() {
				public int getAmountInTank(LevelAccessor level, BlockPos pos, int tank) {
					BlockEntity blockEntity = level.getBlockEntity(pos);
					if (blockEntity != null) {
						return blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, null).map(fluidHandler -> fluidHandler.getFluidInTank(tank).getAmount()).orElse(0);
					}
					return 0;
				}
			}.getAmountInTank(world, BlockPos.containing(x, y, z), (int) 0) >= 1000) {
				{
					int _drain = 999;
					BlockEntity blockEntity = world.getBlockEntity(BlockPos.containing(x, y, z));
					if (blockEntity != null) {
						blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, null).ifPresent(capability -> capability.drain(_drain, IFluidHandler.FluidAction.EXECUTE));
					}
				}
				lazybankFluidBalance = lazybankFluidBalance + 999;
			}
		}
		if (lazybankFluidBalance >= LazybankModVariables.MapVariables.get(world).minimumInterestBearingAmount * 1000 && new Object() {
			public boolean isFluidValid(LevelAccessor level, BlockPos pos, FluidStack stack, int tank) {
				BlockEntity blockEntity = level.getBlockEntity(pos);
				if (blockEntity != null) {
					return blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, null).map(fluidHandler -> fluidHandler.isFluidValid(tank, stack)).orElse(false);
				}
				return false;
			}
		}.isFluidValid(world, BlockPos.containing(x, (y - 1), z), (new FluidStack(BuiltInRegistries.FLUID.get(ResourceLocation.tryParse((getBlockNBTString(world, BlockPos.containing(x, y, z), "lazybankFluidName")))), 1)), (int) 0) && new Object() {
			public int getAmountInTank(LevelAccessor level, BlockPos pos, int tank) {
				BlockEntity blockEntity = level.getBlockEntity(pos);
				if (blockEntity != null) {
					return blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, null).map(fluidHandler -> fluidHandler.getFluidInTank(tank).getAmount()).orElse(0);
				}
				return 0;
			}
		}.getAmountInTank(world, BlockPos.containing(x, (y - 1), z), (int) 0) < new Object() {
			public int getTankSize(LevelAccessor level, BlockPos pos, int tank) {
				BlockEntity blockEntity = level.getBlockEntity(pos);
				if (blockEntity != null) {
					return blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, null).map(fluidHandler -> fluidHandler.getTankCapacity(tank)).orElse(0);
				}
				return 0;
			}
		}.getTankSize(world, BlockPos.containing(x, (y - 1), z), (int) 0)) {
			if (lazybankFluidBalance * LazybankModVariables.MapVariables.get(world).interestRate <= LazybankModVariables.MapVariables.get(world).interestEarningPeriod) {
				if (lazybankTimer % (LazybankModVariables.MapVariables.get(world).interestEarningPeriod / (lazybankFluidBalance * LazybankModVariables.MapVariables.get(world).interestRate)) == 0) {
					{
						int _fill = 1;
						BlockEntity blockEntity = world.getBlockEntity(BlockPos.containing(x, (y - 1), z));
						if (blockEntity != null) {
							blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, null)
									.ifPresent(capability -> capability.fill(
											new FluidStack((new FluidStack(BuiltInRegistries.FLUID.get(ResourceLocation.tryParse((getBlockNBTString(world, BlockPos.containing(x, y, z), "lazybankFluidName")))), 1)).getFluid(), _fill),
											IFluidHandler.FluidAction.EXECUTE));
						}
					}
				}
			} else {
				{
					int _fill = (int) Math.floor((lazybankFluidBalance * LazybankModVariables.MapVariables.get(world).interestRate) / LazybankModVariables.MapVariables.get(world).interestEarningPeriod);
					BlockEntity blockEntity = world.getBlockEntity(BlockPos.containing(x, (y - 1), z));
					if (blockEntity != null) {
						blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, null)
								.ifPresent(capability -> capability.fill(
										new FluidStack((new FluidStack(BuiltInRegistries.FLUID.get(ResourceLocation.tryParse((getBlockNBTString(world, BlockPos.containing(x, y, z), "lazybankFluidName")))), 1)).getFluid(), _fill),
										IFluidHandler.FluidAction.EXECUTE));
					}
				}
			}
		} else if (lazybankTimer % LazybankModVariables.MapVariables.get(world).interestEarningPeriod == 0) {
			lazybankFluidBalance = Math.min(lazybankFluidBalance + lazybankFluidBalance * LazybankModVariables.MapVariables.get(world).interestRate,
					(2147483647 * LazybankModVariables.MapVariables.get(world).interestEarningPeriod) / LazybankModVariables.MapVariables.get(world).interestRate);
		}
		if (!world.isClientSide()) {
			BlockPos _bp = BlockPos.containing(x, y, z);
			BlockEntity _blockEntity = world.getBlockEntity(_bp);
			BlockState _bs = world.getBlockState(_bp);
			if (_blockEntity != null) {
				_blockEntity.getPersistentData().putDouble("lazybankFluidBalance", lazybankFluidBalance);
			}
			if (world instanceof Level _level)
				_level.sendBlockUpdated(_bp, _bs, _bs, 3);
		}
	}

	private static double getBlockNBTNumber(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getDouble(tag);
		return -1;
	}

	private static String getBlockNBTString(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getString(tag);
		return "";
	}
}