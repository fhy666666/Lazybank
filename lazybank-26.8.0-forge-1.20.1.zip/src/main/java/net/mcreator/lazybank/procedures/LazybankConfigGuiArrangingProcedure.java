package net.mcreator.lazybank.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.lazybank.network.LazybankModVariables;
import net.mcreator.lazybank.init.LazybankModMenus;

public class LazybankConfigGuiArrangingProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && _player.containerMenu instanceof LazybankModMenus.MenuAccessor _menu)
			_menu.sendMenuStateUpdate(_player, 0, "minimumInterestBearingAmount", (new java.text.DecimalFormat("##.######").format(LazybankModVariables.MapVariables.get(world).minimumInterestBearingAmount)), true);
		if (entity instanceof Player _player && _player.containerMenu instanceof LazybankModMenus.MenuAccessor _menu)
			_menu.sendMenuStateUpdate(_player, 0, "interestRate", (new java.text.DecimalFormat("##.######").format(LazybankModVariables.MapVariables.get(world).interestRate)), true);
		if (entity instanceof Player _player && _player.containerMenu instanceof LazybankModMenus.MenuAccessor _menu)
			_menu.sendMenuStateUpdate(_player, 0, "interestEarningPeriod", (new java.text.DecimalFormat("##.######").format(LazybankModVariables.MapVariables.get(world).interestEarningPeriod)), true);
	}
}