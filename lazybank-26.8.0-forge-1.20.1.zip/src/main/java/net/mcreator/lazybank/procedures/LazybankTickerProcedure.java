package net.mcreator.lazybank.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;

import net.mcreator.lazybank.network.LazybankModVariables;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class LazybankTickerProcedure {
	@SubscribeEvent
	public static void onWorldTick(TickEvent.LevelTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.level);
		}
	}

	public static void execute(LevelAccessor world) {
		execute(null, world);
	}

	private static void execute(@Nullable Event event, LevelAccessor world) {
		if ((world instanceof Level _lvl ? _lvl.dimension() : (world instanceof WorldGenLevel _wgl ? _wgl.getLevel().dimension() : Level.OVERWORLD)) == Level.OVERWORLD) {
			if (LazybankModVariables.MapVariables.get(world).lazybankTicker >= 1000000000) {
				LazybankModVariables.MapVariables.get(world).lazybankTicker = 0;
				LazybankModVariables.MapVariables.get(world).markSyncDirty();
			} else {
				LazybankModVariables.MapVariables.get(world).lazybankTicker = LazybankModVariables.MapVariables.get(world).lazybankTicker + 1;
				LazybankModVariables.MapVariables.get(world).markSyncDirty();
			}
		}
	}
}