package net.mcreator.lazybank.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.lazybank.network.LazybankModVariables;

public class LazybankFluidProgressDisplayProcedure {
	public static String execute(LevelAccessor world, double x, double y, double z) {
		return new java.text.DecimalFormat("##").format((LazybankModVariables.MapVariables.get(world).lazybankTicker + Math.abs((int) (x * 31) ^ (int) (y * 17) ^ (int) z)) % LazybankModVariables.MapVariables.get(world).interestEarningPeriod) + "/"
				+ new java.text.DecimalFormat("##").format(LazybankModVariables.MapVariables.get(world).interestEarningPeriod);
	}
}