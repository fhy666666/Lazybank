package net.mcreator.lazybank.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.lazybank.network.LazybankModVariables;

public class LazybankFluidRebalancedModeCheckboxProcedure {
	public static boolean execute(LevelAccessor world) {
		return LazybankModVariables.MapVariables.get(world).isLazybankFluidRebalancedMode;
	}
}