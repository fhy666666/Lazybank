package net.mcreator.lazybank.procedures;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.BlockPos;

public class LazybankNameDisplayProcedure {
	public static String execute(LevelAccessor world, double x, double y, double z) {
		return ForgeRegistries.ITEMS.getKey((getBlockNBTItemStack(world, BlockPos.containing(x, y, z), "lazybankName")).getItem()).toString();
	}

	private static ItemStack getBlockNBTItemStack(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return ItemStack.of(blockEntity.getPersistentData().getCompound(tag));
		return ItemStack.EMPTY;
	}
}