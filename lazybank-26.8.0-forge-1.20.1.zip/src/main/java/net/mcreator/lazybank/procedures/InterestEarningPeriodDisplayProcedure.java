package net.mcreator.lazybank.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.lazybank.network.LazybankModVariables;

public class InterestEarningPeriodDisplayProcedure {
	public static String execute(LevelAccessor world) {
		return new java.text.DecimalFormat("##").format(LazybankModVariables.MapVariables.get(world).interestEarningPeriod);
	}
}