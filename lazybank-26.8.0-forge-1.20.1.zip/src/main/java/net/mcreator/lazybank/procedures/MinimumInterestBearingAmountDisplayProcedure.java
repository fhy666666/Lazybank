package net.mcreator.lazybank.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.lazybank.network.LazybankModVariables;

public class MinimumInterestBearingAmountDisplayProcedure {
	public static String execute(LevelAccessor world) {
		return new java.text.DecimalFormat("##").format(LazybankModVariables.MapVariables.get(world).minimumInterestBearingAmount);
	}
}