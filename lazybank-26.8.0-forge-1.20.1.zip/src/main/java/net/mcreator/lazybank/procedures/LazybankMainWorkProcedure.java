package net.mcreator.lazybank.procedures;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.common.capabilities.ForgeCapabilities;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.tags.ItemTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.BlockPos;

import net.mcreator.lazybank.network.LazybankModVariables;

import java.util.concurrent.atomic.AtomicReference;

public class LazybankMainWorkProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double lazybankBalance = 0;
		double lazybankTimer = 0;
		if (world.isClientSide()) {
			LazybankItemRenderProcedure.execute(world);
		} else {
			lazybankBalance = getBlockNBTNumber(world, BlockPos.containing(x, y, z), "lazybankBalance");
			lazybankTimer = LazybankModVariables.MapVariables.get(world).lazybankTicker + Math.abs((int) (x * 31) ^ (int) (y * 17) ^ (int) z);
			if ((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).getItem() == Blocks.AIR.asItem()) {
				if (!((getBlockNBTItemStack(world, BlockPos.containing(x, y, z), "lazybankName")).getItem() == Blocks.AIR.asItem())) {
					if (lazybankBalance >= 3) {
						{
							BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y, z));
							if (_ent != null) {
								final int _slotid = 0;
								final ItemStack _setstack = (getBlockNBTItemStack(world, BlockPos.containing(x, y, z), "lazybankName")).copy();
								_setstack.setCount(1);
								_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
									if (capability instanceof IItemHandlerModifiable)
										((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
								});
							}
						}
						lazybankBalance = lazybankBalance - 1;
					} else {
						{
							BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y, z));
							if (_ent != null) {
								final int _slotid = 0;
								final ItemStack _setstack = (getBlockNBTItemStack(world, BlockPos.containing(x, y, z), "lazybankName")).copy();
								_setstack.setCount(1);
								_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
									if (capability instanceof IItemHandlerModifiable)
										((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
								});
							}
						}
						lazybankBalance = 0;
						if (!world.isClientSide()) {
							BlockPos _bp = BlockPos.containing(x, y, z);
							BlockEntity _blockEntity = world.getBlockEntity(_bp);
							BlockState _bs = world.getBlockState(_bp);
							if (_blockEntity != null) {
								_blockEntity.getPersistentData().put("lazybankName", !new ItemStack(Blocks.AIR).isEmpty() ? new ItemStack(Blocks.AIR).save(new CompoundTag()) : new CompoundTag());
							}
							if (world instanceof Level _level)
								_level.sendBlockUpdated(_bp, _bs, _bs, 3);
						}
					}
				}
			} else if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).getCount() > 1) {
				if ((getBlockNBTItemStack(world, BlockPos.containing(x, y, z), "lazybankName")).getItem() == Blocks.AIR.asItem()) {
					if (LazybankModVariables.MapVariables.get(world).isLazybankRebalancedMode) {
						if (!((ForgeRegistries.ITEMS.getKey((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).getItem()).toString())
								.substring((ForgeRegistries.ITEMS.getKey((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).getItem()).toString()).indexOf(":", 0))).contains("_")
								|| (ForgeRegistries.ITEMS.getKey((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).getItem()).toString()).contains("block")
								|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).is(ItemTags.create(new ResourceLocation("forge:storage_blocks")))
								|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).is(ItemTags.create(new ResourceLocation("c:storage_blocks")))) {
							if (!world.isClientSide()) {
								BlockPos _bp = BlockPos.containing(x, y, z);
								BlockEntity _blockEntity = world.getBlockEntity(_bp);
								BlockState _bs = world.getBlockState(_bp);
								if (_blockEntity != null) {
									_blockEntity.getPersistentData().put("lazybankName",
											!(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).isEmpty() ? (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).save(new CompoundTag()) : new CompoundTag());
								}
								if (world instanceof Level _level)
									_level.sendBlockUpdated(_bp, _bs, _bs, 3);
							}
							lazybankBalance = 1;
						}
					} else {
						if (!world.isClientSide()) {
							BlockPos _bp = BlockPos.containing(x, y, z);
							BlockEntity _blockEntity = world.getBlockEntity(_bp);
							BlockState _bs = world.getBlockState(_bp);
							if (_blockEntity != null) {
								_blockEntity.getPersistentData().put("lazybankName",
										!(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).isEmpty() ? (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).save(new CompoundTag()) : new CompoundTag());
							}
							if (world instanceof Level _level)
								_level.sendBlockUpdated(_bp, _bs, _bs, 3);
						}
						lazybankBalance = 1;
					}
				}
				lazybankBalance = lazybankBalance + itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).getCount() - 1;
				{
					BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y, z));
					if (_ent != null) {
						final int _slotid = 0;
						final ItemStack _setstack = (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).copy();
						_setstack.setCount(1);
						_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
							if (capability instanceof IItemHandlerModifiable)
								((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
						});
					}
				}
			}
			if (/*@Boolean*/(new Object() {
				boolean isFull(LevelAccessor w, double x, double y, double z, ItemStack test, int cnt) {
					if (w.isClientSide())
						return true;
					BlockEntity be = w.getBlockEntity(new BlockPos((int) x, (int) y, (int) z));
					if (be == null)
						return true;
					java.util.concurrent.atomic.AtomicBoolean r = new java.util.concurrent.atomic.AtomicBoolean(true);
					be.getCapability(net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER, null).ifPresent(h -> {
						ItemStack s = test.copy();
						s.setCount(cnt);
						for (int i = 0; i < h.getSlots(); i++) {
							if (h.insertItem(i, s, true).getCount() < cnt) {
								r.set(false);
								break;
							}
						}
					});
					return r.get();
				}
			}.isFull(world, x, (y - 1), z, (getBlockNBTItemStack(world, BlockPos.containing(x, y, z), "lazybankName")), (int) 1))) {
				if (((ForgeRegistries.ITEMS.getKey((getBlockNBTItemStack(world, BlockPos.containing(x, y, z), "lazybankName")).getItem()).toString()).contains("block")
						|| (getBlockNBTItemStack(world, BlockPos.containing(x, y, z), "lazybankName")).is(ItemTags.create(new ResourceLocation("forge:storage_blocks")))
						|| (getBlockNBTItemStack(world, BlockPos.containing(x, y, z), "lazybankName")).is(ItemTags.create(new ResourceLocation("c:storage_blocks")))
								? lazybankBalance >= Math.floor(LazybankModVariables.MapVariables.get(world).minimumInterestBearingAmount / 8)
								: lazybankBalance >= LazybankModVariables.MapVariables.get(world).minimumInterestBearingAmount)
						&& lazybankTimer % LazybankModVariables.MapVariables.get(world).interestEarningPeriod == 0) {
					lazybankBalance = Math.min(lazybankBalance + lazybankBalance * LazybankModVariables.MapVariables.get(world).interestRate,
							(2147483647 * LazybankModVariables.MapVariables.get(world).interestEarningPeriod) / LazybankModVariables.MapVariables.get(world).interestRate);
				}
			} else {
				if ((ForgeRegistries.ITEMS.getKey((getBlockNBTItemStack(world, BlockPos.containing(x, y, z), "lazybankName")).getItem()).toString()).contains("block")
						|| (getBlockNBTItemStack(world, BlockPos.containing(x, y, z), "lazybankName")).is(ItemTags.create(new ResourceLocation("forge:storage_blocks")))
						|| (getBlockNBTItemStack(world, BlockPos.containing(x, y, z), "lazybankName")).is(ItemTags.create(new ResourceLocation("c:storage_blocks")))
								? lazybankBalance >= Math.floor(LazybankModVariables.MapVariables.get(world).minimumInterestBearingAmount / 8)
								: lazybankBalance >= LazybankModVariables.MapVariables.get(world).minimumInterestBearingAmount) {
					if (lazybankBalance * LazybankModVariables.MapVariables.get(world).interestRate <= LazybankModVariables.MapVariables.get(world).interestEarningPeriod) {
						if (lazybankTimer % Math.ceil(LazybankModVariables.MapVariables.get(world).interestEarningPeriod / (lazybankBalance * LazybankModVariables.MapVariables.get(world).interestRate)) == 0) {
							int insertCount = 1;
							ItemStack stackToInsert = (getBlockNBTItemStack(world, BlockPos.containing(x, y, z), "lazybankName")).copy();
							if (!world.isClientSide()) {
								// 坐标修正（避免偏移）
								BlockPos pos = new BlockPos((int) Math.floor(x), (int) Math.floor((y - 1)), (int) Math.floor(z));
								BlockEntity be = world.getBlockEntity(pos);
								if (be == null)
									return;
								// 【关键修复】：解决 Java lambda 表达式的 final 限制
								// 在进入 lambda 之前，将变量声明为 final
								final ItemStack finalstackToInsert = stackToInsert.copy();
								final double finalinsertCount = insertCount;
								be.getCapability(net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER, null).ifPresent(handler -> {
									// 在这里使用 finalinsertCount
									long total = Math.round(finalinsertCount);
									if (total <= 0)
										return;
									// 防止超过 int 上限
									if (total > Integer.MAX_VALUE)
										total = Integer.MAX_VALUE;
									int remaining = (int) total;
									// 在这里使用 finalstackToInsert
									ItemStack tempStack = finalstackToInsert.copy();
									tempStack.setCount(remaining);
									// 遍历所有槽位尝试插入 (O(1) 性能优化版)
									for (int i = 0; i < handler.getSlots(); i++) {
										tempStack = handler.insertItem(i, tempStack, false);
										// 如果堆叠变为空（已全部存入），则提前结束遍历
										if (tempStack.isEmpty()) {
											break;
										}
									}
								});
							}
						}
					} else {
						int insertCount = ((int) Math.min((lazybankBalance * LazybankModVariables.MapVariables.get(world).interestRate) / LazybankModVariables.MapVariables.get(world).interestEarningPeriod,
								26512143 - (int) (itemFromBlockInventory(world, BlockPos.containing(x, y - 1, z), (int) Math.max(getBlockInventorySlotCount(world, BlockPos.containing(x, y - 1, z)) - 1, 0)).getCount())));
						ItemStack stackToInsert = (getBlockNBTItemStack(world, BlockPos.containing(x, y, z), "lazybankName")).copy();
						if (!world.isClientSide()) {
							// 坐标修正（避免偏移）
							BlockPos pos = new BlockPos((int) Math.floor(x), (int) Math.floor((y - 1)), (int) Math.floor(z));
							BlockEntity be = world.getBlockEntity(pos);
							if (be == null)
								return;
							// 【关键修复】：解决 Java lambda 表达式的 final 限制
							// 在进入 lambda 之前，将变量声明为 final
							final ItemStack finalstackToInsert = stackToInsert.copy();
							final double finalinsertCount = insertCount;
							be.getCapability(net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER, null).ifPresent(handler -> {
								// 在这里使用 finalinsertCount
								long total = Math.round(finalinsertCount);
								if (total <= 0)
									return;
								// 防止超过 int 上限
								if (total > Integer.MAX_VALUE)
									total = Integer.MAX_VALUE;
								int remaining = (int) total;
								// 在这里使用 finalstackToInsert
								ItemStack tempStack = finalstackToInsert.copy();
								tempStack.setCount(remaining);
								// 遍历所有槽位尝试插入 (O(1) 性能优化版)
								for (int i = 0; i < handler.getSlots(); i++) {
									tempStack = handler.insertItem(i, tempStack, false);
									// 如果堆叠变为空（已全部存入），则提前结束遍历
									if (tempStack.isEmpty()) {
										break;
									}
								}
							});
						}
					}
				}
			}
			if (!world.isClientSide()) {
				BlockPos _bp = BlockPos.containing(x, y, z);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null) {
					_blockEntity.getPersistentData().putDouble("lazybankBalance", lazybankBalance);
				}
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
		}
	}

	private static double getBlockNBTNumber(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getDouble(tag);
		return -1;
	}

	private static ItemStack itemFromBlockInventory(LevelAccessor level, BlockPos pos, int slot) {
		AtomicReference<ItemStack> result = new AtomicReference<>(ItemStack.EMPTY);
		BlockEntity entity = level.getBlockEntity(pos);
		if (entity != null)
			entity.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> result.set(capability.getStackInSlot(slot)));
		return result.get();
	}

	private static ItemStack getBlockNBTItemStack(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return ItemStack.of(blockEntity.getPersistentData().getCompound(tag));
		return ItemStack.EMPTY;
	}

	private static int getBlockInventorySlotCount(LevelAccessor world, BlockPos pos) {
		AtomicReference<Integer> result = new AtomicReference<>(0);
		BlockEntity entity = world.getBlockEntity(pos);
		if (entity != null)
			entity.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> result.set(capability.getSlots()));
		return result.get();
	}
}