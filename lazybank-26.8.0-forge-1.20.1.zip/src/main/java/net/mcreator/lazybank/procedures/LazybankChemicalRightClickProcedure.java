package net.mcreator.lazybank.procedures;

import net.minecraftforge.network.NetworkHooks;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.InteractionHand;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.core.BlockPos;

import net.mcreator.lazybank.world.inventory.LazybankChemicalGuiMenu;
import net.mcreator.lazybank.init.LazybankModBlocks;
import net.mcreator.lazybank.LazybankMod;

import io.netty.buffer.Unpooled;

public class LazybankChemicalRightClickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity.isShiftKeyDown() && (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Blocks.AIR.asItem()) {
			LazybankMod.queueServerWork(1, () -> {
				if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == LazybankModBlocks.LAZYBANK_CHEMICAL.get()) {
					if (entity instanceof LivingEntity _entity) {
						ItemStack _setstack5 = new ItemStack(LazybankModBlocks.LAZYBANK_CHEMICAL.get()).copy();
						_setstack5.setCount(1);
						_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack5);
						if (_entity instanceof Player _player)
							_player.getInventory().setChanged();
					}
					(entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getOrCreateTag().putString("lazybankChemicalName", (getBlockNBTString(world, BlockPos.containing(x, y, z), "lazybankChemicalName")));
					(entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getOrCreateTag().putDouble("lazybankChemicalBalance", (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "lazybankChemicalBalance")));
					(entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).setHoverName(Component.literal((Component.translatable("block.lazybank.lazybank_chemical").getString() + "["
							+ ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getOrCreateTag().getString("lazybankChemicalName")) + "]["
							+ (new java.text.DecimalFormat("##.###").format((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getOrCreateTag().getDouble("lazybankChemicalBalance") / 1000)) + "B" + "]")));
					world.destroyBlock(BlockPos.containing(x, y, z), false);
					if (entity instanceof Player _player)
						_player.closeContainer();
				}
			});
		} else {
			if (entity instanceof ServerPlayer _ent) {
				BlockPos _bpos = BlockPos.containing(x, y, z);
				NetworkHooks.openScreen((ServerPlayer) _ent, new MenuProvider() {
					@Override
					public Component getDisplayName() {
						return Component.literal("LazybankChemicalGui");
					}

					@Override
					public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
						return new LazybankChemicalGuiMenu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(_bpos));
					}
				}, _bpos);
			}
		}
	}

	private static String getBlockNBTString(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getString(tag);
		return "";
	}

	private static double getBlockNBTNumber(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getDouble(tag);
		return -1;
	}
}