package net.mcreator.lazybank.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.lazybank.network.LazybankModVariables;
import net.mcreator.lazybank.init.LazybankModMenus;

public class ButtonSaveProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		LazybankModVariables.MapVariables.get(world).minimumInterestBearingAmount = new Object() {
			double convert(String s) {
				try {
					return Double.parseDouble(s.trim());
				} catch (Exception e) {
				}
				return 0;
			}
		}.convert((entity instanceof Player _entity0 && _entity0.containerMenu instanceof LazybankModMenus.MenuAccessor _menu0) ? _menu0.getMenuState(0, "minimumInterestBearingAmount", "") : "");
		LazybankModVariables.MapVariables.get(world).interestRate = new Object() {
			double convert(String s) {
				try {
					return Double.parseDouble(s.trim());
				} catch (Exception e) {
				}
				return 0;
			}
		}.convert((entity instanceof Player _entity1 && _entity1.containerMenu instanceof LazybankModMenus.MenuAccessor _menu1) ? _menu1.getMenuState(0, "interestRate", "") : "");
		LazybankModVariables.MapVariables.get(world).interestEarningPeriod = new Object() {
			double convert(String s) {
				try {
					return Double.parseDouble(s.trim());
				} catch (Exception e) {
				}
				return 0;
			}
		}.convert((entity instanceof Player _entity2 && _entity2.containerMenu instanceof LazybankModMenus.MenuAccessor _menu2) ? _menu2.getMenuState(0, "interestEarningPeriod", "") : "");
		LazybankModVariables.MapVariables.get(world).isLazybankRebalancedMode = (entity instanceof Player _entity3 && _entity3.containerMenu instanceof LazybankModMenus.MenuAccessor _menu3)
				&& _menu3.getMenuState(1, "isLazybankRebalancedMode", false);
		LazybankModVariables.MapVariables.get(world).isLazybankFluidRebalancedMode = (entity instanceof Player _entity4 && _entity4.containerMenu instanceof LazybankModMenus.MenuAccessor _menu4)
				&& _menu4.getMenuState(1, "isLazybankFluidRebalancedMode", false);
		LazybankModVariables.MapVariables.get(world).isLazybankChemicalRebalancedMode = (entity instanceof Player _entity5 && _entity5.containerMenu instanceof LazybankModMenus.MenuAccessor _menu5)
				&& _menu5.getMenuState(1, "isLazybankChemicalRebalancedMode", false);
		LazybankModVariables.MapVariables.get(world).markSyncDirty();
	}
}