/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lazybank.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.client.Minecraft;

import net.mcreator.lazybank.world.inventory.LazybankGuiMenu;
import net.mcreator.lazybank.world.inventory.LazybankFluidGuiMenu;
import net.mcreator.lazybank.world.inventory.LazybankConfigGuiMenu;
import net.mcreator.lazybank.world.inventory.LazybankChemicalGuiMenu;
import net.mcreator.lazybank.network.MenuStateUpdateMessage;
import net.mcreator.lazybank.LazybankMod;

import java.util.Map;

public class LazybankModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, LazybankMod.MODID);
	public static final RegistryObject<MenuType<LazybankGuiMenu>> LAZYBANK_GUI = REGISTRY.register("lazybank_gui", () -> IForgeMenuType.create(LazybankGuiMenu::new));
	public static final RegistryObject<MenuType<LazybankConfigGuiMenu>> LAZYBANK_CONFIG_GUI = REGISTRY.register("lazybank_config_gui", () -> IForgeMenuType.create(LazybankConfigGuiMenu::new));
	public static final RegistryObject<MenuType<LazybankFluidGuiMenu>> LAZYBANK_FLUID_GUI = REGISTRY.register("lazybank_fluid_gui", () -> IForgeMenuType.create(LazybankFluidGuiMenu::new));
	public static final RegistryObject<MenuType<LazybankChemicalGuiMenu>> LAZYBANK_CHEMICAL_GUI = REGISTRY.register("lazybank_chemical_gui", () -> IForgeMenuType.create(LazybankChemicalGuiMenu::new));

	public interface MenuAccessor {
		Map<String, Object> getMenuState();

		Map<Integer, Slot> getSlots();

		default void sendMenuStateUpdate(Player player, int elementType, String name, Object elementState, boolean needClientUpdate) {
			getMenuState().put(elementType + ":" + name, elementState);
			if (player instanceof ServerPlayer serverPlayer) {
				LazybankMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> serverPlayer), new MenuStateUpdateMessage(elementType, name, elementState));
			} else if (player.level().isClientSide) {
				if (Minecraft.getInstance().screen instanceof LazybankModScreens.ScreenAccessor accessor && needClientUpdate)
					accessor.updateMenuState(elementType, name, elementState);
				LazybankMod.PACKET_HANDLER.sendToServer(new MenuStateUpdateMessage(elementType, name, elementState));
			}
		}

		default <T> T getMenuState(int elementType, String name, T defaultValue) {
			try {
				return (T) getMenuState().getOrDefault(elementType + ":" + name, defaultValue);
			} catch (ClassCastException e) {
				return defaultValue;
			}
		}
	}
}