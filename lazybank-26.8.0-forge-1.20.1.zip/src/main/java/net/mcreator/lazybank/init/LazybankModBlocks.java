/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lazybank.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.lazybank.block.LazybankFluidBlock;
import net.mcreator.lazybank.block.LazybankChemicalBlock;
import net.mcreator.lazybank.block.LazybankBlock;
import net.mcreator.lazybank.LazybankMod;

public class LazybankModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, LazybankMod.MODID);
	public static final RegistryObject<Block> LAZYBANK;
	public static final RegistryObject<Block> LAZYBANK_FLUID;
	public static final RegistryObject<Block> LAZYBANK_CHEMICAL;
	static {
		LAZYBANK = REGISTRY.register("lazybank", LazybankBlock::new);
		LAZYBANK_FLUID = REGISTRY.register("lazybank_fluid", LazybankFluidBlock::new);
		LAZYBANK_CHEMICAL = REGISTRY.register("lazybank_chemical", LazybankChemicalBlock::new);
	}
	// Start of user code block custom blocks
	// End of user code block custom blocks
}