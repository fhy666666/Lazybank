/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lazybank.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.lazybank.LazybankMod;

public class LazybankModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LazybankMod.MODID);
	public static final RegistryObject<CreativeModeTab> LAZYBANK_TAB = REGISTRY.register("lazybank_tab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.lazybank.lazybank_tab")).icon(() -> new ItemStack(LazybankModBlocks.LAZYBANK.get())).displayItems((parameters, tabData) -> {
				tabData.accept(LazybankModBlocks.LAZYBANK.get().asItem());
				tabData.accept(LazybankModBlocks.LAZYBANK_FLUID.get().asItem());
				tabData.accept(LazybankModBlocks.LAZYBANK_CHEMICAL.get().asItem());
			}).build());
}