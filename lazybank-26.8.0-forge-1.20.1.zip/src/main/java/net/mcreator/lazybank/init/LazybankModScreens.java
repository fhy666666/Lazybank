/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lazybank.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

import net.mcreator.lazybank.client.gui.LazybankGuiScreen;
import net.mcreator.lazybank.client.gui.LazybankFluidGuiScreen;
import net.mcreator.lazybank.client.gui.LazybankConfigGuiScreen;
import net.mcreator.lazybank.client.gui.LazybankChemicalGuiScreen;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class LazybankModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(LazybankModMenus.LAZYBANK_GUI.get(), LazybankGuiScreen::new);
			MenuScreens.register(LazybankModMenus.LAZYBANK_CONFIG_GUI.get(), LazybankConfigGuiScreen::new);
			MenuScreens.register(LazybankModMenus.LAZYBANK_FLUID_GUI.get(), LazybankFluidGuiScreen::new);
			MenuScreens.register(LazybankModMenus.LAZYBANK_CHEMICAL_GUI.get(), LazybankChemicalGuiScreen::new);
		});
	}

	public interface ScreenAccessor {
		void updateMenuState(int elementType, String name, Object elementState);
	}
}