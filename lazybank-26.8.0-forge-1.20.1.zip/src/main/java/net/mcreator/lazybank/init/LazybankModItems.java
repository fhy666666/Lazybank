/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lazybank.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.lazybank.LazybankMod;

public class LazybankModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, LazybankMod.MODID);
	public static final RegistryObject<Item> LAZYBANK;
	public static final RegistryObject<Item> LAZYBANK_FLUID;
	public static final RegistryObject<Item> LAZYBANK_CHEMICAL;
	static {
		LAZYBANK = block(LazybankModBlocks.LAZYBANK);
		LAZYBANK_FLUID = block(LazybankModBlocks.LAZYBANK_FLUID);
		LAZYBANK_CHEMICAL = block(LazybankModBlocks.LAZYBANK_CHEMICAL);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return block(block, new Item.Properties());
	}

	private static RegistryObject<Item> block(RegistryObject<Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}
}