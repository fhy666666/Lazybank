/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lazybank.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Block;

import net.mcreator.lazybank.block.entity.LazybankFluidBlockEntity;
import net.mcreator.lazybank.block.entity.LazybankChemicalBlockEntity;
import net.mcreator.lazybank.block.entity.LazybankBlockEntity;
import net.mcreator.lazybank.LazybankMod;

public class LazybankModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, LazybankMod.MODID);
	public static final RegistryObject<BlockEntityType<LazybankBlockEntity>> LAZYBANK = register("lazybank", LazybankModBlocks.LAZYBANK, LazybankBlockEntity::new);
	public static final RegistryObject<BlockEntityType<LazybankFluidBlockEntity>> LAZYBANK_FLUID = register("lazybank_fluid", LazybankModBlocks.LAZYBANK_FLUID, LazybankFluidBlockEntity::new);
	public static final RegistryObject<BlockEntityType<LazybankChemicalBlockEntity>> LAZYBANK_CHEMICAL = register("lazybank_chemical", LazybankModBlocks.LAZYBANK_CHEMICAL, LazybankChemicalBlockEntity::new);

	// Start of user code block custom block entities
	// End of user code block custom block entities
	private static <T extends BlockEntity> RegistryObject<BlockEntityType<T>> register(String registryname, RegistryObject<Block> block, BlockEntityType.BlockEntitySupplier<T> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}