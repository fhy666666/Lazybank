package net.mcreator.lazybank.client.gui;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.lazybank.world.inventory.LazybankGuiMenu;
import net.mcreator.lazybank.procedures.LazybankProgressDisplayProcedure;
import net.mcreator.lazybank.procedures.LazybankNameDisplayProcedure;
import net.mcreator.lazybank.procedures.LazybankBalanceDisplayProcedure;
import net.mcreator.lazybank.init.LazybankModScreens;

import com.mojang.blaze3d.systems.RenderSystem;

public class LazybankGuiScreen extends AbstractContainerScreen<LazybankGuiMenu> implements LazybankModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private static final ResourceLocation BACKGROUND = new ResourceLocation("lazybank:textures/screens/lazybank_gui.png");
	private static final ResourceLocation IMAGE_0 = new ResourceLocation("lazybank:textures/screens/bigpaper.png");

	public LazybankGuiScreen(LazybankGuiMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 200;
		this.imageHeight = 260;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(guiGraphics);
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(BACKGROUND, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		guiGraphics.blit(IMAGE_0, this.leftPos + 54, this.topPos + 81, 0, 0, 96, 96, 96, 96);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.lazybank.lazybank_gui.label_balance"), 9, 36, -12829636, false);
		guiGraphics.drawString(this.font, LazybankBalanceDisplayProcedure.execute(world, x, y, z), 9, 45, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.lazybank.lazybank_gui.label_item_name"), 9, 9, -12829636, false);
		guiGraphics.drawString(this.font, LazybankNameDisplayProcedure.execute(world, x, y, z), 9, 18, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.lazybank.lazybank_gui.label_progress"), 9, 63, -12829636, false);
		guiGraphics.drawString(this.font, LazybankProgressDisplayProcedure.execute(world, x, y, z), 9, 72, -12829636, false);
	}

	@Override
	public void init() {
		super.init();
	}
}