package net.mcreator.lazybank.client.gui;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.lazybank.world.inventory.LazybankFluidGuiMenu;
import net.mcreator.lazybank.procedures.LazybankFluidProgressDisplayProcedure;
import net.mcreator.lazybank.procedures.LazybankFluidNameDisplayProcedure;
import net.mcreator.lazybank.procedures.LazybankFluidBalanceDisplayProcedure;
import net.mcreator.lazybank.init.LazybankModScreens;

import com.mojang.blaze3d.systems.RenderSystem;

public class LazybankFluidGuiScreen extends AbstractContainerScreen<LazybankFluidGuiMenu> implements LazybankModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private static final ResourceLocation BACKGROUND = new ResourceLocation("lazybank:textures/screens/lazybank_fluid_gui.png");

	public LazybankFluidGuiScreen(LazybankFluidGuiMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 200;
		this.imageHeight = 100;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(guiGraphics);
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(BACKGROUND, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.lazybank.lazybank_fluid_gui.label_fluid_name"), 9, 10, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.lazybank.lazybank_fluid_gui.label_balance"), 9, 37, -12829636, false);
		guiGraphics.drawString(this.font, LazybankFluidNameDisplayProcedure.execute(world, x, y, z), 9, 19, -12829636, false);
		guiGraphics.drawString(this.font, LazybankFluidBalanceDisplayProcedure.execute(world, x, y, z), 9, 46, -12829636, false);
		guiGraphics.drawString(this.font, LazybankFluidProgressDisplayProcedure.execute(world, x, y, z), 9, 73, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.lazybank.lazybank_fluid_gui.label_progress"), 9, 64, -12829636, false);
	}

	@Override
	public void init() {
		super.init();
	}
}