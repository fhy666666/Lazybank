package net.mcreator.lazybank.client.gui;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Checkbox;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.Minecraft;

import net.mcreator.lazybank.world.inventory.LazybankConfigGuiMenu;
import net.mcreator.lazybank.procedures.*;
import net.mcreator.lazybank.network.LazybankConfigGuiButtonMessage;
import net.mcreator.lazybank.init.LazybankModScreens;
import net.mcreator.lazybank.LazybankMod;

import com.mojang.blaze3d.systems.RenderSystem;

public class LazybankConfigGuiScreen extends AbstractContainerScreen<LazybankConfigGuiMenu> implements LazybankModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private EditBox minimumInterestBearingAmount;
	private EditBox interestRate;
	private EditBox interestEarningPeriod;
	private Checkbox isLazybankRebalancedMode;
	private Checkbox isLazybankFluidRebalancedMode;
	private Checkbox isLazybankChemicalRebalancedMode;
	private Button button_save;
	private static final ResourceLocation BACKGROUND = new ResourceLocation("lazybank:textures/screens/lazybank_config_gui.png");

	public LazybankConfigGuiScreen(LazybankConfigGuiMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 400;
		this.imageHeight = 250;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		if (elementType == 0 && elementState instanceof String stringState) {
			if (name.equals("minimumInterestBearingAmount"))
				minimumInterestBearingAmount.setValue(stringState);
			else if (name.equals("interestRate"))
				interestRate.setValue(stringState);
			else if (name.equals("interestEarningPeriod"))
				interestEarningPeriod.setValue(stringState);
		}
		if (elementType == 1 && elementState instanceof Boolean logicState) {
			if (name.equals("isLazybankRebalancedMode")) {
				if (isLazybankRebalancedMode.selected() != logicState)
					isLazybankRebalancedMode.onPress();
			} else if (name.equals("isLazybankFluidRebalancedMode")) {
				if (isLazybankFluidRebalancedMode.selected() != logicState)
					isLazybankFluidRebalancedMode.onPress();
			} else if (name.equals("isLazybankChemicalRebalancedMode")) {
				if (isLazybankChemicalRebalancedMode.selected() != logicState)
					isLazybankChemicalRebalancedMode.onPress();
			}
		}
		menuStateUpdateActive = false;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(guiGraphics);
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		minimumInterestBearingAmount.render(guiGraphics, mouseX, mouseY, partialTicks);
		interestRate.render(guiGraphics, mouseX, mouseY, partialTicks);
		interestEarningPeriod.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(BACKGROUND, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		if (minimumInterestBearingAmount.isFocused())
			return minimumInterestBearingAmount.keyPressed(key, b, c);
		if (interestRate.isFocused())
			return interestRate.keyPressed(key, b, c);
		if (interestEarningPeriod.isFocused())
			return interestEarningPeriod.keyPressed(key, b, c);
		return super.keyPressed(key, b, c);
	}

	@Override
	public void resize(Minecraft minecraft, int width, int height) {
		String minimumInterestBearingAmountValue = minimumInterestBearingAmount.getValue();
		String interestRateValue = interestRate.getValue();
		String interestEarningPeriodValue = interestEarningPeriod.getValue();
		super.resize(minecraft, width, height);
		minimumInterestBearingAmount.setValue(minimumInterestBearingAmountValue);
		interestRate.setValue(interestRateValue);
		interestEarningPeriod.setValue(interestEarningPeriodValue);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.lazybank.lazybank_config_gui.label_minimuminterestbearingamount"), 10, 13, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.lazybank.lazybank_config_gui.label_interestrate"), 10, 49, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.lazybank.lazybank_config_gui.label_interestearningperiod"), 10, 85, -12829636, false);
		guiGraphics.drawString(this.font, MinimumInterestBearingAmountDisplayProcedure.execute(world), 136, 31, -12829636, false);
		guiGraphics.drawString(this.font, InterestEarningPeriodDisplayProcedure.execute(world), 136, 103, -12829636, false);
		guiGraphics.drawString(this.font, InterestRateDisplayProcedure.execute(world), 136, 67, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.lazybank.lazybank_config_gui.label_are_you_sure_you_wanna_disable_t"), 10, 202, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.lazybank.lazybank_config_gui.label_dont_you_wanna_build_a_few_prop"), 10, 211, -12829636, false);
	}

	@Override
	public void init() {
		super.init();
		minimumInterestBearingAmount = new EditBox(this.font, this.leftPos + 10, this.topPos + 22, 120, 20, Component.translatable("gui.lazybank.lazybank_config_gui.minimumInterestBearingAmount"));
		minimumInterestBearingAmount.setMaxLength(8192);
		minimumInterestBearingAmount.setResponder(content -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 0, "minimumInterestBearingAmount", content, false);
		});
		this.addWidget(this.minimumInterestBearingAmount);
		interestRate = new EditBox(this.font, this.leftPos + 10, this.topPos + 58, 120, 20, Component.translatable("gui.lazybank.lazybank_config_gui.interestRate"));
		interestRate.setMaxLength(8192);
		interestRate.setResponder(content -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 0, "interestRate", content, false);
		});
		this.addWidget(this.interestRate);
		interestEarningPeriod = new EditBox(this.font, this.leftPos + 10, this.topPos + 94, 120, 20, Component.translatable("gui.lazybank.lazybank_config_gui.interestEarningPeriod"));
		interestEarningPeriod.setMaxLength(8192);
		interestEarningPeriod.setResponder(content -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 0, "interestEarningPeriod", content, false);
		});
		this.addWidget(this.interestEarningPeriod);
		button_save = Button.builder(Component.translatable("gui.lazybank.lazybank_config_gui.button_save"), e -> {
			int x = LazybankConfigGuiScreen.this.x;
			int y = LazybankConfigGuiScreen.this.y;
			if (true) {
				LazybankMod.PACKET_HANDLER.sendToServer(new LazybankConfigGuiButtonMessage(0, x, y, z));
				LazybankConfigGuiButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 298, this.topPos + 202, 81, 20).build();
		this.addRenderableWidget(button_save);
		boolean isLazybankRebalancedModeSelected = LazybankRebalancedModeCheckboxProcedure.execute(world);
		isLazybankRebalancedMode = new Checkbox(this.leftPos + 10, this.topPos + 121, 20, 20, Component.translatable("gui.lazybank.lazybank_config_gui.isLazybankRebalancedMode"), isLazybankRebalancedModeSelected) {
			@Override
			public void onPress() {
				super.onPress();
				if (!menuStateUpdateActive)
					menu.sendMenuStateUpdate(entity, 1, "isLazybankRebalancedMode", this.selected(), false);
			}
		};
		if (isLazybankRebalancedModeSelected)
			menu.sendMenuStateUpdate(entity, 1, "isLazybankRebalancedMode", true, false);
		this.addRenderableWidget(isLazybankRebalancedMode);
		boolean isLazybankFluidRebalancedModeSelected = LazybankFluidRebalancedModeCheckboxProcedure.execute(world);
		isLazybankFluidRebalancedMode = new Checkbox(this.leftPos + 10, this.topPos + 148, 20, 20, Component.translatable("gui.lazybank.lazybank_config_gui.isLazybankFluidRebalancedMode"), isLazybankFluidRebalancedModeSelected) {
			@Override
			public void onPress() {
				super.onPress();
				if (!menuStateUpdateActive)
					menu.sendMenuStateUpdate(entity, 1, "isLazybankFluidRebalancedMode", this.selected(), false);
			}
		};
		if (isLazybankFluidRebalancedModeSelected)
			menu.sendMenuStateUpdate(entity, 1, "isLazybankFluidRebalancedMode", true, false);
		this.addRenderableWidget(isLazybankFluidRebalancedMode);
		boolean isLazybankChemicalRebalancedModeSelected = LazybankChemicalRebalancedModeCheckboxProcedure.execute(world);
		isLazybankChemicalRebalancedMode = new Checkbox(this.leftPos + 10, this.topPos + 175, 20, 20, Component.translatable("gui.lazybank.lazybank_config_gui.isLazybankChemicalRebalancedMode"), isLazybankChemicalRebalancedModeSelected) {
			@Override
			public void onPress() {
				super.onPress();
				if (!menuStateUpdateActive)
					menu.sendMenuStateUpdate(entity, 1, "isLazybankChemicalRebalancedMode", this.selected(), false);
			}
		};
		if (isLazybankChemicalRebalancedModeSelected)
			menu.sendMenuStateUpdate(entity, 1, "isLazybankChemicalRebalancedMode", true, false);
		this.addRenderableWidget(isLazybankChemicalRebalancedMode);
	}

	@Override
	protected void containerTick() {
		super.containerTick();
		minimumInterestBearingAmount.tick();
		interestRate.tick();
		interestEarningPeriod.tick();
	}
}